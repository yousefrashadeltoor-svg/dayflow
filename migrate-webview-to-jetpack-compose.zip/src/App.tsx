import { useMemo } from "react";

const FIXES = [
  { icon: "🤖", t: "الروبوت يطفو فوق الشاشة كلها", d: "RobotOverlayService بخدمة أمامية وTYPE_APPLICATION_OVERLAY — نفس التصميم والفيزياء، سحب وقذف والتصاق بالحواف، لوحة سريعة وفقاعات تذكير، وإشعار دائم بزر إيقاف." },
  { icon: "⬇️", t: "التحميل بلا جدار CORS", d: "تحليل وتحميل أصليان بـ OkHttp وThreads IO مباشرة: فحص Range ثم HEAD، تحليل m3u8، ومحرك متعدد المسارات يستكمل بعد الإغلاق من ملفات .part." },
  { icon: "🔗", t: "معاينة الروابط الحقيقية", d: "oEmbed (يوتيوب/فيميو/ساوندكلاود/تيك توك) ثم كشط Open Graph بـ Jsoup — عنوان وغلاف ومؤلف ووصف ومدة وحجم من استجابات حقيقية فقط." },
  { icon: "⏰", t: "منبه يعمل فعلًا", d: "setAlarmClock + مستقبِل يرنّ والتطبيق مقتول، شاشة رنين فوق القفل، غفوة، استيقاظ لطيف ٦٠ ثانية، اهتزاز، ومرجع URI دائم للنغمة." },
  { icon: "🧩", t: "ودجات Home Screen حقيقية", d: "خمس بوابات؛ الإضافة من الشاشة تفتح كتالوج التطبيق فورًا لاختيار التصميم لذات الـ appWidgetId — يُرسم بالبيانات الحقيقية ويتحدث كل دقيقة." },
  { icon: "🔔", t: "إشعارات أصلية كاملة", d: "خمس قنوات (منبهات/تذكيرات/تنزيلات/رفيق/مراجعة)، إذن أندرويد 13+، أزرار إجراءات، و«مراجعة المسا» مجدولة بـ AlarmManager وتُستعاد بعد الإقلاع." },
  { icon: "🕌", t: "مواقيت صلاة صحيحة", d: "قراءة توقيت النظام بقواعد DST المصرية (+2/+3 تلقائيًا)، الجيزة و١٦ مدينة، GPS اختياري، ولفّ الصلاة القادمة لفجر الغد الحقيقي." },
  { icon: "🕧", t: "الصيغة ١٢ ساعة في كل مكان", d: "TimeFmt موحّد إجباري بأرقام عربية و«ص/م» — الشاشات والمحرر والودجات والإشعارات؛ محرر المنبه صار عجلات ١–١٢ + ص/م." },
  { icon: "📱", t: "أندرويد أصلي — لا WebView", d: "إعادة بناء بـ Jetpack Compose بنفس الواجهة حرفيًا (٦٠ ثيمًا، المكونات، RTL، الأيقونات) والمنطق كله Kotlin على النظام." },
  { icon: "🌐", t: "رسائل الويب للمتصفح فقط", d: "لا تحذيرات «يعمل على أندرويد فقط» داخل النسخة الأصلية إطلاقًا — لأن كل شيء مُنفذ فعليًا." },
  { icon: "⚡", t: "سلاسة حقيقية", d: "نبض إطار واحد يعيد رسم Canvas فقط (لا إعادة تركيب لكل إطار)، بذور حتمية، قوائم Lazy، ولا setInterval في الواجهة." },
  { icon: "🍂", t: "زخارف واقعية لمواسم أكثر", d: "ثلج بثلاث طبقات عمق، ساكورا متطاولة، فقاعات صيف شفافة، فوانيس توهج، يراعات ليلية، بالونات وخيوط، حمام وطني، شموع قبطية — كلها متجهات Canvas." },
];

const FILES = [
  { p: "DayflowApp.kt", d: "التهيئة: القنوات، استعادة المنبهات، مزامنة الودجات، إطلاق الروبوت تلقائيًا" },
  { p: "alarm/AlarmScheduler.kt", d: "جدولة دقيقة setAlarmClock + إذن SCHEDULE_EXACT_ALARM وبدائلها" },
  { p: "alarm/AlarmReceiver.kt + BootReceiver", d: "يرنّ مقتولًا، ويعيد التسليح بعد BOOT_COMPLETED/TIME_SET/TIMEZONE_CHANGED" },
  { p: "alarm/AlarmSoundService.kt", d: "صوت مستمر، gentle wake ramp، اهتزاز، أزرار غفوة/إيقاف" },
  { p: "alarm/AlarmActivity.kt", d: "شاشة الرنين نفس التصميم: تدرج موسمي، زخرفة، سحب للإيقاف" },
  { p: "companion/RobotModel.kt + RobotOverlayService.kt", d: "الروبوت الأصلي فوق كل التطبيقات — نفس الجسم والأزياء والفيزياء" },
  { p: "widget/Widgets.kt + WidgetPainter.kt + WidgetConfigActivity.kt", d: "البوابات الخمس، الرسم الأصلي، اختيار التصميم من الكتالوج" },
  { p: "download/LinkAnalyzer.kt + DownloadService.kt", d: "تحليل OG/oEmbed/m3u8 ومحرك Range متعدد المسارات مع إشعارات التقدم" },
  { p: "prayer/PrayerEngine.kt", d: "فلكية دقيقة بقواعد ZoneId الحقيقية ومدن موسّعة" },
  { p: "calendar/Calendars.kt", d: "هجري (أم القرى) + قبطي (حساب JDN دقيق) + المناسبات وحلّال الزخارف" },
  { p: "ui/theme/Themes.kt + patterns/Patterns.kt + decor/DecorCanvas.kt", d: "٦٠ ثيمًا ومحرك الزخارف بالمعادلات نفسها + الزخارف الواقعية الجديدة" },
  { p: "data/Store.kt", d: "مخطط بيانات يوافق dayflow-v2، محفوظ ذرّيًا في SharedPreferences" },
];

export default function App() {
  const stats = useMemo(() => ({ fixes: FIXES.length + 9, files: 36 }), []);
  return (
    <div dir="rtl" className="min-h-full" style={{ background: "#0d1220", color: "#e6e9f2", fontFamily: "system-ui, 'Segoe UI', sans-serif" }}>
      <div className="mx-auto max-w-3xl px-5 py-10">
        {/* hero */}
        <div className="relative overflow-hidden rounded-3xl p-8 text-center" style={{ background: "linear-gradient(145deg, #123a3e, #0c2b2e)", border: "1px solid #d4a83a33" }}>
          <div className="mx-auto mb-4 grid h-20 w-20 place-items-center rounded-3xl" style={{ background: "#d4a83a22", boxShadow: "0 0 30px #d4a83a44 inset" }}>
            {/* eslint-disable-next-line */}
            <svg width="52" height="52" viewBox="0 0 120 140" aria-hidden>
              <defs>
                <radialGradient id="b" cx="35%" cy="30%" r="80%"><stop offset="0" stopColor="#fff" /><stop offset="1" stopColor="#8d9bb0" /></radialGradient>
              </defs>
              <line x1="48" y1="40" x2="42" y2="22" stroke="#7d8aa0" strokeWidth="3" strokeLinecap="round" />
              <line x1="72" y1="40" x2="78" y2="22" stroke="#7d8aa0" strokeWidth="3" strokeLinecap="round" />
              <circle cx="42" cy="19" r="5" fill="#d4a83a" /><circle cx="78" cy="19" r="5" fill="#d4a83a" />
              <rect x="30" y="36" width="60" height="46" rx="20" fill="url(#b)" stroke="#7f8ca2" />
              <rect x="37" y="45" width="46" height="28" rx="13" fill="#0d1424" />
              <ellipse cx="50" cy="59" rx="4" ry="5" fill="#7fd6ff" /><ellipse cx="70" cy="59" rx="4" ry="5" fill="#7fd6ff" />
              <rect x="34" y="84" width="52" height="46" rx="18" fill="url(#b)" stroke="#7f8ca2" />
              <rect x="47" y="96" width="26" height="16" rx="5" fill="#0f1a2c" />
              <circle cx="60" cy="104" r="4" fill="#d4a83a" />
            </svg>
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight" style={{ color: "#f3e9cc" }}>DAYFLOW — الإصلاح الكامل</h1>
          <p className="mt-2 text-sm leading-6" style={{ color: "#f3e9ccb3" }}>
            نسخة أندرويد أصلية بنفس الواجهة حرفيًا «نفس كل شيء» — Kotlin + Jetpack Compose،
            والمنطق كله أصلي: المنبه، التعويم، الودجات، التحميل، المواقيت، الإشعارات، الزخارف.
          </p>
          <div className="mt-5 flex flex-wrap justify-center gap-2 text-xs font-bold">
            <span className="rounded-full px-3 py-1" style={{ background: "#d4a83a2b", color: "#f3dfa2" }}>{stats.fixes} مشكلة ومحاكاة حُلّت</span>
            <span className="rounded-full px-3 py-1" style={{ background: "#4fb39a2b", color: "#b8f0df" }}>{stats.files} ملفًا أصليًا</span>
            <span className="rounded-full px-3 py-1" style={{ background: "#7aa2ff2b", color: "#c9d8ff" }}>app.dayflow.android · minSdk 26</span>
          </div>
        </div>

        {/* fixes */}
        <h2 className="mb-3 mt-8 px-1 text-lg font-bold">كل المشاكل — وحلّها</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          {FIXES.map((f) => (
            <div key={f.t} className="rounded-2xl p-4" style={{ background: "#161d30", border: "1px solid #e6e9f214" }}>
              <p className="flex items-center gap-2 text-sm font-bold"><span aria-hidden>{f.icon}</span>{f.t}</p>
              <p className="mt-1.5 text-xs leading-5" style={{ color: "#e6e9f299" }}>{f.d}</p>
            </div>
          ))}
        </div>

        {/* architecture */}
        <h2 className="mb-3 mt-8 px-1 text-lg font-bold">بنية النسخة الأصلية</h2>
        <div className="grid gap-2">
          {FILES.map((m) => (
            <div key={m.p} className="flex items-start gap-3 rounded-xl px-4 py-3 text-xs" style={{ background: "#161d30", border: "1px solid #e6e9f20e" }}>
              <code className="flex-none rounded-md px-2 py-1 font-mono text-[10px]" dir="ltr" style={{ background: "#0d1220", color: "#9fd0ff" }}>{m.p}</code>
              <span style={{ color: "#e6e9f2bb" }}>{m.d}</span>
            </div>
          ))}
        </div>

        {/* build */}
        <h2 className="mb-3 mt-8 px-1 text-lg font-bold">البناء</h2>
        <div className="rounded-2xl p-4" dir="ltr" style={{ background: "#0b0f1a", border: "1px solid #e6e9f21a" }}>
          <pre className="overflow-x-auto text-xs leading-6" style={{ color: "#b6f5b6" }}>{`cd dayflow-android
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
# APK → app/build/outputs/apk/debug/`}</pre>
        </div>
        <p className="mt-3 text-xs leading-5" style={{ color: "#e6e9f280" }}>
          القائمة الكاملة الجاهزة للنسخ داخل <code>dayflow-android/README_FIXES.md</code>.
          الواجهة لم تتغير: نفس الستين ثيمًا والخامات والأشكال والحركات والزخارف والاتجاه RTL.
        </p>
      </div>
    </div>
  );
}
