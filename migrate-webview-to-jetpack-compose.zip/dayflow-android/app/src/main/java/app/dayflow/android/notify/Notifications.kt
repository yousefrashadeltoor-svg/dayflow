package app.dayflow.android.notify

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import app.dayflow.android.MainActivity
import app.dayflow.android.R
import app.dayflow.android.alarm.AlarmReceiver
import app.dayflow.android.alarm.AlarmScheduler
import app.dayflow.android.alarm.Reminders
import app.dayflow.android.data.Alarm
import app.dayflow.android.data.Store
import app.dayflow.android.time.TimeFmt
import java.util.Calendar
import java.util.Date

/** One place for channels, permission state, alarm/reminder posts. */
object Notifications {

    const val CH_ALARMS = "alarms"
    const val CH_REMINDERS = "reminders"
    const val CH_DOWNLOADS = "downloads"
    const val CH_COMPANION = "companion"
    const val CH_REVIEW = "review"

    const val ID_ALARM = 4001
    const val ID_REVIEW = 4002
    const val ID_COMPANION = 4003
    const val ID_SNOOZE = 4004

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        nm.createNotificationChannels(
            listOf(
                NotificationChannel(CH_ALARMS, ctx.getString(R.string.ch_alarms), NotificationManager.IMPORTANCE_HIGH).apply {
                    setSound(alarmSound, AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
                    enableVibration(true)
                    setBypassDnd(true)
                    lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                },
                NotificationChannel(CH_REMINDERS, ctx.getString(R.string.ch_reminders), NotificationManager.IMPORTANCE_DEFAULT),
                NotificationChannel(CH_DOWNLOADS, ctx.getString(R.string.ch_downloads), NotificationManager.IMPORTANCE_LOW),
                NotificationChannel(CH_COMPANION, ctx.getString(R.string.ch_companion), NotificationManager.IMPORTANCE_MIN),
                NotificationChannel(CH_REVIEW, ctx.getString(R.string.ch_review), NotificationManager.IMPORTANCE_DEFAULT),
            ),
        )
    }

    fun hasPermission(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED

    private fun openAppPI(ctx: Context, tab: String = "today"): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).putExtra("tab", tab).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(ctx, tab.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /** Full-screen alarm notification (the reliable path when direct activity launch is blocked). */
    fun alarmFire(ctx: Context, alarm: Alarm) {
        val full = PendingIntent.getActivity(
            ctx, alarm.id.hashCode(),
            Intent(ctx, app.dayflow.android.alarm.AlarmActivity::class.java).putExtra(app.dayflow.android.alarm.AlarmSoundService.EXTRA_ALARM_ID, alarm.id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val dismiss = PendingIntent.getService(ctx, 11, app.dayflow.android.alarm.AlarmSoundService.dismissIntent(ctx, alarm.id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val snooze = PendingIntent.getService(ctx, 12, app.dayflow.android.alarm.AlarmSoundService.snoozeIntent(ctx, alarm.id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(ctx, CH_ALARMS)
            .setSmallIcon(R.drawable.ic_launcher_fg)
            .setContentTitle(alarm.label.ifBlank { ctx.getString(R.string.app_name) })
            .setContentText("المنبه يرن · " + TimeFmt.fmt(alarm.time, Store.current().lang))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(full, true)
            .setContentIntent(full)
            .setOngoing(true)
            .addAction(0, ctx.getString(R.string.alarm_snooze) + " ${TimeFmt.num(alarm.snooze, Store.current().lang)} د", snooze)
            .addAction(0, ctx.getString(R.string.alarm_dismiss), dismiss)
        if (hasPermission(ctx)) NotificationManagerCompat.from(ctx).notify(ID_ALARM, n.build())
    }

    fun snoozed(ctx: Context, alarmId: String, minutes: Int) {
        val n = NotificationCompat.Builder(ctx, CH_ALARMS)
            .setSmallIcon(R.drawable.ic_launcher_fg)
            .setContentTitle(ctx.getString(R.string.app_name))
            .setContentText("غفوة — يرن مرة أخرى بعد ${TimeFmt.num(minutes, Store.current().lang)} دقيقة")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(false)
        if (hasPermission(ctx)) NotificationManagerCompat.from(ctx).notify(ID_SNOOZE, n.build())
    }

    /** The scheduled evening review / reminder hit. */
    fun reminderHit(ctx: Context) {
        val s = Store.current()
        if (s.notif.quiet) { Reminders.scheduleDailyReview(ctx); return }
        val seen: Int = s.tasks.count { it.date == Store.dayKey() && it.done }
        val total: Int = s.tasks.count { it.date == Store.dayKey() }
        val body = if (total > 0) "أنجزت ${TimeFmt.num(seen, s.lang)} من ${TimeFmt.num(total, s.lang)} مهام اليوم" else "يومك هادي — راجع خطتك لبكرة"
        val n = NotificationCompat.Builder(ctx, CH_REVIEW)
            .setSmallIcon(R.drawable.ic_launcher_fg)
            .setContentTitle("مراجعة المسا")
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(openAppPI(ctx, "me"))
            .addAction(0, "افتح", openAppPI(ctx, "me"))
            .setAutoCancel(true)
        if (hasPermission(ctx)) NotificationManagerCompat.from(ctx).notify(ID_REVIEW, n.build())
        Reminders.scheduleDailyReview(ctx) // re-arm tomorrow
    }

    /** Companion "bring me back" / status notification. */
    fun companionHidden(ctx: Context) {
        val back = openAppPI(ctx, "me:companion")
        val n = NotificationCompat.Builder(ctx, CH_COMPANION)
            .setSmallIcon(R.drawable.ic_launcher_fg)
            .setContentTitle("DAYFLOW — الرفيق مستخفي")
            .setContentText("اضغط هنا ترجّعه تاني في أي وقت")
            .setContentIntent(back).setAutoCancel(true)
        if (hasPermission(ctx)) NotificationManagerCompat.from(ctx).notify(ID_COMPANION, n.build())
    }
}

/** Schedules the daily review notification natively (survives app death; re-arms after boot). */
object Reminders {
    fun scheduleDailyReview(ctx: Context) {
        val s = Store.current()
        val parts = s.notif.dailyReview.split(":").mapNotNull { it.toIntOrNull() }
        if (parts.size < 2) return
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, parts[0]); set(Calendar.MINUTE, parts[1]); set(Calendar.SECOND, 0)
            if (time.before(Date())) add(Calendar.DAY_OF_YEAR, 1)
        }
        val i = Intent(ctx, AlarmReceiver::class.java).setAction(AlarmScheduler.ACTION_REMINDER)
        val pi = PendingIntent.getBroadcast(ctx, 7777, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            if (AlarmScheduler.canScheduleExact(ctx)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
            else am.set(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
        } catch (se: SecurityException) {
            am.set(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
        }
    }
}
