package app.dayflow.android.ui.shell

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.StickyNote2
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlaylistAddCheck
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.calendar.Calendars
import app.dayflow.android.data.Store
import app.dayflow.android.decor.DecorCanvas
import app.dayflow.android.ui.AppBackground
import app.dayflow.android.ui.DFButton
import app.dayflow.android.ui.DFSheet
import app.dayflow.android.ui.bodyStyle
import app.dayflow.android.ui.pack
import app.dayflow.android.ui.screens.AIScreen
import app.dayflow.android.ui.screens.AlarmsScreen
import app.dayflow.android.ui.screens.CalendarScreen
import app.dayflow.android.ui.screens.DownloadsScreen
import app.dayflow.android.ui.screens.MeScreen
import app.dayflow.android.ui.screens.TodayScreen
import app.dayflow.android.ui.screens.ToolsScreen
import java.time.LocalDate

/** Root shell — same design: max-width content, floating create FAB, blur tab bar. */
@Composable
fun AppShell(initialTab: String, initialSub: String?, sharedLink: String?, onShareConsumed: () -> Unit) {
    val s by Store.state.collectAsState()
    var tab by rememberSaveable { mutableStateOf(initialTab) }
    var sub by rememberSaveable { mutableStateOf(initialSub) }
    var quick by rememberSaveable { mutableStateOf(false) }
    val ar = s.lang == "ar"

    LaunchedEffect(initialTab, initialSub) { tab = initialTab; sub = initialSub }
    LaunchedEffect(sharedLink) {
        if (sharedLink != null) { tab = "downloads"; onShareConsumed() }
    }

    val decor = remember(s.userDays, s.intensity, s.examSeason) {
        Calendars.resolveDecor(LocalDate.now(), s.userDays, if (s.intensity == "off") 1 else 3, s.examSeason)
    }
    val showParticles = s.decorSurfaces["app"] == true && s.intensity != "off" && !s.reduceMotion && (s.intensity != "subtle" || decor.occasions.isNotEmpty())

    Box(Modifier.fillMaxSize()) {
        AppBackground()
        if (showParticles) DecorCanvas.Layer(decor.primary, s.intensity, Modifier.fillMaxSize())

        Scaffold(
            containerColor = androidx.compose.ui.graphics.Color.Transparent,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = { TabBar(tab) { tab = it; sub = null } },
            floatingActionButton = {
                val p = pack
                Box(
                    Modifier.size(56.dp).shadow(10.dp, CircleShape).clip(CircleShape).background(p.accent).clickable { quick = true },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Add, contentDescription = if (ar) "اعمل جديد" else "Create", tint = p.onAccent, modifier = Modifier.size(26.dp)) }
            },
            floatingActionButtonPosition = androidx.compose.material3.FabPosition.Center,
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(bottom = padding.calculateBottomPadding()).statusBarsPadding()
                    .widthIn(max = 640.dp).align(Alignment.CenterHorizontally).padding(horizontal = 16.dp),
            ) {
                when (tab) {
                    "today" -> TodayScreen(go = { t, sb -> tab = t; sub = sb })
                    "calendar" -> CalendarScreen(go = { t, sb -> tab = t; sub = sb })
                    "alarms" -> AlarmsScreen()
                    "tools" -> ToolsScreen(sub, go = { t, sb -> tab = t; sub = sb })
                    "ai" -> AIScreen(go = { t, sb -> tab = t; sub = sb })
                    "downloads" -> DownloadsScreen(sharedLink)
                    "me" -> MeScreen(sub, go = { t, sb -> tab = t; sub = sb })
                }
            }
        }

        QuickCreate(quick, { quick = false }, { t, sb -> tab = t; sub = sb })
    }
}

@Composable
private fun TabBar(active: String, onTab: (String) -> Unit) {
    val p = pack
    val ctx = LocalContext.current
    val tabs: List<Triple<String, ImageVector, String>> = listOf(
        Triple("today", Icons.Filled.WbSunny, if (p.dark) "Today" else "Today"),
        Triple("calendar", Icons.Filled.CalendarMonth, "Calendar"),
        Triple("tools", Icons.Filled.GridView, "Tools"),
        Triple("alarms", Icons.Filled.Alarm, "Alarms"),
        Triple("ai", Icons.Filled.AutoAwesome, "AI"),
        Triple("downloads", Icons.Filled.Download, "Download"),
        Triple("me", Icons.Filled.Person, "Me"),
    )
    val ar = Store.current().lang == "ar"
    val labels = if (ar) listOf("النهاردة", "التقويم", "أدوات", "المنبهات", "الذكاء", "التحميل", "أنا") else tabs.map { it.third }

    Row(
        Modifier.fillMaxWidth().navigationBarsPadding()
            .background(p.surface.copy(alpha = 0.78f))
            .padding(top = 6.dp, bottom = 10.dp),
    ) {
        tabs.forEachIndexed { i, (id, icon, _) ->
            val on = active == id
            Column(
                Modifier.weight(1f).clickable { onTab(id) }.padding(top = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    Modifier.height(28.dp).size(width = 40.dp, height = 28.dp).clip(CircleShape)
                        .background(if (on) p.soft else androidx.compose.ui.graphics.Color.Transparent),
                    contentAlignment = Alignment.Center,
                ) { Icon(icon, null, tint = if (on) p.accent else p.muted, modifier = Modifier.size(20.dp)) }
                Text(
                    labels[i],
                    fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = if (on) p.accent else p.muted,
                )
            }
        }
    }
}

@Composable
private fun QuickCreate(open: Boolean, onClose: () -> Unit, go: (String, String?) -> Unit) {
    val ar = Store.current().lang == "ar"
    var mode by remember { mutableStateOf<String?>(null) }
    var txt by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("06:00") }
    if (!open) { mode = null; return }
    DFSheet(open = true, onClose = { mode = null; onClose() }, title = if (ar) "اعمل جديد" else "Create") {
        if (mode == null) {
            val items = listOf(
                Triple(if (ar) "منبه" else "Alarm", Icons.Filled.Alarm, "alarm"),
                Triple(if (ar) "مهمة" else "Task", Icons.Filled.PlaylistAddCheck, "task"),
                Triple(if (ar) "ملاحظة" else "Note", Icons.AutoMirrored.Outlined.StickyNote2, "note"),
                Triple(if (ar) "تذكير" else "Reminder", Icons.Filled.Add, "reminder"),
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items.forEach { (label, icon, kind) ->
                    Column(
                        Modifier.weight(1f).clip(androidx.compose.foundation.shape.RoundedCornerShape(18.dp))
                            .background(pack.soft).clickable {
                                when (kind) {
                                    "alarm" -> { onClose(); mode = null; go("alarms", null) }
                                    else -> mode = kind
                                }
                            }.padding(vertical = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Icon(icon, null, tint = pack.accent, modifier = Modifier.size(22.dp))
                        Text(label, style = bodyStyle(12, FontWeight.SemiBold))
                    }
                }
            }
        } else {
            androidx.compose.material3.OutlinedTextField(
                value = txt, onValueChange = { txt = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text(if (mode == "note") (if (ar) "اكتب ملاحظة…" else "Write a note…") else if (ar) "ما المطلوب إنجازه؟" else "What needs doing?") },
            )
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DFButton(if (ar) "رجوع" else "Back", { mode = null }, variant = "ghost")
                DFButton(if (ar) "حفظ" else "Save", {
                    val v = txt.trim()
                    if (v.isNotEmpty()) {
                        when (mode) {
                            "task" -> Store.addTask(v)
                            "note" -> Store.addNote(v)
                            "reminder" -> {
                                val id = Store.addAlarm(app.dayflow.android.data.Alarm("", time, days = emptyList(), label = v, enabled = true))
                                app.dayflow.android.alarm.AlarmScheduler.schedule(
                                    LocalContextHolder.ctx, Store.current().alarms.find { it.id == id }!!,
                                )
                            }
                        }
                    }
                    mode = null; txt = ""; onClose()
                }, Modifier.weight(1f))
            }
        }
    }
}

/** Simple context holder for quick-create scheduling. */
object LocalContextHolder { lateinit var ctx: android.content.Context }
