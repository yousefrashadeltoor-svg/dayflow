package app.dayflow.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.ai.MiniBrain
import app.dayflow.android.data.ApiKeyEntry
import app.dayflow.android.data.ChatMsg
import app.dayflow.android.data.Store
import app.dayflow.android.ui.DFButton
import app.dayflow.android.ui.DFCard
import app.dayflow.android.ui.DFSheet
import app.dayflow.android.ui.Honest
import app.dayflow.android.ui.ScreenHeader
import app.dayflow.android.ui.bodyStyle
import app.dayflow.android.ui.pack
import kotlinx.coroutines.launch

/** AI — the same chat shell with the local Egyptian engine as default, keys behind a sheet. */
@Composable
fun AIScreen(go: (String, String?) -> Unit) {
    val s by Store.state.collectAsState()
    val lang = s.lang
    val scope = rememberCoroutineScope()
    val msgs = remember { mutableStateListOf<ChatMsg>() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var keys by remember { mutableStateOf(false) }
    val activeKey = s.apiKeys.find { it.id == s.activeKeyId }

    Column(Modifier.fillMaxSize().imePadding()) {
        ScreenHeader(
            title = if (lang == "ar") "الذكاء" else "AI",
            subtitle = activeKey?.let { "${it.provider} · ${s.activeModel.ifBlank { "auto" }}" } ?: if (lang == "ar") "محرك مصري محلي (مش محتاج مفتاح)" else "Local Egyptian engine (no key needed)",
            right = { DFButton(if (lang == "ar") "مفاتيح" else "Keys", { keys = true }, variant = "ghost") },
        )

        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 10.dp)) {
            items(msgs.size) { i ->
                val m = msgs[i]
                val mine = m.role == "user"
                Box(Modifier.fillMaxWidth(), contentAlignment = if (mine) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(
                        m.text, style = bodyStyle(14, if (mine) FontWeight.Normal else FontWeight.Normal, if (mine) pack.onAccent else pack.text),
                        modifier = Modifier
                            .clip(if (mine) RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp) else RoundedCornerShape(20.dp, 20.dp, 20.dp, 6.dp))
                            .background(if (mine) pack.accent else pack.soft)
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                    )
                }
            }
            if (msgs.isEmpty()) {
                item {
                    DFCard {
                        Column(Modifier.padding(16.dp)) {
                            Text(if (lang == "ar") "اسألني أي حاجة…" else "Ask anything…", style = bodyStyle(15, FontWeight.Bold))
                            Spacer(Modifier.height(6.dp))
                            listOf("مهامي فاضلة كام؟", "اعمل منبه ٦:٣٠", "اشرب ماية", "إنت مين؟").forEach { q ->
                                Text(q, style = bodyStyle(12, color = pack.accent), modifier = Modifier.padding(vertical = 3.dp).clickable { input = q })
                            }
                        }
                    }
                }
            }
        }

        Row(Modifier.padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f), placeholder = { Text(if (lang == "ar") "قول أي حاجة… «اعمل منبه ٧»" else "Say anything…") },
                singleLine = true, shape = RoundedCornerShape(26.dp),
            )
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.height(46.dp).width(46.dp).clip(CircleShape).background(pack.accent).clickable(enabled = !busy && input.isNotBlank()) {
                    val q = input.trim(); input = ""
                    msgs += ChatMsg("user", q, System.currentTimeMillis())
                    busy = true
                    scope.launch {
                        val answer = MiniBrain.answer(q, lang) { alarm -> app.dayflow.android.alarm.AlarmScheduler.schedule(app.dayflow.android.ui.shell.LocalContextHolder.ctx, alarm) }
                        msgs += ChatMsg("assistant", answer, System.currentTimeMillis())
                        busy = false
                    }
                },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.Send, null, tint = pack.onAccent, modifier = Modifier.padding(start = if (lang == "ar") 4.dp else 0.dp, end = if (lang == "ar") 0.dp else 4.dp)) }
        }
        Text(
            if (activeKey == null) (if (lang == "ar") "يعمل محليًا؛ المفتاح يفعّل النماذج الكبيرة (OpenAI / Claude / Gemini…)" else "Runs locally; a key unlocks the big models")
            else (if (lang == "ar") "المفتاح نشط — الردود من ${activeKey.provider}" else "Key active — replies come from ${activeKey.provider}"),
            style = bodyStyle(10, color = pack.muted), modifier = Modifier.alpha(0.8f),
        )
    }

    if (keys) {
        DFSheet(open = true, onClose = { keys = false }, title = if (lang == "ar") "مفاتيح API" else "API keys") {
            var provider by remember { mutableStateOf("OpenAI") }
            var key by remember { mutableStateOf("") }
            s.apiKeys.forEach { k ->
                DFCard(Modifier.padding(vertical = 4.dp), onClick = { Store.mutate { it.copy(activeKeyId = k.id) } }) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(k.provider, Modifier.weight(1f), style = bodyStyle(13, FontWeight.SemiBold))
                        if (s.activeKeyId == k.id) Text("✓", color = pack.accent, fontWeight = FontWeight.Bold)
                        Text("✕", modifier = Modifier.clickable { Store.mutate { st -> st.copy(apiKeys = st.apiKeys.filterNot { it.id == k.id }, activeKeyId = if (st.activeKeyId == k.id) null else st.activeKeyId) } }, color = pack.muted)
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(provider, { provider = it }, Modifier.weight(1f), placeholder = { Text("OpenAI / Anthropic / Gemini / Groq…") }, singleLine = true)
            }
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), placeholder = { Text("حط المفتاح هنا…") }, singleLine = true)
            Spacer(Modifier.height(10.dp))
            DFButton(if (lang == "ar") "احفظ" else "Save", {
                if (key.isNotBlank()) {
                    val id = Store.newId()
                    Store.mutate { it.copy(apiKeys = it.apiKeys + ApiKeyEntry(id, provider.ifBlank { "custom" }, provider, key.trim()), activeKeyId = it.activeKeyId ?: id) }
                    key = ""
                }
            })
            Spacer(Modifier.height(8.dp))
            Honest(if (lang == "ar") "المفاتيح تُحفظ على جهازك فقط. طلبات الرد تُرسل مباشرة من أندرويد (بدون CORS)." else "Keys stay on-device; replies are sent straight from Android (no CORS).")
        }
    }
}
