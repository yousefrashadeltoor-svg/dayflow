package app.dayflow.android.alarm

import android.app.KeyguardManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.calendar.Calendars
import app.dayflow.android.data.Store
import app.dayflow.android.decor.DecorCanvas
import app.dayflow.android.patterns.Patterns
import app.dayflow.android.time.TimeFmt
import app.dayflow.android.ui.HeaderCrown
import app.dayflow.android.ui.MotifView
import kotlinx.coroutines.delay
import java.util.Date

/**
 * Native lock-screen-ready ring screen — visual match for the web RingScreen
 * (gradient, pattern wash, header crown, pulsing motif, giant 12h clock,
 * snooze pill, slide-to-dismiss).
 */
class AlarmActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true); setTurnScreenOn(true)
            (getSystemService(KEYGUARD_SERVICE) as KeyguardManager).requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContent {
            val alarmId = intent?.getStringExtra(AlarmSoundService.EXTRA_ALARM_ID)
            val state by Store.state.collectAsState()
            val alarm = state.alarms.find { it.id == alarmId }
            RingScreen(
                label = alarm?.label ?: "",
                snoozeMin = alarm?.snooze ?: 10,
                alarmId = alarmId ?: "",
                lang = state.lang,
                showSeconds = state.alarmLook.showSeconds,
                gradient = state.alarmLook.gradient,
                userDays = state.userDays,
                intensity = "rich",
                onDismiss = { finish() },
                onSnooze = { finish() },
            )
        }
    }
}

@Composable
fun RingScreen(
    label: String, snoozeMin: Int, alarmId: String, lang: String,
    showSeconds: Boolean, gradient: Boolean,
    userDays: List<app.dayflow.android.data.UserDay>, intensity: String,
    onDismiss: () -> Unit, onSnooze: () -> Unit,
) {
    val ctx = LocalContext.current
    val stack = remember { Calendars.resolveDecor(Calendars.run { java.time.LocalDate.now() }, userDays, 3) }
    val fam = stack.primary
    val st = Patterns.FAMILY[fam]!!

    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { nowMs = System.currentTimeMillis(); delay(500) } }

    // slide-to-dismiss (0..1) — same threshold semantics as the web ring screen (95%)
    var slide by remember { mutableStateOf(0f) }
    LaunchedEffect(slide) {
        if (slide >= 0.95f) {
            ctx.startService(AlarmSoundService.dismissIntent(ctx, alarmId))
            onDismiss()
        }
    }
    DisposableEffect(Unit) { onDispose { } }

    val bg = if (gradient) Brush.linearGradient(listOf(st.c2, Color(0xff0b0f1a)), start = Offset(0f, 0f), end = Offset(400f, 1800f))
    else Brush.linearGradient(listOf(Color(0xff0b0f1a), Color(0xff0b0f1a)))

    Box(Modifier.fillMaxSize().background(bg)) {
        // pattern wash
        Canvas(Modifier.fillMaxSize().alpha(0.12f)) {
            val step = 70.dp.toPx()
            var y = -step; while (y < size.height + step) {
                var x = -step; while (x < size.width + step) {
                    val off = if (((y / step).toInt()) % 2 == 0) step / 2 else 0f
                    Patterns.run { with(this@Canvas) { drawMotif(fam, x + off, y, step * 0.8f, mono = Color.White) } }
                    x += step
                }
                y += step
            }
        }
        DecorCanvas.Layer(fam, intensity)

        Column(
            Modifier.fillMaxSize().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                HeaderCrown(fam, height = 70.dp)
                Spacer(Modifier.height(24.dp))
                Text("منبه", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp, letterSpacing = 6.sp)
                Spacer(Modifier.height(10.dp))
                val now = Date(nowMs)
                val parts = TimeFmt.clock12(
                    java.util.Calendar.getInstance().apply { time = now }[java.util.Calendar.HOUR_OF_DAY],
                    java.util.Calendar.getInstance().apply { time = now }[java.util.Calendar.MINUTE],
                    lang,
                    if (showSeconds) java.util.Calendar.getInstance().apply { time = now }[java.util.Calendar.SECOND] else null,
                )
                Text(parts.time, color = Color.White, fontSize = 84.sp, fontWeight = FontWeight.ExtraLight)
                Text(parts.suffix, color = Color.White.copy(alpha = 0.85f), fontSize = 20.sp)
                Spacer(Modifier.height(6.dp))
                Text(label.ifBlank { "منبه" }, color = Color.White.copy(alpha = 0.9f), fontSize = 18.sp)
                Spacer(Modifier.height(4.dp))
                Text(TimeFmt.dateLine(now, lang), color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp)
            }

            // pulsing motif ring (same ring-pulse animation)
            Box(contentAlignment = Alignment.Center) {
                var pulse by remember { mutableStateOf(0f) }
                LaunchedEffect(Unit) { while (true) { pulse = (pulse + 0.016f) % 1f; delay(16) } }
                Canvas(Modifier.size(144.dp).alpha(0.5f * (1 - pulse))) {
                    drawCircle(Color.White, radius = size.minDimension / 2 * (1 + 0.8f * pulse), style = Stroke(2.dp.toPx()))
                }
                Box(
                    Modifier.size(144.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center,
                ) { MotifView(fam, 80.dp, mono = Color.White) }
            }

            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                androidx.compose.material3.Button(
                    onClick = {
                        ctx.startService(AlarmSoundService.snoozeIntent(ctx, alarmId))
                        onSnooze()
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = CircleShape,
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.15f), contentColor = Color.White),
                ) { Text("غفوة ${TimeFmt.num(snoozeMin, lang)} دقائق", fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }

                Spacer(Modifier.height(14.dp))

                // slide to dismiss
                Box(
                    Modifier.fillMaxWidth().height(64.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    Box(
                        Modifier.fillMaxWidth(slide.coerceIn(0.08f, 1f)).fillMaxSize().clip(CircleShape).background(Color.White.copy(alpha = 0.9f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        MotifView(fam, 36.dp, mono = Color(0xff0b0f1a))
                    }
                    Text(
                        if (lang == "ar") "اسحب للإيقاف ←" else "Slide to dismiss →",
                        color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp,
                        modifier = Modifier.align(Alignment.Center),
                    )
                    androidx.compose.material3.Slider(
                        value = slide,
                        onValueChange = { slide = it },
                        onValueChangeFinished = { if (slide < 0.95f) slide = 0f },
                        modifier = Modifier.fillMaxWidth().alpha(0.001f),
                    )
                }
            }
        }
    }
}
