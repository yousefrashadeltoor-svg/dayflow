package app.dayflow.android.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.calendar.Calendars.Family
import app.dayflow.android.patterns.Patterns
import app.dayflow.android.ui.theme.LocalPack
import app.dayflow.android.ui.theme.Material
import app.dayflow.android.ui.theme.PackFont
import app.dayflow.android.ui.theme.ThemePack

/** Applies the DAYFLOW theme pack: colors, material, radius, font family, RTL direction. */
@Composable
fun DayflowTheme(pack: ThemePack, rtl: Boolean, content: @Composable () -> Unit) {
    CompositionLocalProvider(
        LocalPack provides pack,
        LocalContentColor provides pack.text,
        LocalLayoutDirection provides if (rtl) LayoutDirection.Rtl else LayoutDirection.Ltr,
    ) { content() }
}

val pack: ThemePack @Composable get() = LocalPack.current

fun PackFont.family(): FontFamily = when (this) {
    PackFont.serif -> FontFamily.Serif
    PackFont.mono -> FontFamily.Monospace
    PackFont.rounded -> FontFamily.Cursive
    PackFont.condensed -> FontFamily(android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.NORMAL))
    else -> FontFamily.SansSerif
}

@Composable
fun bodyStyle(size: Int = 14, weight: FontWeight = FontWeight.Normal, color: Color = pack.text) =
    TextStyle(fontFamily = pack.font.family(), fontSize = size.sp, fontWeight = weight, color = color)

/** Textures: mesh radial wash / grid / dots / lines — the CSS backgrounds, in Canvas. */
@Composable
fun AppBackground() {
    val p = pack
    Canvas(Modifier.fillMaxSize()) {
        drawRect(p.bg)
        when (p.texture) {
            "mesh" -> {
                drawCircle(Brush.radialGradient(listOf(p.accent.copy(alpha = 0.20f), Color.Transparent), center = Offset(size.width * 0.15f, size.height * 0.1f), radius = size.width * 0.7f), radius = size.width * 0.7f, center = Offset(size.width * 0.15f, size.height * 0.1f))
                drawCircle(Brush.radialGradient(listOf(p.accent2.copy(alpha = 0.18f), Color.Transparent), center = Offset(size.width * 0.9f, size.height * 0.3f), radius = size.width * 0.6f), radius = size.width * 0.6f, center = Offset(size.width * 0.9f, size.height * 0.3f))
                drawCircle(Brush.radialGradient(listOf(p.accent.copy(alpha = 0.13f), Color.Transparent), center = Offset(size.width * 0.5f, size.height), radius = size.width * 0.7f), radius = size.width * 0.7f, center = Offset(size.width * 0.5f, size.height))
            }
            "grid" -> {
                val step = 24.dp.toPx(); val st = Stroke(1f)
                var x = 0f; while (x < size.width) { drawLine(p.line, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f); x += step }
                var y = 0f; while (y < size.height) { drawLine(p.line, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f); y += step }
            }
            "dots" -> {
                val step = 18.dp.toPx()
                var x = 0f; while (x < size.width) { var y = 0f; while (y < size.height) { drawCircle(p.text.copy(alpha = 0.10f), radius = 1.2.dp.toPx(), center = Offset(x, y)); y += step }; x += step }
            }
            "lines" -> {
                var y = 0f; while (y < size.height) { drawLine(p.line, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f); y += 28.dp.toPx() }
            }
        }
    }
}

/** .card — all nine materials + squircle-ish radii, exactly mapped. */
fun Modifier.dfCard(p: ThemePack): Modifier {
    val shape = RoundedCornerShape(maxOf(p.radius, 20.dp))
    var m = this.clip(shape)
    m = when (p.material) {
        Material.paper -> m.shadow(6.dp, shape).background(p.surface).border(1.dp, p.line, shape)
        Material.glass -> m.shadow(10.dp, shape)
            .background(p.surface.copy(alpha = 0.62f))
            .border(1.dp, if (p.dark) Color.White.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.35f), shape)
        Material.matte -> m.background(p.surface)
        Material.glossy -> m.shadow(4.dp, shape).background(Brush.verticalGradient(listOf(Color(1f, 1f, 1f, if (p.dark) 0.06f else 0.14f).compositeOver(p.surface), p.surface)))
        Material.clay -> m.background(p.surface).shadow(8.dp, shape, ambientColor = p.text.copy(alpha = 0.14f), spotColor = p.text.copy(alpha = 0.14f))
        Material.flat -> m.background(p.surface)
        Material.outlined -> m.border(1.5.dp, p.text.copy(alpha = 0.7f), shape)
        Material.blueprint -> m.background(p.surface.copy(alpha = 0.7f)).border(1.dp, p.text.copy(alpha = 0.55f), shape)
        Material.neon -> m.border(1.dp, p.accent.copy(alpha = 0.6f), shape).background(p.surface.copy(alpha = 0.85f))
    }
    return m
}

@Composable
fun DFCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val p = pack
    Box(
        modifier = modifier
            .dfCard(p)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick).semantics { role = Role.Button } else Modifier),
    ) { Column(content = content) }
}

@Composable
fun DFButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, variant: String = "primary", icon: (@Composable () -> Unit)? = null) {
    val p = pack
    val shape = RoundedCornerShape(14.dp)
    val colors = when (variant) {
        "primary" -> p.accent to p.onAccent
        "soft" -> p.soft to p.text
        else -> Color.Transparent to p.text
    }
    Row(
        modifier.heightIn(min = 42.dp).clip(shape)
            .background(colors.first)
            .then(if (variant == "ghost") Modifier.border(1.dp, p.line, shape) else Modifier)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center,
    ) {
        if (icon != null) { icon(); Spacer(Modifier.width(6.dp)) }
        Text(text, style = bodyStyle(14, FontWeight.SemiBold, colors.second))
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = pack
    Box(
        modifier.clip(CircleShape)
            .background(if (selected) p.accent else p.surface.copy(alpha = 0.7f))
            .then(if (!selected) Modifier.border(1.dp, p.line, CircleShape) else Modifier)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
    ) {
        Text(text, style = bodyStyle(12, FontWeight.SemiBold, if (selected) p.onAccent else p.text))
    }
}

/** iOS-style toggle from the design (44×26). */
@Composable
fun DFToggle(on: Boolean, onChange: (Boolean) -> Unit, label: String = "") {
    val p = pack
    Box(
        Modifier.size(44.dp, 26.dp).clip(CircleShape)
            .background(if (on) p.accent else p.line)
            .clickable { onChange(!on) }
            .semantics { role = Role.Switch },
    ) {
        Box(
            Modifier.padding(3.dp).size(20.dp).align(if (on) Alignment.CenterEnd else Alignment.CenterStart)
                .shadow(2.dp, CircleShape).background(Color.White),
        )
    }
}

@Composable
fun Segmented(options: List<Pair<String, String>>, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val p = pack
    Row(modifier.fillMaxWidth().clip(CircleShape).background(p.soft).padding(4.dp)) {
        options.forEach { (id, label) ->
            val sel = id == value
            Box(
                Modifier.weight(1f).clip(CircleShape)
                    .background(if (sel) p.surface else Color.Transparent)
                    .clickable { onChange(id) }.padding(vertical = 8.dp),
                contentAlignment = Alignment.Center,
            ) { Text(label, style = bodyStyle(13, if (sel) FontWeight.Bold else FontWeight.SemiBold, p.text.copy(alpha = if (sel) 1f else 0.7f))) }
        }
    }
}

@Composable
fun ScreenHeader(title: String, subtitle: String? = null, onBack: (() -> Unit)? = null, right: (@Composable RowScope.() -> Unit)? = null) {
    val p = pack
    Row(
        Modifier.fillMaxWidth().background(p.bg.copy(alpha = 0.82f)).padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(if (LocalLayoutDirection.current == LayoutDirection.Rtl) Icons.AutoMirrored.Filled.KeyboardArrowRight else Icons.AutoMirrored.Filled.KeyboardArrowLeft, "back", tint = p.text) }
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = bodyStyle(20, FontWeight.Bold))
            if (subtitle != null) Text(subtitle, style = bodyStyle(12, color = p.muted), maxLines = 1)
        }
        if (right != null) Row(content = right)
    }
}

/** iOS-style grouped list card. Rows opt into hairline separators with [GroupDivider]. */
@Composable
fun Group(title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.padding(vertical = 6.dp)) {
        if (title != null) Text(title, style = bodyStyle(12, FontWeight.SemiBold, pack.muted), modifier = Modifier.padding(start = 4.dp, bottom = 6.dp))
        Column(Modifier.fillMaxWidth().dfCard(pack), content = content)
    }
}

@Composable
fun GroupDivider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(pack.line))
}

@Composable
fun RowItem(title: String, hint: String? = null, icon: (@Composable () -> Unit)? = null, right: (@Composable () -> Unit)? = null, onClick: (() -> Unit)? = null) {
    val p = pack
    Row(
        Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(p.soft), contentAlignment = Alignment.Center) {
                CompositionLocalProvider(LocalContentColor provides p.accent) { icon() }
            }
            Spacer(Modifier.width(10.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = bodyStyle(15, FontWeight.Medium))
            if (hint != null) Text(hint, style = bodyStyle(12, color = p.muted))
        }
        if (right != null) right()
        else if (onClick != null) Icon(
            if (LocalLayoutDirection.current == LayoutDirection.Rtl) Icons.AutoMirrored.Filled.KeyboardArrowLeft else Icons.AutoMirrored.Filled.KeyboardArrowRight,
            null, tint = p.muted, modifier = Modifier.size(18.dp),
        )
    }
}

@Composable
fun Ring(value: Float, size: Dp = 58.dp, stroke: Dp = 7.dp, content: @Composable () -> Unit) {
    val p = pack
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = stroke.toPx()
            val inset = sw / 2
            drawArc(p.line, 0f, 360f, false, topLeft = Offset(inset, inset), size = Size(this.size.width - sw, this.size.height - sw), style = Stroke(sw, cap = androidx.compose.ui.graphics.StrokeCap.Round))
            drawArc(p.accent, -90f, 360f * value.coerceIn(0f, 1f), false, topLeft = Offset(inset, inset), size = Size(this.size.width - sw, this.size.height - sw), style = Stroke(sw, cap = androidx.compose.ui.graphics.StrokeCap.Round))
        }
        content()
    }
}

@Composable
fun DFSheet(open: Boolean, onClose: () -> Unit, title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    if (!open) return
    val p = pack
    ModalBottomSheet(
        onDismissRequest = onClose,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false),
        containerColor = p.surface, contentColor = p.text,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    ) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 36.dp)) {
            if (title != null) Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = bodyStyle(18, FontWeight.Bold), modifier = Modifier.weight(1f))
                IconButton(onClick = onClose, modifier = Modifier.clip(CircleShape).background(p.soft)) { Icon(Icons.Filled.Close, null, tint = p.text) }
            }
            content()
        }
    }
}

@Composable
fun Honest(text: String) {
    val p = pack
    Box(Modifier.fillMaxWidth().border(1.dp, p.line, RoundedCornerShape(12.dp)).padding(10.dp)) {
        Text(text, style = bodyStyle(12, color = p.muted), lineHeight = 18.sp)
    }
}

// ── Decoration helpers (HeaderCrown / corners / divider / empty state) ──

@Composable
fun MotifView(family: Family, size: Dp = 48.dp, mono: Color? = null, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        Patterns.run { drawMotif(family, this@Canvas.size.width / 2, this@Canvas.size.height / 2, this@Canvas.size.minDimension, mono) }
    }
}

@Composable
fun HeaderCrown(family: Family, height: Dp = 64.dp) {
    val c3 = Patterns.FAMILY[family]!!.c3
    Row(Modifier.fillMaxWidth().height(height), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        Box(Modifier.weight(1f).height(1.dp).background(Brush.horizontalGradient(listOf(Color.Transparent, c3.copy(alpha = 0.6f)))))
        MotifView(family, height * 0.36f, mono = c3, modifier = Modifier.alpha(0.55f))
        Spacer(Modifier.width(10.dp))
        MotifView(family, height * 0.72f, mono = c3)
        Spacer(Modifier.width(10.dp))
        MotifView(family, height * 0.36f, mono = c3, modifier = Modifier.alpha(0.55f))
        Box(Modifier.weight(1f).height(1.dp).background(Brush.horizontalGradient(listOf(c3.copy(alpha = 0.6f), Color.Transparent))))
    }
}

@Composable
fun DecorDivider(family: Family, modifier: Modifier = Modifier) {
    val st = Patterns.FAMILY[family]!!
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f).height(1.dp).background(Brush.horizontalGradient(listOf(Color.Transparent, st.c1))))
        Spacer(Modifier.width(8.dp)); MotifView(family, 22.dp); Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f).height(1.dp).background(Brush.horizontalGradient(listOf(st.c1, Color.Transparent))))
    }
}

@Composable
fun EmptyState(family: Family, title: String, hint: String? = null, action: (@Composable () -> Unit)? = null) {
    val st = Patterns.FAMILY[family]!!
    Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(112.dp).drawBehind {
                drawCircle(Brush.radialGradient(listOf(st.c3.copy(alpha = 0.6f), Color.Transparent)), radius = size.minDimension / 2)
            },
            contentAlignment = Alignment.Center,
        ) { MotifView(family, 74.dp) }
        Text(title, style = bodyStyle(15, FontWeight.SemiBold))
        if (hint != null) Text(hint, style = bodyStyle(13, color = pack.muted), modifier = Modifier.padding(top = 4.dp))
        if (action != null) { Spacer(Modifier.height(12.dp)); action() }
    }
}
