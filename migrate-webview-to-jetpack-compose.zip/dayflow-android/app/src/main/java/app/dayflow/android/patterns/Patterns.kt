package app.dayflow.android.patterns

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import app.dayflow.android.calendar.Calendars.Family
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Pattern engine — the same exact geometry (star tilings, snowflakes, waves, lotus, lantern, hearts) in Compose paths. */
object Patterns {

    data class FamilyStyle(val c1: Color, val c2: Color, val c3: Color, val en: String, val ar: String)

    val FAMILY: Map<Family, FamilyStyle> = mapOf(
        Family.ramadan to FamilyStyle(Color(0xffd4a237), Color(0xff1f4e5f), Color(0xfff3dfa2), "Ramadan lantern", "فانوس رمضان"),
        Family.islamic to FamilyStyle(Color(0xff1e7a5f), Color(0xffc9a24a), Color(0xffe8f1ea), "Islamic geometry", "هندسة إسلامية"),
        Family.eid to FamilyStyle(Color(0xffc8962c), Color(0xff7a2e5c), Color(0xfffbe8b8), "Eid festive", "زينة العيد"),
        Family.winter to FamilyStyle(Color(0xff7fb2d9), Color(0xff2f5a80), Color(0xffe8f3fb), "Winter crystal", "بلورات الشتاء"),
        Family.spring to FamilyStyle(Color(0xffe98aa6), Color(0xff5e9e4f), Color(0xfffde9ef), "Spring floral", "زهور الربيع"),
        Family.summer to FamilyStyle(Color(0xff2fa3c4), Color(0xfff2a541), Color(0xffe3f6fb), "Summer wave", "موج الصيف"),
        Family.autumn to FamilyStyle(Color(0xffc46a2f), Color(0xff8a5a2b), Color(0xfff8e6d4), "Autumn leaf", "أوراق الخريف"),
        Family.national to FamilyStyle(Color(0xffce1126), Color(0xffc09300), Color(0xfff5f5f5), "National ribbon", "شريط وطني"),
        Family.nile to FamilyStyle(Color(0xff2b6cb0), Color(0xff3aa17e), Color(0xffe5f0fa), "Nile lotus", "لوتس النيل"),
        Family.coptic to FamilyStyle(Color(0xff8b5a2b), Color(0xffb8860b), Color(0xfff6ecdc), "Coptic geometric", "زخرفة قبطية"),
        Family.love to FamilyStyle(Color(0xffd6456b), Color(0xfff08fa8), Color(0xfffde4ea), "Hearts", "قلوب"),
        Family.study to FamilyStyle(Color(0xff4f6bd8), Color(0xff7a8fe0), Color(0xffe8ecfb), "Study", "دراسة"),
        Family.birthday to FamilyStyle(Color(0xffe0a020), Color(0xffd6456b), Color(0xfffff2d6), "Birthday sparkle", "بريق الميلاد"),
        Family.friday to FamilyStyle(Color(0xff2e7d6b), Color(0xff9bc4b6), Color(0xffe6f2ee), "Friday accent", "لمسة الجمعة"),
        Family.newyear to FamilyStyle(Color(0xffc9a227), Color(0xff3b3f8f), Color(0xfff5efd9), "New Year", "العام الجديد"),
    )

    /** Deterministic PRNG (same mulberry32 as the web build). */
    fun mulberry32(seed0: Int): () -> Float {
        var seed = seed0
        return {
            seed = (seed + 0x6D2B79F5)
            var t = Math.imul(seed xor (seed ushr 15), 1 or seed)
            t = (t + Math.imul(t xor (t ushr 7), 61 or t)) xor t
            ((t xor (t ushr 14)) ushr 0).toFloat() / 4294967296f
        }
    }

    fun star(cx: Float, cy: Float, n: Int, ro: Float, ri: Float, rot: Float = (-PI / 2).toFloat()) = Path().apply {
        for (i in 0 until n * 2) {
            val r = if (i % 2 == 1) ri else ro
            val a = rot + i * PI.toFloat() / n
            val x = cx + r * cos(a); val y = cy + r * sin(a)
            if (i == 0) moveTo(x, y) else lineTo(x, y)
        }
        close()
    }

    fun polygon(cx: Float, cy: Float, n: Int, r: Float, rot: Float = 0f) = Path().apply {
        for (i in 0 until n) {
            val a = rot + i * 2 * PI.toFloat() / n
            val x = cx + r * cos(a); val y = cy + r * sin(a)
            if (i == 0) moveTo(x, y) else lineTo(x, y)
        }
        close()
    }

    fun snowflake(cx: Float, cy: Float, r: Float) = Path().apply {
        for (i in 0 until 6) {
            val a = i * PI.toFloat() / 3 - PI.toFloat() / 2
            moveTo(cx, cy); lineTo(cx + r * cos(a), cy + r * sin(a))
            for (t in listOf(0.45f, 0.72f)) {
                val bx = cx + r * t * cos(a); val by = cy + r * t * sin(a)
                val bl = r * (if (t == 0.45f) 0.3f else 0.2f)
                for (s in listOf(-1, 1)) {
                    val ba = a + s * PI.toFloat() / 4
                    moveTo(bx, by); lineTo(bx + bl * cos(ba), by + bl * sin(ba))
                }
            }
        }
    }

    fun lotus(cx: Float, cy: Float, r: Float, petals: Int = 5) = Path().apply {
        for (i in 0 until petals) {
            val a = -PI.toFloat() / 2 + (i - (petals - 1) / 2f) * PI.toFloat() / (petals + 1.2f)
            val tx = cx + r * cos(a); val ty = cy + r * sin(a)
            val w = r * 0.32f
            val nx = -sin(a) * w; val ny = cos(a) * w
            val mx = cx + r * 0.5f * cos(a); val my = cy + r * 0.5f * sin(a)
            moveTo(cx, cy); quadraticTo(mx + nx, my + ny, tx, ty); quadraticTo(mx - nx, my - ny, cx, cy); close()
        }
    }

    fun crescent(cx: Float, cy: Float, r: Float) = Path().apply {
        // arc-based crescent: outer arc then inner arc sweeping back
        val r2 = r * 0.82f
        moveTo(cx, cy - r)
        arcToRad(cx - r, cy - r, r, fromDeg = -90f, sweepDeg = -180f)
        arcToRad(cx - r2, cy - r2, r2, fromDeg = 90f, sweepDeg = 180f)
        close()
    }

    private fun Path.arcToRad(l: Float, t: Float, r: Float, fromDeg: Float, sweepDeg: Float) {
        val rect = androidx.compose.ui.geometry.Rect(l, t, l + 2 * r, t + 2 * r)
        arcTo(rect, fromDeg, sweepDeg, false)
    }

    fun lantern(cx: Float, top: Float, s: Float): List<Path> = listOf(
        Path().apply { moveTo(cx, top); lineTo(cx + s * 0.18f, top + s * 0.22f); lineTo(cx - s * 0.18f, top + s * 0.22f); close() },
        Path().apply {
            moveTo(cx - s * 0.3f, top + s * 0.24f); lineTo(cx + s * 0.3f, top + s * 0.24f)
            lineTo(cx + s * 0.38f, top + s * 0.55f); lineTo(cx + s * 0.22f, top + s * 0.9f)
            lineTo(cx - s * 0.22f, top + s * 0.9f); lineTo(cx - s * 0.38f, top + s * 0.55f); close()
        },
        Path().apply { moveTo(cx - s * 0.16f, top + s * 0.92f); lineTo(cx + s * 0.16f, top + s * 0.92f); lineTo(cx, top + s * 1.05f); close() },
    )

    fun heart(cx: Float, cy: Float, s: Float) = Path().apply {
        moveTo(cx, cy + s * 0.35f)
        cubicTo(cx - s * 0.9f, cy - s * 0.2f, cx - s * 0.35f, cy - s * 0.75f, cx, cy - s * 0.3f)
        cubicTo(cx + s * 0.35f, cy - s * 0.75f, cx + s * 0.9f, cy - s * 0.2f, cx, cy + s * 0.35f)
        close()
    }

    fun leaf(cx: Float, cy: Float, s: Float, a: Float = 0f) = Path().apply {
        val c = cos(a); val si = sin(a)
        fun p(x: Float, y: Float) = cx + x * c - y * si to (cy + x * si + y * c)
        val (t, b) = p(0f, -s) to p(0f, s)
        val (r, l) = p(s * 0.6f, 0f) to p(-s * 0.6f, 0f)
        moveTo(t.first, t.second); quadraticTo(r.first, r.second, b.first, b.second)
        quadraticTo(l.first, l.second, t.first, t.second); close()
        moveTo(t.first, t.second); lineTo(b.first, b.second)
    }

    /** Sakura petal: two-lobed petal with a notch — part of the new realistic spring set. */
    fun petal(cx: Float, cy: Float, s: Float, rot: Float) = Path().apply {
        val c = cos(rot); val si = sin(rot)
        fun p(x: Float, y: Float) = cx + x * c - y * si to (cy + x * si + y * c)
        val top = p(0f, -s); val left = p(-s * 0.5f, -s * 0.15f); val right = p(s * 0.5f, -s * 0.15f); val bottom = p(0f, s * 0.9f)
        moveTo(top.first, top.second)
        quadraticTo(left.first, left.second, bottom.first, bottom.second)
        quadraticTo(right.first, right.second, top.first, top.second)
        close()
    }

    fun sparkle(cx: Float, cy: Float, s: Float) = star(cx, cy, 4, s, s * 0.22f)

    /** Motif fill/stroke paths for a family (same geometry as the web motif()). */
    data class Motif(val fills: List<Path>, val strokes: List<Path>, val flagStripe: Boolean = false)

    fun motif(f: Family, cx: Float, cy: Float, s: Float): Motif = when (f) {
        Family.ramadan -> Motif(listOf(crescent(cx - s * 0.15f, cy, s * 0.42f)), lantern(cx + s * 0.28f, cy - s * 0.45f, s * 0.7f))
        Family.islamic, Family.friday -> Motif(emptyList(), listOf(
            star(cx, cy, if (f == Family.friday) 6 else 8, s * 0.46f, s * 0.46f * 0.62f),
            polygon(cx, cy, if (f == Family.friday) 6 else 8, s * 0.45f, PI.toFloat() / (if (f == Family.friday) 6 else 8)),
            star(cx, cy, if (f == Family.friday) 6 else 8, s * 0.23f, s * 0.147f),
        ))
        Family.eid -> Motif(listOf(star(cx, cy, 8, s * 0.45f, s * 0.22f)), listOf(polygon(cx, cy, 8, s * 0.3f, PI.toFloat() / 8)))
        Family.winter -> Motif(emptyList(), listOf(snowflake(cx, cy, s * 0.45f)))
        Family.spring -> Motif(listOf(lotus(cx, cy + s * 0.25f, s * 0.55f, 6)), emptyList())
        Family.nile -> Motif(listOf(lotus(cx, cy + s * 0.15f, s * 0.5f, 5)), listOf(wave(s, s * 0.05f, 2, 0f, cy + s * 0.3f, cx - s / 2)))
        Family.summer -> Motif(emptyList(), (0..2).map { i -> wave(s, s * 0.07f, 1.5f, i.toFloat(), s * 0.3f + i * s * 0.18f + cy - s / 2, cx - s / 2) })
        Family.autumn -> Motif(listOf(leaf(cx, cy, s * 0.42f, 0.6f)), emptyList())
        Family.national -> Motif(emptyList(), listOf(Path().apply {
            moveTo(cx - s * 0.45f, cy + s * 0.2f)
            cubicTo(cx - s * 0.15f, cy - s * 0.4f, cx + s * 0.15f, cy + s * 0.4f, cx + s * 0.45f, cy - s * 0.2f)
        }), flagStripe = true)
        Family.coptic -> Motif(emptyList(), listOf(Path().apply {
            moveTo(cx, cy - s * 0.42f); lineTo(cx, cy + s * 0.42f)
            moveTo(cx - s * 0.42f, cy); lineTo(cx + s * 0.42f, cy)
        }, polygon(cx, cy, 4, s * 0.3f, PI.toFloat() / 4)) + (0..3).map { i ->
            polygon(cx + cos(i * PI.toFloat() / 2) * s * 0.42f, cy + sin(i * PI.toFloat() / 2) * s * 0.42f, 4, s * 0.07f, PI.toFloat() / 4)
        })
        Family.love -> Motif(listOf(heart(cx, cy, s * 0.55f)), emptyList())
        Family.study -> Motif(emptyList(), listOf(Path().apply {
            moveTo(cx - s * 0.4f, cy - s * 0.25f); lineTo(cx, cy - s * 0.1f); lineTo(cx + s * 0.4f, cy - s * 0.25f)
            lineTo(cx + s * 0.4f, cy + s * 0.3f); lineTo(cx, cy + s * 0.45f); lineTo(cx - s * 0.4f, cy + s * 0.3f); close()
            moveTo(cx, cy - s * 0.1f); lineTo(cx, cy + s * 0.45f)
        }))
        Family.birthday, Family.newyear -> Motif(listOf(
            sparkle(cx, cy, s * 0.4f), sparkle(cx + s * 0.32f, cy - s * 0.3f, s * 0.14f), sparkle(cx - s * 0.32f, cy + s * 0.28f, s * 0.1f),
        ), emptyList())
    }

    private fun wave(w: Float, amp: Float, periods: Float, phase: Float, y0: Float, x0: Float) = Path().apply {
        moveTo(x0, y0)
        for (i in 1..48) {
            val x = x0 + i / 48f * w
            lineTo(x, y0 + amp * sin(phase + i / 48f * periods * 2 * PI.toFloat()))
        }
    }

    /** Draws a family motif with its two-tone palette (or a single ink when mono != null). */
    fun DrawScope.drawMotif(f: Family, cx: Float, cy: Float, s: Float, mono: Color? = null) {
        val st = FAMILY[f]
        val m = motif(f, cx, cy, s)
        m.fills.forEachIndexed { i, p -> drawPath(p, mono ?: if (i % 2 == 1) st.c2 else st.c1, alpha = 0.92f) }
        m.strokes.forEachIndexed { i, p ->
            drawPath(p, mono ?: if (i % 2 == 1) st.c1 else st.c2, style = Stroke(width = if (f == Family.national) s * 0.07f else s * 0.03f, cap = androidx.compose.ui.graphics.StrokeCap.Round))
        }
        if (f == Family.national && mono == null) {
            val base = m.strokes.first()
            drawPath(base, Color.White, style = Stroke(width = s * 0.04f, cap = androidx.compose.ui.graphics.StrokeCap.Round), alpha = 0.9f)
        }
    }
}
