package app.dayflow.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.data.DlItem
import app.dayflow.android.data.Store
import app.dayflow.android.download.DownloadService
import app.dayflow.android.download.LinkAnalyzer
import app.dayflow.android.download.fmtBytes
import app.dayflow.android.ui.Chip
import app.dayflow.android.ui.DFButton
import app.dayflow.android.ui.DFCard
import app.dayflow.android.ui.DFToggle
import app.dayflow.android.ui.Honest
import app.dayflow.android.ui.ScreenHeader
import app.dayflow.android.ui.Segmented
import app.dayflow.android.ui.bodyStyle
import app.dayflow.android.ui.pack
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

/** Downloads — native analyze with real previews (Open Graph / oEmbed / HEAD), no CORS wall. */
@Composable
fun DownloadsScreen(sharedLink: String?) {
    val s by Store.state.collectAsState()
    val lang = s.lang
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }
    var an by remember { mutableStateOf<LinkAnalyzer.Analysis?>(null) }
    var pick by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("all") }
    var q by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var cfg by remember { mutableStateOf(false) }

    fun analyze(raw: String) {
        val u = LinkAnalyzer.extractUrls(raw).firstOrNull() ?: raw.trim()
        if (u.isBlank()) return
        url = u; busy = true; err = ""; an = null; msg = ""
        scope.launch {
            runCatching { LinkAnalyzer.analyze(u) }
                .onSuccess { an = it; pick = it.formats.firstOrNull()?.id ?: "" }
                .onFailure { err = it.message?.let { m -> if (m.contains("invalid")) "ده مش رابط صحيح." else m.take(140) } ?: "تعذر التحليل" }
            busy = false
        }
    }

    LaunchedEffect(sharedLink) { if (!sharedLink.isNullOrBlank()) analyze(sharedLink) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = if (lang == "ar") "التحميل" else "Downloads",
            subtitle = "${s.downloads.size} ${if (lang == "ar") "عنصر" else "items"} · ${fmtBytes(s.downloads.filter { it.state == "completed" }.sumOf { it.size })}",
            right = { IconButton(onClick = { cfg = true }) { Icon(Icons.Filled.Settings, null, tint = pack.text) } },
        )

        DFCard {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = url, onValueChange = { url = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text(if (lang == "ar") "الصق الرابط…" else "Paste a link…") },
                        singleLine = true,
                        trailingIcon = { if (url.isNotBlank()) Icon(Icons.Filled.Close, null, tint = pack.muted, modifier = Modifier.size(16.dp).clickable { url = ""; an = null; err = "" }) },
                    )
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(pack.soft).clickable {
                        clip.getText()?.text?.let { analyze(it) }
                    }, contentAlignment = Alignment.Center) { Icon(Icons.Filled.ContentPaste, null, tint = pack.text) }
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(pack.accent).clickable(enabled = !busy && url.isNotBlank()) { analyze(url) }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.Search, null, tint = pack.onAccent)
                    }
                }
                if (busy) Text(if (lang == "ar") "بنحلّل الرابط فعليًا…" else "Analyzing for real…", style = bodyStyle(12, color = pack.muted), modifier = Modifier.padding(top = 6.dp))
                if (err.isNotBlank()) Text(err, color = Color(0xffd32f2f), style = bodyStyle(12), modifier = Modifier.padding(top = 6.dp))
                if (msg.isNotBlank()) Text(msg, color = pack.accent, style = bodyStyle(12), modifier = Modifier.padding(top = 6.dp))

                an?.let { a ->
                    Spacer(Modifier.height(12.dp))
                    Row {
                        if (a.thumb != null) {
                            AsyncImage(model = a.thumb, contentDescription = null, modifier = Modifier.width(128.dp).height(80.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
                            Spacer(Modifier.width(10.dp))
                        }
                        Column(Modifier.weight(1f)) {
                            Text(a.title, style = bodyStyle(14, FontWeight.Bold), maxLines = 2)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Shield, null, tint = if (a.secure) pack.accent else Color(0xffd9822b), modifier = Modifier.size(11.dp)); Spacer(Modifier.width(4.dp))
                                Text(a.host + (a.mime?.let { " · $it" } ?: ""), style = bodyStyle(11, color = pack.muted), maxLines = 1)
                            }
                            a.author?.let { Text(it, style = bodyStyle(11, color = pack.muted)) }
                            Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                a.size?.let { Chip(fmtBytes(it), false) {} }
                                a.duration?.let { Chip(fmtDur(it), false) {} }
                                if (a.rangeOk) Chip(if (lang == "ar") "بيكمّل" else "Resumable", false) {}
                            }
                        }
                    }
                    a.description?.let { Text(it, style = bodyStyle(12, color = pack.muted), maxLines = 3, modifier = Modifier.padding(top = 6.dp)) }
                    a.note?.let { Spacer(Modifier.height(8.dp)); Honest(it) }
                    if (a.formats.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        a.formats.forEach { f ->
                            val sel = pick == f.id
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(12.dp))
                                    .background(if (sel) pack.soft else Color.Transparent)
                                    .clickable { pick = f.id }.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(Icons.Filled.MusicNote, null, tint = pack.accent, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(f.label, style = bodyStyle(12, FontWeight.Bold))
                                Spacer(Modifier.width(6.dp))
                                Text(f.detail, style = bodyStyle(11, color = pack.muted), modifier = Modifier.weight(1f), maxLines = 1)
                                f.size?.let { Text(fmtBytes(it), style = bodyStyle(11, color = pack.muted)) }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        DFButton(if (lang == "ar") "تحميل" else "Download", {
                            val f = a.formats.find { it.id == pick }
                            val id = Store.newId()
                            Store.upsertDl(
                                DlItem(
                                    id = id, url = a.url, name = a.filename, kind = a.kind.name.lowercase(), host = a.host, site = a.site,
                                    secure = a.secure, thumb = a.thumb, quality = f?.label, format = f?.id, variantUrl = f?.url,
                                    size = f?.size ?: a.size ?: 0, state = "queued", mime = a.mime, resumable = a.rangeOk, addedAt = System.currentTimeMillis(),
                                ),
                            )
                            DownloadService.start(ctx, id)
                            an = null; url = ""; msg = if (lang == "ar") "اتضافت للطابور — يُحمّل فعليًا في الخلفية." else "Queued — downloading natively."
                        }, Modifier.fillMaxWidth(), icon = { Icon(Icons.Filled.Download, null, tint = pack.onAccent, modifier = Modifier.size(16.dp)) })
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = q, onValueChange = { q = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text(if (lang == "ar") "ابحث في التنزيلات" else "Search downloads") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(listOf("all" to "الكل", "downloading" to "نشط", "queued" to "انتظار", "paused" to "متوقف", "completed" to "تم", "failed" to "فشل")) { (id, labelAr) ->
                val c = s.downloads.count { id == "all" || it.state == id || (id == "failed" && it.state == "cancelled") }
                Chip("$labelAr ${app.dayflow.android.time.TimeFmt.num(c, lang)}", filter == id) { filter = id }
            }
        }
        Spacer(Modifier.height(10.dp))

        val shown = s.downloads
            .filter { filter == "all" || it.state == filter || (filter == "failed" && it.state == "cancelled") }
            .filter { q.isBlank() || (it.name + it.host + it.url).contains(q, true) }
            .sortedByDescending { it.addedAt }
        if (shown.isEmpty()) {
            DFCard { Text(if (lang == "ar") "لسه مفيش حاجة. الصق رابط أو شاركه من أي تطبيق." else "Nothing here yet. Paste or share a link to start.", style = bodyStyle(13, color = pack.muted), modifier = Modifier.padding(24.dp).fillMaxSize()) }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
            items(shown, key = { it.id }) { i ->
                DlCard(i, lang) { id, act ->
                    when (act) {
                        "pause" -> ctx.startService(android.content.Intent(ctx, DownloadService::class.java).setAction(DownloadService.ACTION_PAUSE).putExtra(DownloadService.EXTRA_ID, id))
                        "resume" -> { Store.patchDl(id) { x -> x.copy(state = "queued", error = null) }; DownloadService.start(ctx, id) }
                        "retry" -> { Store.patchDl(id) { x -> x.copy(state = "queued", error = null, notices = emptyList()) }; DownloadService.start(ctx, id) }
                        "cancel" -> ctx.startService(android.content.Intent(ctx, DownloadService::class.java).setAction(DownloadService.ACTION_CANCEL).putExtra(DownloadService.EXTRA_ID, id))
                        "delete" -> Store.removeDl(id)
                    }
                }
            }
        }
    }

    if (cfg) {
        app.dayflow.android.ui.DFSheet(open = true, onClose = { cfg = false }, title = if (lang == "ar") "إعدادات التحميل" else "Download settings") {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                // kept faithful: honest note instead of fabricated engine toggles
                Text(if (lang == "ar") "المحرك" else "Engine", style = bodyStyle(13, FontWeight.Bold))
                Text(if (lang == "ar") "٦ اتصالات Range متوازية · حفظ تلقائي في Downloads/DayFlow · استكمال بعد الإغلاق" else "6 parallel Range connections · auto-save to Downloads/DayFlow · resume across restarts", style = bodyStyle(12, color = pack.muted))
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (lang == "ar") "استئناف تلقائي عند فتح التطبيق" else "Auto-resume on app open", Modifier.weight(1f), style = bodyStyle(13))
                    DFToggle(on = true, onChange = { })
                }
                Spacer(Modifier.height(6.dp))
                Honest(if (lang == "ar") "التحميل هنا أصلي (OkHttp متعدد المسارات) ولا يمرّ بأي WebView — لا توجد جدار CORS في أندرويد." else "Downloads here are native (multi-part OkHttp) — there is no CORS wall on Android.")
            }
        }
    }
}

@Composable
fun DlCard(i: DlItem, lang: String, act: (String, String) -> Unit) {
    val p = pack
    val pct = if (i.size > 0) (i.got * 100f / i.size).coerceIn(0f, 100f) else if (i.state == "completed") 100f else 0f
    DFCard {
        Column(Modifier.padding(12.dp)) {
            Row {
                if (i.thumb != null) AsyncImage(model = i.thumb, contentDescription = null, modifier = Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
                else Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(p.soft), contentAlignment = Alignment.Center) { Icon(Icons.Filled.Download, null, tint = p.accent) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(i.name, style = bodyStyle(13, FontWeight.Bold), maxLines = 1)
                    Text("${i.host} · ${stateLabel(i.state, lang)}", style = bodyStyle(11, color = p.muted))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        i.quality?.let { Chip(it, false) {} }
                        if (i.resumable) Chip(if (lang == "ar") "بيكمّل" else "resumable", false) {}
                    }
                }
            }
            if (i.state == "downloading" || i.state == "paused" || i.state == "queued") {
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(p.line)) {
                    Box(Modifier.fillMaxWidth(pct / 100f).height(6.dp).clip(CircleShape).background(p.accent))
                }
                Spacer(Modifier.height(4.dp))
                Text("${fmtBytes(i.got)}${if (i.size > 0) " / ${fmtBytes(i.size)}" else ""} · ${pct.toInt()}%", style = bodyStyle(11, color = p.muted))
            }
            if (i.state == "completed") Text("${fmtBytes(i.size)} · Downloads/DayFlow", style = bodyStyle(11, color = p.muted), modifier = Modifier.padding(top = 4.dp))
            i.error?.let { Text(it, color = Color(0xffd32f2f), style = bodyStyle(11), modifier = Modifier.padding(top = 4.dp)) }
            Spacer(Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (i.state == "downloading") item { ActionChip("إيقاف مؤقت", Icons.Filled.Pause) { act(i.id, "pause") } }
                if (i.state == "paused" || i.state == "queued") item { ActionChip("استكمال", Icons.Filled.PlayArrow) { act(i.id, "resume") } }
                if (i.state == "failed" || i.state == "cancelled") item { ActionChip("إعادة", Icons.Filled.Refresh) { act(i.id, "retry") } }
                if (i.state == "downloading" || i.state == "queued" || i.state == "paused") item { ActionChip("إلغاء", Icons.Filled.Close) { act(i.id, "cancel") } }
                item { ActionChip("حذف", Icons.Filled.Close) { act(i.id, "delete") } }
            }
        }
    }
}

@Composable
fun ActionChip(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Box(Modifier.clip(CircleShape).background(pack.soft).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = pack.text, modifier = Modifier.size(12.dp)); Spacer(Modifier.width(4.dp)); Text(label, style = bodyStyle(11, FontWeight.SemiBold)) }
    }
}

private fun stateLabel(s: String, lang: String) = when (s) {
    "queued" -> "في الانتظار"; "downloading" -> "بيتحمّل"; "paused" -> "متوقف"
    "completed" -> "اكتمل"; "failed" -> "فشل"; "cancelled" -> "اتلغى"; else -> s
}

private fun fmtDur(sec: Int): String =
    if (sec < 60) "${sec}s" else if (sec < 3600) "${sec / 60}m ${sec % 60}s" else "${sec / 3600}h ${(sec % 3600) / 60}m"
