package app.dayflow.android.ui.theme

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.dayflow.android.calendar.Calendars.Family

/** Exact port of the 60-pack theme registry (colors, material, shape, font, motion, texture). */
enum class Material { paper, glass, matte, glossy, clay, flat, outlined, blueprint, neon }
enum class PackFont { sans, serif, mono, rounded, condensed }

data class ThemePack(
    val id: String, val en: String, val ar: String, val cat: String, val dark: Boolean,
    val bg: Color, val surface: Color, val text: Color, val accent: Color, val accent2: Color,
    val material: Material, val radius: Dp, val font: PackFont,
    val durMs: Int, val ease: Easing, val texture: String, val ornament: Family,
) {
    val onAccent: Color get() = if (luminance(accent) > 0.45) Color(0xFF111111) else Color.White
    val muted: Color get() = text.copy(alpha = 0.58f)
    val line: Color get() = text.copy(alpha = 0.11f)
    val soft: Color get() = accent.copy(alpha = 0.12f).compositeOver(surface)
}

private fun luminance(c: Color): Float {
    fun ch(v: Float) = if (v <= 0.03928f) v / 12.92f else Math.pow(((v + 0.055f) / 1.055f), 2.4).toFloat()
    return 0.2126f * ch(c.red) + 0.7152f * ch(c.green) + 0.0722f * ch(c.blue)
}

private val CALM = CubicBezierEasing(0.2f, 0.7f, 0.2f, 1f)
private val SPRINGY = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f)
private val SNAPPY = CubicBezierEasing(0.2f, 0f, 0f, 1f)

private fun radius(shape: String) = when (shape) { "squircle" -> 26.dp; "chamfer" -> 4.dp; "sharp" -> 2.dp; else -> 18.dp }
private fun motion(m: String) = when (m) { "springy" -> 520 to SPRINGY; "snappy" -> 160 to SNAPPY; "none" -> 1 to CALM; else -> 420 to CALM }

private data class Row(
    val en: String, val ar: String, val cat: String, val dark: Boolean,
    val bg: Long, val surface: Long, val text: Long, val accent: Long, val accent2: Long,
    val material: Material, val shape: String, val font: PackFont, val motion: String, val texture: String, val ornament: Family,
)

private val ROWS = listOf(
    Row("Paper White", "ورق أبيض", "light", false, 0xfff7f5f0, 0xffffffff, 0xff1d1c1a, 0xff2f6f5e, 0xffc9a24a, Material.paper, "round", PackFont.serif, "calm", "grain", Family.islamic),
    Row("Ivory Journal", "دفتر عاجي", "light", false, 0xfff4eddc, 0xfffbf7ec, 0xff2b2418, 0xff8a5a2b, 0xff5c7a4d, Material.paper, "sharp", PackFont.serif, "calm", "lines", Family.coptic),
    Row("Linen", "كتان", "light", false, 0xffefe9e1, 0xfff8f4ee, 0xff2d2a26, 0xff7b6a58, 0xffa0805d, Material.matte, "squircle", PackFont.sans, "calm", "grain", Family.spring),
    Row("Silver Mist", "ضباب فضي", "light", false, 0xffe9edf1, 0xfff6f8fa, 0xff1c2530, 0xff4a6a8a, 0xff8aa0b6, Material.glass, "round", PackFont.sans, "calm", "mesh", Family.winter),
    Row("Arctic", "قطبي", "light", false, 0xffeaf4f8, 0xffffffff, 0xff0e2a36, 0xff1b8bb4, 0xff7cc6dd, Material.flat, "squircle", PackFont.rounded, "snappy", "none", Family.winter),
    Row("Porcelain", "بورسلين", "light", false, 0xfff3f4f7, 0xffffffff, 0xff20232b, 0xff3c5ccf, 0xffd64f7a, Material.glossy, "round", PackFont.sans, "springy", "none", Family.spring),
    Row("Newsprint", "ورق الصحف", "light", false, 0xffecebe6, 0xfff6f5f1, 0xff111111, 0xff111111, 0xffb3261e, Material.outlined, "sharp", PackFont.serif, "none", "lines", Family.islamic),
    Row("Library", "مكتبة", "light", false, 0xffe8e1d3, 0xfff4efe4, 0xff2a2016, 0xff6b2d2d, 0xff2f5a45, Material.paper, "chamfer", PackFont.serif, "calm", "grain", Family.coptic),
    Row("Midnight", "منتصف الليل", "dark", true, 0xff0d1220, 0xff161d30, 0xffe6e9f2, 0xff7aa2ff, 0xffc9a24a, Material.matte, "round", PackFont.sans, "calm", "dots", Family.islamic),
    Row("Graphite", "جرافيت", "dark", true, 0xff1a1b1e, 0xff24262a, 0xffececec, 0xff9fb4c7, 0xffd1a35c, Material.matte, "squircle", PackFont.sans, "snappy", "none", Family.winter),
    Row("AMOLED Black", "أسود أموليد", "dark", true, 0xff000000, 0xff0b0b0b, 0xfff2f2f2, 0xff4fd1c5, 0xfff6ad55, Material.flat, "round", PackFont.sans, "snappy", "none", Family.friday),
    Row("Obsidian", "سبج", "dark", true, 0xff0f0e12, 0xff1b1920, 0xffece8f4, 0xffb392f0, 0xff5ad1a8, Material.glossy, "chamfer", PackFont.sans, "springy", "none", Family.islamic),
    Row("Slate", "أردواز", "dark", true, 0xff1c232b, 0xff26303a, 0xffe3e9ef, 0xff5fb3b3, 0xffe0b45c, Material.matte, "squircle", PackFont.condensed, "calm", "lines", Family.nile),
    Row("Deep Ink", "حبر عميق", "dark", true, 0xff0b1530, 0xff13204a, 0xffe5ebff, 0xfff0c24b, 0xff76a6ff, Material.paper, "round", PackFont.serif, "calm", "grain", Family.ramadan),
    Row("Carbon", "كربون", "dark", true, 0xff121314, 0xff1d1f21, 0xffe8e8e8, 0xffff6b4a, 0xff9aa5b1, Material.outlined, "sharp", PackFont.mono, "snappy", "grid", Family.national),
    Row("Nile Blue", "أزرق النيل", "egypt", false, 0xffe7f0f8, 0xfff7fbff, 0xff0f2742, 0xff1f5fa8, 0xff2fa37e, Material.glass, "round", PackFont.sans, "calm", "pattern", Family.nile),
    Row("Desert Gold", "ذهب الصحراء", "egypt", false, 0xfff3e7cf, 0xfffbf4e4, 0xff3a2a12, 0xffb07d1e, 0xff7a4a1d, Material.paper, "chamfer", PackFont.serif, "calm", "grain", Family.coptic),
    Row("Pharaonic Teal & Gold", "فيروزي وذهبي فرعوني", "egypt", true, 0xff0c2b2e, 0xff123a3e, 0xfff3e9cc, 0xffd4a83a, 0xff3fb3a4, Material.glossy, "chamfer", PackFont.serif, "calm", "pattern", Family.nile),
    Row("Cairo Night", "ليل القاهرة", "egypt", true, 0xff120f1c, 0xff1d1830, 0xfff1e8d6, 0xffe7b04a, 0xff8f7bd8, Material.glass, "squircle", PackFont.sans, "springy", "pattern", Family.islamic),
    Row("Khan El-Khalili", "خان الخليلي", "egypt", true, 0xff2a160c, 0xff3a2014, 0xfff6e6cc, 0xffe39b2b, 0xff2c8c7a, Material.clay, "chamfer", PackFont.serif, "calm", "pattern", Family.ramadan),
    Row("Luxor Dawn", "فجر الأقصر", "egypt", false, 0xfffbe9da, 0xfffff6ee, 0xff3b2318, 0xffd2693c, 0xffc9a24a, Material.glass, "round", PackFont.serif, "calm", "mesh", Family.nile),
    Row("Aswan Sunset", "غروب أسوان", "egypt", true, 0xff2b1420, 0xff3b1c2c, 0xfffbe6dc, 0xffff8a5b, 0xffffc46b, Material.glossy, "round", PackFont.sans, "springy", "mesh", Family.nile),
    Row("Siwa Oasis", "واحة سيوة", "egypt", false, 0xffefe6d2, 0xfffaf5ea, 0xff2f2a1b, 0xff5b8a3c, 0xffc48a3a, Material.clay, "squircle", PackFont.rounded, "calm", "grain", Family.spring),
    Row("Alexandria Corniche", "كورنيش الإسكندرية", "egypt", false, 0xffe3f1f6, 0xfff7fcfe, 0xff0b2c3a, 0xff167ea3, 0xffe3a64a, Material.flat, "round", PackFont.sans, "springy", "lines", Family.summer),
    Row("Sinai Granite", "جرانيت سيناء", "egypt", true, 0xff231d1d, 0xff302828, 0xffeee3df, 0xffd07a5a, 0xff9db0a6, Material.matte, "chamfer", PackFont.condensed, "calm", "grain", Family.national),
    Row("Red Sea Reef", "شعاب البحر الأحمر", "egypt", true, 0xff04263a, 0xff06344f, 0xffe2f6fb, 0xffff7f6b, 0xff3fd3c3, Material.glass, "round", PackFont.rounded, "springy", "mesh", Family.summer),
    Row("Papyrus", "بردي", "egypt", false, 0xffece0bf, 0xfff6eed6, 0xff33291a, 0xff6f6230, 0xffa1442a, Material.paper, "sharp", PackFont.serif, "none", "lines", Family.nile),
    Row("Delta Green", "أخضر الدلتا", "egypt", false, 0xffe5efe0, 0xfff5faf2, 0xff1c2d18, 0xff3f7f33, 0xffb8932f, Material.matte, "round", PackFont.sans, "calm", "grain", Family.spring),
    Row("Ramadan Lantern", "فانوس رمضان", "islamic", true, 0xff0f1f2b, 0xff172d3d, 0xfff6ecd2, 0xffe1a93b, 0xff4fb39a, Material.glass, "squircle", PackFont.serif, "calm", "pattern", Family.ramadan),
    Row("Mamluk Geometry", "هندسة مملوكية", "islamic", false, 0xffefe5d3, 0xfffaf3e6, 0xff2a1d10, 0xff9b3b1f, 0xff1d5a6e, Material.paper, "chamfer", PackFont.serif, "calm", "pattern", Family.islamic),
    Row("Andalusian Tile", "زليج أندلسي", "islamic", false, 0xffe8f0f3, 0xffffffff, 0xff132a33, 0xff1b6f8a, 0xffc78a2b, Material.glossy, "chamfer", PackFont.serif, "springy", "pattern", Family.islamic),
    Row("Mihrab", "محراب", "islamic", true, 0xff1a1410, 0xff2a2018, 0xfff3e7d0, 0xffc99a45, 0xff6fa38a, Material.clay, "round", PackFont.serif, "calm", "pattern", Family.islamic),
    Row("Arabesque Emerald", "أرابيسك زمردي", "islamic", true, 0xff06221b, 0xff0c3128, 0xffe5f4ec, 0xffd7b65a, 0xff3cc18f, Material.glossy, "squircle", PackFont.serif, "calm", "pattern", Family.islamic),
    Row("Zellige", "زليج", "islamic", false, 0xffe5f2ee, 0xfffbfffd, 0xff0f2a24, 0xff167a63, 0xff2d5fa8, Material.outlined, "chamfer", PackFont.sans, "snappy", "pattern", Family.friday),
    Row("Muqarnas Night", "مقرنصات الليل", "islamic", true, 0xff101326, 0xff191d38, 0xffece9fb, 0xffd9b25f, 0xff7f8cff, Material.glass, "chamfer", PackFont.serif, "calm", "pattern", Family.ramadan),
    Row("Sage", "مريمية", "nature", false, 0xffe9eee6, 0xfff6f9f4, 0xff1f2a1e, 0xff5d7f5a, 0xffb49a6a, Material.matte, "squircle", PackFont.rounded, "calm", "grain", Family.spring),
    Row("Forest", "غابة", "nature", true, 0xff0f1d16, 0xff173026, 0xffe2efe5, 0xff6fc28b, 0xffd9b46a, Material.matte, "round", PackFont.sans, "calm", "grain", Family.autumn),
    Row("Mint Fresh", "نعناع منعش", "nature", false, 0xffe6f7f1, 0xffffffff, 0xff103028, 0xff14a37f, 0xffff8c6b, Material.flat, "round", PackFont.rounded, "springy", "dots", Family.spring),
    Row("Rain", "مطر", "nature", true, 0xff141c24, 0xff1d2833, 0xffdfe8f0, 0xff6fa8dc, 0xff9fc5e8, Material.glass, "round", PackFont.sans, "calm", "lines", Family.winter),
    Row("Dune", "كثيب", "nature", false, 0xfff1e3cc, 0xfffbf2e2, 0xff3b2c18, 0xffc27c3e, 0xff6a7f5a, Material.clay, "round", PackFont.sans, "calm", "grain", Family.summer),
    Row("Aurora", "شفق قطبي", "nature", true, 0xff071422, 0xff0e2033, 0xffe3f3ff, 0xff58e0b0, 0xffb07bff, Material.glass, "round", PackFont.sans, "springy", "mesh", Family.winter),
    Row("Ocean Deep", "أعماق المحيط", "nature", true, 0xff031a2b, 0xff08283f, 0xffdff1ff, 0xff2bb3e3, 0xff7ce0d2, Material.glossy, "round", PackFont.sans, "calm", "mesh", Family.summer),
    Row("Coral", "مرجان", "nature", false, 0xfffdeee8, 0xfffff8f5, 0xff3a1d16, 0xffe2583e, 0xff2a9d8f, Material.flat, "squircle", PackFont.rounded, "springy", "none", Family.summer),
    Row("Meadow", "مرج", "nature", false, 0xffeef5e2, 0xfffbfdf6, 0xff22301a, 0xff6a9a2e, 0xffe0a33a, Material.paper, "round", PackFont.rounded, "springy", "dots", Family.spring),
    Row("Snowfield", "حقل الثلج", "nature", false, 0xfff2f6fa, 0xffffffff, 0xff1b2733, 0xff5a7fa8, 0xffb0c4d8, Material.glass, "round", PackFont.sans, "calm", "pattern", Family.winter),
    Row("Soft Glass", "زجاج ناعم", "glass", false, 0xffdfe7f3, 0xffffffff, 0xff17202c, 0xff4f7cff, 0xffff7aa8, Material.glass, "round", PackFont.sans, "springy", "mesh", Family.spring),
    Row("Frosted Premium", "زجاج مصنفر فاخر", "glass", true, 0xff101418, 0xff1a2028, 0xffeef2f6, 0xffc8b48a, 0xff8fb3d9, Material.glass, "squircle", PackFont.sans, "calm", "mesh", Family.winter),
    Row("One UI Glass", "زجاج بأسلوب One UI", "glass", false, 0xffe4ebf5, 0xffffffff, 0xff141a22, 0xff3e7bfa, 0xff5ac8a8, Material.glass, "squircle", PackFont.rounded, "springy", "mesh", Family.friday),
    Row("Classic iOS-inspired", "كلاسيكي مستوحى من iOS", "glass", false, 0xfff2f2f7, 0xffffffff, 0xff000000, 0xff007aff, 0xff34c759, Material.glass, "squircle", PackFont.sans, "springy", "none", Family.spring),
    Row("Fluid Glass", "زجاج سائل", "glass", true, 0xff0d1022, 0xff171b36, 0xffeef0ff, 0xff8ea2ff, 0xffff9ad5, Material.glass, "round", PackFont.rounded, "springy", "mesh", Family.eid),
    Row("Soft Clay", "صلصال ناعم", "glass", false, 0xffe8e3dc, 0xffefeae3, 0xff2d2924, 0xffc06c4a, 0xff6b8f7a, Material.clay, "round", PackFont.rounded, "springy", "none", Family.autumn),
    Row("Layered Depth", "عمق متعدد الطبقات", "glass", true, 0xff15171c, 0xff20232a, 0xffeceef2, 0xff6ad1ff, 0xffffcf6a, Material.glossy, "squircle", PackFont.sans, "springy", "dots", Family.newyear),
    Row("Neon Grid", "شبكة نيون", "tech", true, 0xff0a0716, 0xff120d26, 0xfff0e9ff, 0xffff3fd8, 0xff3ff0ff, Material.neon, "sharp", PackFont.mono, "snappy", "grid", Family.newyear),
    Row("Terminal", "طرفية", "tech", true, 0xff050a05, 0xff0b140b, 0xffb6f5b6, 0xff39ff7a, 0xffffd23f, Material.outlined, "sharp", PackFont.mono, "none", "lines", Family.study),
    Row("Synthwave Dusk", "غسق سينث", "tech", true, 0xff1a0b2e, 0xff2a1145, 0xffffe9f7, 0xffff6ac1, 0xffffb86b, Material.neon, "round", PackFont.condensed, "springy", "grid", Family.summer),
    Row("Blueprint", "مخطط أزرق", "tech", true, 0xff0d3466, 0xff0f3c75, 0xffe6f0ff, 0xffffffff, 0xff9fd0ff, Material.blueprint, "sharp", PackFont.mono, "none", "grid", Family.study),
    Row("Cyber Mint", "نعناع سيبراني", "tech", true, 0xff06161a, 0xff0b2328, 0xffd9fbf3, 0xff3dffc5, 0xff7aa8ff, Material.neon, "chamfer", PackFont.mono, "snappy", "grid", Family.winter),
    Row("Monochrome Pro", "أحادي احترافي", "tech", false, 0xfff0f0f0, 0xffffffff, 0xff0a0a0a, 0xff0a0a0a, 0xff6b6b6b, Material.outlined, "sharp", PackFont.condensed, "snappy", "none", Family.friday),
    Row("Coffee", "قهوة", "warm", true, 0xff1e1410, 0xff2b1d17, 0xfff2e4d6, 0xffc88a55, 0xff8fae8b, Material.matte, "round", PackFont.serif, "calm", "grain", Family.autumn),
    Row("Champagne", "شمبانيا", "warm", false, 0xfff6eee0, 0xfffffaf1, 0xff2f2618, 0xff8a6a26, 0xff9c6b7b, Material.glossy, "squircle", PackFont.serif, "calm", "none", Family.eid),
    Row("Rose Quartz", "كوارتز وردي", "warm", false, 0xfff8e8ea, 0xfffff6f7, 0xff3a1f26, 0xffc45a78, 0xff7c8fc4, Material.glass, "round", PackFont.rounded, "springy", "mesh", Family.love),
    Row("Terracotta", "تيراكوتا", "warm", false, 0xfff1e0d4, 0xfffaf0e8, 0xff3a2116, 0xffb5532e, 0xff4f7a6a, Material.clay, "chamfer", PackFont.sans, "calm", "grain", Family.coptic),
    Row("Sunset", "غروب", "warm", true, 0xff26111a, 0xff371a26, 0xffffe8de, 0xffff7a59, 0xffffc85c, Material.glossy, "round", PackFont.sans, "springy", "mesh", Family.summer),
    Row("Amber", "كهرمان", "warm", true, 0xff1b1408, 0xff2a1f0d, 0xfffbeccc, 0xfff2a516, 0xffd8693b, Material.matte, "squircle", PackFont.condensed, "snappy", "none", Family.autumn),
    Row("Saffron", "زعفران", "warm", false, 0xfffbefd6, 0xfffff8e8, 0xff3a2808, 0xffa65a0a, 0xffa83a3a, Material.paper, "round", PackFont.serif, "calm", "pattern", Family.ramadan),
    Row("Candy", "حلوى", "playful", false, 0xfffff0f6, 0xffffffff, 0xff3a1030, 0xffff4fa3, 0xff7a5cff, Material.glossy, "round", PackFont.rounded, "springy", "dots", Family.birthday),
    Row("Pastel Cloud", "سحابة باستيل", "playful", false, 0xffeef0ff, 0xffffffff, 0xff232552, 0xff8a7bff, 0xff5fd3c0, Material.clay, "round", PackFont.rounded, "springy", "none", Family.spring),
    Row("Sticker Pop", "ملصقات", "playful", false, 0xfffff7d6, 0xffffffff, 0xff141414, 0xffff5a36, 0xff2f7bff, Material.outlined, "round", PackFont.rounded, "springy", "dots", Family.birthday),
    Row("Arcade", "أركيد", "playful", true, 0xff14092b, 0xff1f1040, 0xfffff4d6, 0xffffd23f, 0xff3fd0ff, Material.neon, "sharp", PackFont.mono, "snappy", "grid", Family.newyear),
)

val THEMES: List<ThemePack> = ROWS.map { r ->
    val (dur, ease) = motion(r.motion)
    ThemePack(
        id = r.en.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-'),
        en = r.en, ar = r.ar, cat = r.cat, dark = r.dark,
        bg = Color(r.bg), surface = Color(r.surface), text = Color(r.text), accent = Color(r.accent), accent2 = Color(r.accent2),
        material = r.material, radius = radius(r.shape), font = r.font,
        durMs = dur, ease = ease, texture = r.texture, ornament = r.ornament,
    )
}

fun themeById(id: String): ThemePack = THEMES.find { it.id == id } ?: THEMES[0]

val LocalPack = compositionLocalOf { THEMES[0] }
