package app.dayflow.android.calendar

import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.chrono.HijrahChronology
import kotlin.math.floor

/**
 * Three-calendars domain core (native port of the web calendar engine):
 * Gregorian + Hijri (Umm al-Qura via java.time HijrahDate) + Coptic (exact JDN computus),
 * plus the occasion table and the DecorResolver (same priorities/budgets as the design).
 */
object Calendars {

    enum class Family { ramadan, islamic, eid, winter, spring, summer, autumn, national, nile, coptic, love, study, birthday, friday, newyear }

    // ── Hijri ────────────────────────────────────────────────────
    data class CalParts(val y: Int, val m: Int, val d: Int)

    fun hijri(date: LocalDate): CalParts {
        val h = HijrahDate.from(date)
        return CalParts(h.get(java.time.temporal.ChronoField.YEAR_OF_ERA), h.monthValue, h.dayOfMonth)
    }

    val HIJRI_MONTHS_AR = listOf("محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة")
    val HIJRI_MONTHS_EN = listOf("Muharram", "Safar", "Rabi' I", "Rabi' II", "Jumada I", "Jumada II", "Rajab", "Sha'ban", "Ramadan", "Shawwal", "Dhu al-Qi'dah", "Dhu al-Hijjah")

    // ── Coptic (exact Julian-day computus) ───────────────────────
    private const val COPTIC_EPOCH = 1825029L // JDN of 1 Thout 1 AM

    private fun jdn(date: LocalDate): Long = date.toEpochDay() + 2440588
    private fun copticToJdn(y: Int, m: Int, d: Int): Long = COPTIC_EPOCH - 1 + 365L * (y - 1) + y / 4 + 30L * (m - 1) + d

    fun coptic(date: LocalDate): CalParts {
        val j = jdn(date)
        val y = ((4 * (j - COPTIC_EPOCH) + 1463) / 1461).toInt()
        val m = ((j - copticToJdn(y, 1, 1)) / 30).toInt() + 1
        val d = (j - copticToJdn(y, m, 1)).toInt() + 1
        return CalParts(y, m, d)
    }

    val COPTIC_MONTHS_AR = listOf("توت", "بابه", "هاتور", "كيهك", "طوبة", "أمشير", "برمهات", "برمودة", "بشنس", "بؤونة", "أبيب", "مسرى", "النسيء")
    val COPTIC_MONTHS_EN = listOf("Thout", "Paopi", "Hathor", "Koiak", "Tobi", "Meshir", "Paremhat", "Parmouti", "Pashons", "Paoni", "Epip", "Mesori", "Nasie")

    /** Orthodox Easter — Meeus Julian algorithm (+13 days, valid 1900–2099). */
    fun orthodoxEaster(year: Int): LocalDate {
        val a = year % 4; val b = year % 7; val c = year % 19
        val d = (19 * c + 15) % 30
        val e = (2 * a + 4 * b - d + 34) % 7
        val month = (d + e + 114) / 31
        val day = (d + e + 114) % 31 + 1
        return LocalDate.of(year, month, day).plusDays(13)
    }

    // ── Occasions ────────────────────────────────────────────────
    data class Occasion(val id: String, val en: String, val ar: String, val family: Family, val priority: Int, val phase: String? = null, val strength: Float = 1f)

    private val FIXED = listOf(
        Triple(1 to 1, Occasion("newyear", "New Year", "رأس السنة الميلادية", Family.newyear, 70), "civil"),
        Triple(1 to 7, Occasion("coptic-christmas", "Coptic Christmas", "عيد الميلاد المجيد", Family.coptic, 70), "coptic"),
        Triple(1 to 19, Occasion("epiphany", "Epiphany", "عيد الغطاس", Family.coptic, 70), "coptic"),
        Triple(1 to 25, Occasion("jan25", "25 January Revolution", "ثورة ٢٥ يناير", Family.national, 70), "national"),
        Triple(2 to 14, Occasion("valentine", "Valentine's Day", "عيد الحب", Family.love, 30), "civil"),
        Triple(3 to 21, Occasion("mothers", "Mother's Day", "عيد الأم", Family.love, 70), "civil"),
        Triple(4 to 25, Occasion("sinai", "Sinai Liberation Day", "عيد تحرير سيناء", Family.national, 70), "national"),
        Triple(5 to 1, Occasion("labour", "Labour Day", "عيد العمال", Family.national, 40), "civil"),
        Triple(6 to 30, Occasion("jun30", "30 June Revolution", "ثورة ٣٠ يونيو", Family.national, 70), "national"),
        Triple(7 to 23, Occasion("jul23", "23 July Revolution", "ثورة ٢٣ يوليو", Family.national, 70), "national"),
        Triple(8 to 15, Occasion("wafaa", "Wafaa El-Nil", "عيد وفاء النيل", Family.nile, 70), "national"),
        Triple(9 to 11, Occasion("nayrouz", "Nayrouz", "عيد النيروز", Family.coptic, 70), "coptic"),
        Triple(9 to 27, Occasion("cross", "Feast of the Cross", "عيد الصليب", Family.coptic, 40), "coptic"),
    )

    private data class HOcc(val m: Int, val d: Int, val len: Int, val o: Occasion)
    private val HIJRI_OCC = listOf(
        HOcc(1, 1, 1, Occasion("hijri-newyear", "Islamic New Year", "رأس السنة الهجرية", Family.islamic, 80)),
        HOcc(3, 12, 1, Occasion("mawlid", "Mawlid an-Nabi", "المولد النبوي الشريف", Family.islamic, 80)),
        HOcc(7, 27, 1, Occasion("isra", "Isra and Mi'raj", "الإسراء والمعراج", Family.islamic, 80)),
        HOcc(8, 15, 1, Occasion("midshaban", "Mid-Sha'ban", "ليلة النصف من شعبان", Family.islamic, 80)),
        HOcc(9, 27, 1, Occasion("qadr", "Laylat al-Qadr", "ليلة القدر (ليلة ٢٧)", Family.ramadan, 95)),
        HOcc(10, 1, 3, Occasion("eid-fitr", "Eid al-Fitr", "عيد الفطر المبارك", Family.eid, 100)),
        HOcc(12, 9, 1, Occasion("arafah", "Day of Arafah", "يوم عرفة", Family.islamic, 95)),
        HOcc(12, 10, 4, Occasion("eid-adha", "Eid al-Adha", "عيد الأضحى المبارك", Family.eid, 100)),
    )

    fun occasionsOn(date: LocalDate): List<Occasion> {
        val out = mutableListOf<Occasion>()
        val m = date.monthValue; val d = date.dayOfMonth
        for ((md, o, _) in FIXED) if (md.first == m && md.second == d) out += o
        if (m == 10 && d in 6..24) {
            val strength = if (d == 6) 1f else if (d == 24) 0.7f else maxOf(0.25f, 1 - (d - 6) / 18f)
            out += Occasion(
                "october",
                if (d == 6) "October Victory" else if (d == 24) "Suez National Day" else "October Victory season",
                if (d == 6) "انتصارات أكتوبر" else if (d == 24) "العيد القومي للسويس" else "موسم انتصارات أكتوبر",
                Family.national, if (d == 6) 90 else 45, strength = strength,
            )
        }
        val h = hijri(date)
        if (h.m == 9) {
            val phase = if (h.d <= 10) "early" else if (h.d <= 20) "middle" else "last-ten"
            out += Occasion(
                "ramadan",
                if (phase == "last-ten") "Ramadan · Last ten nights" else "Ramadan · Day ${h.d}",
                if (phase == "last-ten") "رمضان · العشر الأواخر" else "رمضان · اليوم ${h.d}",
                Family.ramadan, 85, phase, if (phase == "early") 0.55f else if (phase == "middle") 0.75f else 1f,
            )
        }
        for (x in HIJRI_OCC) if (h.m == x.m && h.d >= x.d && h.d < x.d + x.len) out += x.o
        val easter = orthodoxEaster(date.year)
        if (easter == date) out += Occasion("easter", "Easter", "عيد القيامة المجيد", Family.coptic, 75)
        if (easter.plusDays(1) == date) out += Occasion("sham", "Sham El-Nessim", "شم النسيم", Family.spring, 85)
        return out.sortedByDescending { it.priority }
    }

    fun climateSeason(date: LocalDate): Pair<Family, Pair<String, String>> {
        return when (date.monthValue) {
            12, 1, 2 -> Family.winter to ("Winter" to "الشتاء")
            3, 4, 5 -> Family.spring to ("Spring" to "الربيع")
            6, 7, 8 -> Family.summer to ("Summer" to "الصيف")
            else -> Family.autumn to ("Autumn" to "الخريف")
        }
    }

    data class Layer(val source: String, val family: Family, val en: String, val ar: String, val strength: Float)
    data class DecorStack(val layers: List<Layer>, val primary: Family, val occasions: List<Occasion>)

    /** DecorResolver — identical order and budget: occasion → season → weekday → personal day → climate. */
    fun resolveDecor(date: LocalDate, userDays: List<app.dayflow.android.data.UserDay>, budget: Int = 3, examSeason: Boolean = false): DecorStack {
        val occ = occasionsOn(date)
        val layers = mutableListOf<Layer>()
        for (o in occ) layers += Layer("occasion", o.family, o.en, o.ar, o.strength)
        if (examSeason && date.monthValue in listOf(1, 5, 6)) layers += Layer("season", Family.study, "Exam season", "موسم الامتحانات", 0.5f)
        if (date.monthValue == 9 && date.dayOfMonth >= 15 || date.monthValue == 10 && date.dayOfMonth <= 5)
            layers += Layer("season", Family.study, "Back to school", "العودة للمدارس", 0.4f)
        if (date.dayOfWeek.value == 5) layers += Layer("weekday", Family.friday, "Friday", "الجمعة", 0.35f)
        val md = "%02d-%02d".format(date.monthValue, date.dayOfMonth)
        for (u in userDays) if (u.date == md) {
            val fam = runCatching { Family.valueOf(u.family) }.getOrDefault(Family.birthday)
            layers += Layer("user", fam, u.en, u.ar, 0.9f)
        }
        val (cf, cn) = climateSeason(date)
        layers += Layer("climate", cf, cn.first, cn.second, 0.3f)
        val seen = mutableSetOf<Family>()
        val final = layers.filter { if (it.family in seen) false else seen.add(it.family) }.take(budget)
        return DecorStack(final, final.first().family, occ)
    }

    fun upcoming(from: LocalDate, count: Int = 8, horizon: Int = 400): List<Pair<LocalDate, Occasion>> {
        val out = mutableListOf<Pair<LocalDate, Occasion>>()
        val seen = mutableSetOf<String>()
        var d = from
        var i = 0
        while (i < horizon && out.size < count) {
            for (o in occasionsOn(d)) {
                val key = if (o.id == "ramadan" || o.id == "october") o.id else o.id + d.year
                if (key !in seen) { seen += key; out += d to o }
            }
            d = d.plusDays(1); i++
        }
        return out
    }
}
