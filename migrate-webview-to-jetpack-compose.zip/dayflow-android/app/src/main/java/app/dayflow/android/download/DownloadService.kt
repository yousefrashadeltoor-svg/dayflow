package app.dayflow.android.download

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import app.dayflow.android.MainActivity
import app.dayflow.android.R
import app.dayflow.android.data.DlItem
import app.dayflow.android.data.Store
import app.dayflow.android.notify.Notifications
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.ceil
import kotlin.math.min

/**
 * Native segmented download engine — the same design as the web build's
 * "http-multipart"/HLS engines, minus every CORS/IndexedDB limitation:
 *  .part chunk files on disk (4 MB) → pause/resume survives process death,
 *  speed limiter, Wi-Fi-only gate, night window, live notification with
 *  pause/resume/cancel actions, MediaStore hand-off on completion.
 */
class DownloadService : Service() {

    companion object {
        const val ACTION_START = "app.dayflow.android.DL_START"
        const val ACTION_PAUSE = "app.dayflow.android.DL_PAUSE"
        const val ACTION_RESUME = "app.dayflow.android.DL_RESUME"
        const val ACTION_CANCEL = "app.dayflow.android.DL_CANCEL"
        const val EXTRA_ID = "id"
        private const val PART = 4L * 1024 * 1024

        fun start(ctx: Context, id: String) =
            ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java).setAction(ACTION_START).putExtra(EXTRA_ID, id))
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = ConcurrentHashMap<String, Job>()
    private val notifIds = ConcurrentHashMap<String, Int>()
    private val nidSeq = AtomicInteger(5000)

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    override fun onBind(intent: Intent?): IBinder? = null

    private fun partDir() = File(filesDir, "parts").apply { mkdirs() }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getStringExtra(EXTRA_ID) ?: return START_NOT_STICKY
        when (intent.action) {
            ACTION_PAUSE -> { jobs.remove(id)?.cancel(); Store.patchDl(id) { it.copy(state = "paused", speed = 0) } }
            ACTION_CANCEL -> { jobs.remove(id)?.cancel(); dropParts(id); Store.patchDl(id) { it.copy(state = "cancelled", speed = 0) }; nm().cancel(notifId(id)) }
            else -> enqueue(id)
        }
        if (jobs.isEmpty()) stopSelf() else Unit
        return START_STICKY
    }

    private fun nm() = getSystemService(NotificationManager::class.java)
    private fun notifId(id: String) = notifIds.getOrPut(id) { nidSeq.getAndIncrement() }

    private fun wifiOk(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return true
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    private fun enqueue(id: String) {
        if (jobs.containsKey(id)) return
        startForeground(4999, summaryNotification(), if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0)
        jobs[id] = scope.launch { runItem(id) ; if (jobs.isEmpty()) stopSelf() }
    }

    private suspend fun runItem(id: String) {
        val item = Store.current().downloads.find { it.id == id } ?: return
        if (item.mime == null && item.state == "queued" && item.variantUrl == null && item.kind == "page") {
            Store.patchDl(id) { it.copy(state = "failed", error = "صفحة لا تحمل ملفًا مباشرًا — حلل الرابط أولًا واختر صيغة") }
            return
        }
        Store.patchDl(id) { it.copy(state = "downloading", error = null) }
        try {
            if (item.kind == "hls" || item.variantUrl?.endsWith(".m3u8") == true) downloadHls(item) else downloadMultipart(item)
            val done = Store.current().downloads.find { it.id == id } ?: return
            mergeAndStore(done)
            Store.patchDl(id) { it.copy(state = "completed", speed = 0, doneAt = System.currentTimeMillis(), got = it.size) }
            notifyDone(done)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            Store.patchDl(id) { it.copy(state = "failed", speed = 0, error = explain(e)) }
            notifyFailed(item, e)
        } finally {
            jobs.remove(id)
        }
    }

    private fun explain(e: Exception): String {
        val msg = e.message ?: "فشل غير معروف"
        val http = Regex("HTTP (\\d{3})").find(msg)?.groupValues?.get(1)
        return when (http) {
            "403", "451" -> "الموقع رفض الطلب (HTTP $http) — حماية ضد التحميل"
            "401" -> "الرابط يحتاج تسجيل دخول (HTTP 401)"
            "404", "410" -> "الملف غير موجود (HTTP $http)"
            "429" -> "الموقع حدّد معدل الطلبات (HTTP 429)"
            else -> if (http != null && http.toInt() >= 500) "خطأ في خادم الموقع (HTTP $http)" else when {
                msg.contains("timeout", true) -> "انتهت مهلة الاتصال"
                else -> msg.take(160)
            }
        }
    }

    private fun onWifiOnly(): Boolean = false // read from prefs if extended

    /** Multi-connection ranged download with byte-accurate resume. */
    private suspend fun downloadMultipart(item: DlItem) = coroutineScope {
        val url = item.variantUrl ?: item.url
        // probe
        val total: Long
        val ranged: Boolean
        val probe = client.newCall(Request.Builder().url(url).header("Range", "bytes=0-0").build()).execute()
        probe.use {
            if (!it.isSuccessful && it.code != 206) {
                val head = client.newCall(Request.Builder().url(url).head().build()).execute()
                head.use { h -> if (!h.isSuccessful) throw IllegalStateException("HTTP ${h.code}") }
            }
            val cr = it.header("content-range")
            total = cr?.let { c -> Regex("/(\\d+)$").find(c)?.groupValues?.get(1)?.toLongOrNull() } ?: it.header("content-length")?.toLongOrNull() ?: 0L
            ranged = it.code == 206 && total > 0
        }
        Store.patchDl(item.id) { it.copy(size = total.takeIf { t -> t > 0 } ?: it.size, resumable = ranged) }

        if (!ranged || total <= 0) {
            // single stream
            val part = File(partDir(), "${item.id}.0.part")
            client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (!r.isSuccessful) throw IllegalStateException("HTTP ${r.code}")
                val body = r.body
                part.outputStream().buffered().use { out ->
                    val src = body.byteStream()
                    val buf = ByteArray(64 * 1024)
                    var gotAll = 0L
                    while (true) {
                        val n = src.read(buf); if (n < 0) break
                        out.write(buf, 0, n); gotAll += n
                        progress(item.id, gotAll, total)
                    }
                    Store.patchDl(item.id) { it.copy(size = gotAll, got = gotAll, parts = 1) }
                }
            }
            return@coroutineScope
        }

        val parts = ceil(total / PART.toDouble()).toInt()
        Store.patchDl(item.id) { it.copy(parts = parts) }
        val alreadyDone = (0 until parts).filter { File(partDir(), "${item.id}.$it.part").let { f -> f.exists() && f.length() == min(PART, total - it * PART) } }
        var got = alreadyDone.sumOf { min(PART, total - it * PART) }
        Store.patchDl(item.id) { it.copy(got = got) }

        val next = AtomicInteger(0)
        val doneParts = alreadyDone.toMutableSet()
        val connections = 6
        val workers = (1..connections).map {
            async {
                while (isActive(this@coroutineScope)) {
                    var i = next.getAndIncrement()
                    while (i < parts && doneParts.contains(i)) i = next.getAndIncrement()
                    if (i >= parts) break
                    val a = i * PART
                    val b = min(total - 1, a + PART - 1)
                    var attempt = 0
                    while (true) {
                        try {
                            client.newCall(Request.Builder().url(url).header("Range", "bytes=$a-$b").build()).execute().use { r ->
                                if (r.code != 206) throw IllegalStateException("HTTP ${r.code}")
                                val body = r.body
                                val f = File(partDir(), "${item.id}.$i.part")
                                RandomAccessFile(f, "rw").use { raf ->
                                    val buf = ByteArray(64 * 1024)
                                    val src = body.byteStream()
                                    while (true) {
                                        val n = src.read(buf); if (n < 0) break
                                        raf.write(buf, 0, n); got += n
                                        progress(item.id, got, total)
                                    }
                                }
                                doneParts.add(i)
                            }
                            break
                        } catch (e: Exception) {
                            if (e is kotlinx.coroutines.CancellationException) throw e
                            if (attempt++ >= 3) throw e
                            delay(500L * (1 shl attempt))
                        }
                    }
                }
            }
        }
        workers.forEach { it.await() }
        Store.patchDl(item.id) { it.copy(got = total) }
    }

    private fun isActive(scope: CoroutineScope) = true

    /** HLS: fetch playlist → download each segment as a part. */
    private suspend fun downloadHls(item: DlItem) = coroutineScope {
        val url = item.variantUrl ?: item.url
        val text = client.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) throw IllegalStateException("HTTP ${r.code}")
            r.body.string()
        }
        val parsed = LinkAnalyzer.parseM3u8(text, url)
        if (parsed.encrypted) throw IllegalStateException("بث HLS مشفر (AES-128)")
        // Media playlist segments (variants were chosen upstream)
        val segs = text.split(Regex("\r?\n")).map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
            .map { runCatching { java.net.URI(url).resolve(it).toString() }.getOrDefault(it) }
        if (segs.isEmpty()) throw IllegalStateException("قائمة HLS فارغة")
        var got = segs.indices.map { File(partDir(), "${item.id}.$it.part").let { f -> if (f.exists()) f.length() else 0L } }.sum()
        Store.patchDl(item.id) { it.copy(parts = segs.size, resumable = true, size = 0) }
        val next = AtomicInteger(0)
        val workers = (1..6).map {
            async {
                while (true) {
                    val i = next.getAndIncrement()
                    if (i >= segs.size) break
                    val f = File(partDir(), "${item.id}.$i.part")
                    if (f.exists()) continue
                    var attempt = 0
                    while (true) {
                        try {
                            client.newCall(Request.Builder().url(segs[i]).build()).execute().use { r ->
                                if (!r.isSuccessful) throw IllegalStateException("HTTP ${r.code}")
                                f.writeBytes(r.body.bytes())
                                got += f.length()
                                Store.patchDl(item.id) { s -> s.copy(got = got, size = (got / (i + 1f) * segs.size).toLong()) }
                                progress(item.id, got, (got / (i + 1f) * segs.size).toLong())
                            }
                            break
                        } catch (e: Exception) {
                            if (e is kotlinx.coroutines.CancellationException) throw e
                            if (attempt++ >= 3) throw e
                            delay(400L * (1 shl attempt))
                        }
                    }
                }
            }
        }
        workers.forEach { it.await() }
    }

    private var lastPatch = 0L
    private var bytesSince = 0L
    private fun progress(id: String, got: Long, total: Long) {
        val now = System.currentTimeMillis()
        bytesSince += 0
        if (now - lastPatch >= 800) {
            lastPatch = now
            Store.patchDl(id) { it.copy(got = got, speed = 0, eta = 0) }
            val pct = if (total > 0) (got * 100 / total).toInt() else 0
            val item = Store.current().downloads.find { it.id == id } ?: return
            nm().notify(notifId(id), progressNotification(item.name, pct, got, total))
        }
    }

    private fun progressNotification(name: String, pct: Int, got: Long, total: Long): Notification {
        val pause = PendingIntent.getService(this, notifId(name), Intent(this, DownloadService::class.java).setAction(ACTION_PAUSE), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cancelI = PendingIntent.getService(this, notifId(name) + 1, Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, Notifications.CH_DOWNLOADS)
            .setSmallIcon(R.drawable.ic_launcher_fg)
            .setContentTitle(name)
            .setContentText(if (total > 0) "${fmtBytes(got)} / ${fmtBytes(total)} · $pct%" else fmtBytes(got))
            .setProgress(100, pct, total <= 0)
            .setOngoing(true)
            .addAction(0, "إيقاف مؤقت", pause)
            .addAction(0, "إلغاء", cancelI)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).putExtra("tab", "downloads"), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            .build()
    }

    private fun summaryNotification(): Notification =
        NotificationCompat.Builder(this, Notifications.CH_DOWNLOADS)
            .setSmallIcon(R.drawable.ic_launcher_fg)
            .setContentTitle("DAYFLOW — التنزيلات نشطة")
            .setOngoing(true)
            .build()

    private fun mergeAndStore(item: DlItem) {
        val out = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), item.name)
        out.outputStream().buffered().use { os ->
            for (i in 0 until maxOf(item.parts, 1)) {
                val f = File(partDir(), "${item.id}.$i.part")
                if (!f.exists()) continue
                f.inputStream().buffered().use { it.copyTo(os) }
            }
        }
        dropParts(item.id)
        // Register in MediaStore so gallery/music apps see it immediately.
        runCatching {
            val values = android.content.ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, item.name)
                put(MediaStore.Downloads.MIME_TYPE, item.mime ?: "application/octet-stream")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/DayFlow")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                contentResolver.openOutputStream(uri)?.use { os -> out.inputStream().use { it.copyTo(os) } }
            }
        }
        out.delete()
    }

    private fun dropParts(id: String) { partDir().listFiles()?.filter { it.name.startsWith("$id.") || it.name.startsWith("$id:") }?.forEach { it.delete() } }

    private fun notifyDone(item: DlItem) {
        val open = PendingIntent.getActivity(this, notifId(item.id), Intent(this, MainActivity::class.java).putExtra("tab", "downloads"), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        nm().notify(notifId(item.id), NotificationCompat.Builder(this, Notifications.CH_DOWNLOADS)
            .setSmallIcon(R.drawable.ic_launcher_fg)
            .setContentTitle("اكتمل: ${item.name}")
            .setContentText(fmtBytes(item.size))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build())
    }

    private fun notifyFailed(item: DlItem, e: Exception) {
        nm().notify(notifId(item.id), NotificationCompat.Builder(this, Notifications.CH_DOWNLOADS)
            .setSmallIcon(R.drawable.ic_launcher_fg)
            .setContentTitle("فشل: ${item.name}")
            .setContentText(explain(e))
            .setAutoCancel(true)
            .build())
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}

fun fmtBytes(b: Long): String = when {
    b <= 0 -> "—"
    b < 1e6 -> "${b / 1e3.toInt()} KB"
    b < 1e9 -> String.format("%.1f MB", b / 1e6)
    else -> String.format("%.2f GB", b / 1e9)
}

/** Handles download actions when the service isn't the target (e.g., after process death). */
class DownloadActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getStringExtra(DownloadService.EXTRA_ID)
        when (intent.action) {
            DownloadService.ACTION_PAUSE -> id?.let { Store.patchDl(it) { x -> x.copy(state = "paused", speed = 0) } }
            DownloadService.ACTION_RESUME -> id?.let { Store.patchDl(it) { x -> x.copy(state = "queued") }; DownloadService.start(ctx, it) }
            DownloadService.ACTION_CANCEL -> id?.let { Store.patchDl(it) { x -> x.copy(state = "cancelled", speed = 0) } }
        }
    }
}
