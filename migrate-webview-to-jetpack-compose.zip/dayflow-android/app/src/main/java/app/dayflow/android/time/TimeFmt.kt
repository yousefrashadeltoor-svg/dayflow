package app.dayflow.android.time

import app.dayflow.android.data.Alarm
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Strict 12-hour clock for the whole native app — alarms, prayer times,
 * widgets, notifications, countdowns. Arabic UI uses Arabic-Indic digits + ص/م.
 */
object TimeFmt {

    private val AR_DIGITS = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')

    fun toArabicDigits(s: String): String = buildString(s.length) {
        for (c in s) append(if (c in '0'..'9') AR_DIGITS[c - '0'] else c)
    }

    fun num(n: Number | String, lang: String): String =
        if (lang == "ar") toArabicDigits(n.toString()) else n.toString()

    data class Parts(val time: String, val suffix: String, val full: String)

    /** "HH:mm" or Date → 12-hour parts. */
    fun clock12(hour24: Int, minute: Int, lang: String, seconds: Int? = null): Parts {
        val h = hour24 % 24
        val hour = h % 12 == 0 && (h == 0 || h == 12)
        val disp = if (h % 12 == 0) 12 else h % 12
        val base = "$disp:${minute.toString().padStart(2, '0')}" + (seconds?.let { ":${it.toString().padStart(2, '0')}" } ?: "")
        val suffix = if (lang == "ar") (if (h < 12) "ص" else "م") else (if (h < 12) "AM" else "PM")
        val t = num(base, lang)
        return Parts(t, suffix, "$t $suffix")
    }

    fun fmt(value: String, lang: String, seconds: Boolean = false): String {
        val b = value.split(":").mapNotNull { it.toIntOrNull() }
        if (b.size < 2) return "—"
        return clock12(b[0], b[1], lang, if (seconds) (b.getOrNull(2) ?: 0) else null).full
    }

    fun fmt(date: Date, lang: String, seconds: Boolean = false): String {
        val c = Calendar.getInstance().apply { time = date }
        return clock12(c[Calendar.HOUR_OF_DAY], c[Calendar.MINUTE], lang, if (seconds) c[Calendar.SECOND] else null).full
    }

    fun dateLine(d: Date, lang: String): String =
        SimpleDateFormat(if (lang == "ar") "EEEE d MMMM" else "EEEE, MMMM d", if (lang == "ar") Locale("ar", "EG") else Locale.ENGLISH)
            .format(d).let { if (lang == "ar") toArabicDigits(it) else it }

    fun dayName(day: Int /*0=Sun*/, lang: String, short: Boolean = false): String {
        val namesAr = arrayOf("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")
        val namesEn = arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
        val s = if (lang == "ar") namesAr[day % 7] else namesEn[day % 7]
        return if (short && lang == "ar") s.take(3) else if (short) s.take(3) else s
    }

    fun until(ms: Long, lang: String): String {
        val total = (ms / 60000).coerceAtLeast(0)
        val h = (total / 60).toInt(); val m = (total % 60).toInt()
        return if (lang == "ar") "بعد ${num(h, lang)} س ${num(m, lang)} د" else "in ${h}h ${m}m"
    }
}
