package app.dayflow.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Countdown
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.StickyNote2
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.calendar.Calendars
import app.dayflow.android.data.Store
import app.dayflow.android.patterns.Patterns
import app.dayflow.android.time.TimeFmt
import app.dayflow.android.ui.DFButton
import app.dayflow.android.ui.DFCard
import app.dayflow.android.ui.DFToggle
import app.dayflow.android.ui.MotifView
import app.dayflow.android.ui.Ring
import app.dayflow.android.ui.ScreenHeader
import app.dayflow.android.ui.bodyStyle
import app.dayflow.android.ui.pack
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.util.Date

/** Gregorian month grid, Hijri/Coptic cards, and occasion markers (same layout & chips). */
@Composable
fun CalendarScreen(go: (String, String?) -> Unit) {
    val s by Store.state.collectAsState()
    val lang = s.lang
    val today = LocalDate.now()
    var month by remember { mutableStateOf(today.withDayOfMonth(1)) }
    val days = (1..month.lengthOfMonth()).map { month.withDayOfMonth(it) }
    val lead = (month.dayOfWeek.value) % 7 // Sun=0
    val occByDay = remember(month) { days.associateWith { Calendars.occasionsOn(it) } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 96.dp)) {
        ScreenHeader(title = if (lang == "ar") "التقويم" else "Calendar", subtitle = TimeFmt.dateLine(java.sql.Date.valueOf(today.toString()), lang))

        // Tri-calendar strip
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                Triple("الهجري", "${Calendars.hijri(today).d} ${Calendars.HIJRI_MONTHS_AR[Calendars.hijri(today).m - 1]} ${Calendars.hijri(today).y}", Calendars.Family.islamic),
                Triple("القبطي", "${Calendars.coptic(today).d} ${Calendars.COPTIC_MONTHS_AR[Calendars.coptic(today).m - 1]} ${Calendars.coptic(today).y}", Calendars.Family.coptic),
                Triple("الميلادي", "${today.dayOfMonth} / ${today.monthValue} / ${today.year}", Calendars.Family.national),
            ).forEach { (label, value, fam) ->
                DFCard(Modifier.weight(1f)) {
                    Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        MotifView(fam, 26.dp)
                        Text(label, style = bodyStyle(11, color = pack.muted), modifier = Modifier.padding(top = 4.dp))
                        Text(value, style = bodyStyle(12, FontWeight.Bold), textAlign = TextAlign.Center)
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // Month header
        DFCard {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "${TimeFmt.num(month.monthValue, lang)} / ${TimeFmt.num(month.year, lang)}",
                        style = bodyStyle(17, FontWeight.Bold), modifier = Modifier.weight(1f),
                    )
                    Text("‹", fontSize = 22.sp, modifier = Modifier.padding(end = 14.dp).clickable { month = month.minusMonths(1) })
                    Text("›", fontSize = 22.sp, modifier = Modifier.clickable { month = month.plusMonths(1) })
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth()) {
                    (listOf(0, 1, 2, 3, 4, 5, 6)).forEach { d ->
                        Text(TimeFmt.dayName(d, lang, short = true).take(3), Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 10.sp, color = pack.muted)
                    }
                }
                repeat(lead) { }; // alignment handled by grid below
                val cells = (1..((lead + days.size + 6) / 7) * 7)
                cells.chunked(7).forEach { week ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        week.forEach { cell ->
                            val dayIdx = cell - lead
                            val d = if (dayIdx in 1..days.size) days[dayIdx - 1] else null
                            Box(
                                Modifier.weight(1f).aspectRatio(1f).padding(2.dp)
                                    .clip(CircleShape)
                                    .background(if (d == today) pack.accent else Color.Transparent)
                                    .clickable(enabled = d != null) { },
                                contentAlignment = Alignment.Center,
                            ) {
                                if (d != null) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            TimeFmt.num(d.dayOfMonth, lang), fontSize = 13.sp,
                                            color = if (d == today) pack.onAccent else pack.text,
                                            fontWeight = if (d == today) FontWeight.Bold else FontWeight.Normal,
                                        )
                                        val occ = occByDay[d]
                                        if (!occ.isNullOrEmpty()) Box(Modifier.size(4.dp).clip(CircleShape).background(if (d == today) pack.onAccent else Patterns.FAMILY[occ.first().family]!!.c1))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Text(if (lang == "ar") "مناسبات هذا الشهر" else "Occasions this month", style = bodyStyle(14, FontWeight.Bold), modifier = Modifier.padding(horizontal = 4.dp))
        occByDay.filter { it.value.isNotEmpty() }.toList().sortedBy { it.first }.forEach { (d, occs) ->
            occs.forEach { o ->
                val f = Patterns.FAMILY[o.family]!!
                DFCard(Modifier.padding(vertical = 4.dp)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.width(44.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(f.c2, f.c1))).padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                            Text(TimeFmt.num(d.dayOfMonth, lang), color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(if (lang == "ar") o.ar else o.en, style = bodyStyle(13, FontWeight.SemiBold))
                        }
                        MotifView(o.family, 28.dp)
                    }
                }
            }
        }
    }
}

/** Tools hub — working native implementations (notes, tasks, habits, focus, countdowns, water, tasbih, journal, QR generator…). */
@Composable
fun ToolsScreen(sub: String?, go: (String, String?) -> Unit) {
    val s by Store.state.collectAsState()
    val lang = s.lang
    when (sub) {
        "notes" -> NotesScreen(lang, go)
        "tasks" -> TasksScreen(lang, go)
        "habits" -> HabitsScreen(lang, go)
        "focus" -> FocusScreen(lang, go)
        "countdowns" -> CountdownsScreen(lang, go)
        "journal" -> JournalScreen(lang, go)
        "tasbih" -> TasbihScreen(lang)
        else -> ToolsHub(lang, go)
    }
}

@Composable
private fun ToolsHub(lang: String, go: (String, String?) -> Unit) {
    val items = listOf(
        Triple("tasks", Icons.Filled.Checklist, if (lang == "ar") "المهام" else "Tasks"),
        Triple("notes", Icons.Filled.StickyNote2, if (lang == "ar") "الملاحظات" else "Notes"),
        Triple("habits", Icons.Filled.FavoriteBorder, if (lang == "ar") "العادات" else "Habits"),
        Triple("focus", Icons.Filled.Timer, if (lang == "ar") "التركيز" else "Focus"),
        Triple("countdowns", Icons.Filled.Countdown, if (lang == "ar") "العد التنازلي" else "Countdowns"),
        Triple("journal", Icons.Filled.Book, if (lang == "ar") "اليوميات" else "Journal"),
        Triple("tasbih", Icons.Filled.GridView, if (lang == "ar") "التسبيح" else "Tasbih"),
        Triple("qr", Icons.Filled.QrCode, "QR"),
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 96.dp)) {
        ScreenHeader(title = if (lang == "ar") "أدوات" else "Tools")
        androidx.compose.foundation.lazy.grid.LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.height((items.size / 2 * 120).dp), userScrollEnabled = false,
        ) {
            items(items) { (id, icon, label) ->
                DFCard(Modifier.padding(4.dp), onClick = { go("tools", id) }) {
                    Column(Modifier.padding(18.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(pack.soft), contentAlignment = Alignment.Center) {
                            Icon(icon, null, tint = pack.accent)
                        }
                        Text(label, style = bodyStyle(13, FontWeight.SemiBold), modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun TasksScreen(lang: String, go: (String, String?) -> Unit) {
    val s by Store.state.collectAsState()
    var txt by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title = if (lang == "ar") "المهام" else "Tasks", onBack = { go("tools", null) })
        Row {
            OutlinedTextField(txt, { txt = it }, Modifier.weight(1f), placeholder = { Text(if (lang == "ar") "مهمة جديدة…" else "New task…") }, singleLine = true)
            Spacer(Modifier.width(8.dp))
            DFButton("+", { if (txt.isNotBlank()) { Store.addTask(txt.trim()); txt = "" } })
        }
        LazyColumn(Modifier.padding(top = 10.dp)) {
            items(s.tasks, key = { it.id }) { t ->
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp).clickable { Store.toggleTask(t.id) }, verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(22.dp).clip(RoundedCornerShape(6.dp)).background(if (t.done) pack.accent else Color.Transparent).then(Modifier.clip(RoundedCornerShape(6.dp))))
                    Spacer(Modifier.width(10.dp))
                    Text(t.title, Modifier.weight(1f), style = bodyStyle(14, color = if (t.done) pack.muted else pack.text))
                    Text(t.date, style = bodyStyle(11, color = pack.muted))
                }
            }
        }
    }
}

@Composable
private fun NotesScreen(lang: String, go: (String, String?) -> Unit) {
    val s by Store.state.collectAsState()
    var txt by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title = if (lang == "ar") "الملاحظات" else "Notes", onBack = { go("tools", null) })
        Row {
            OutlinedTextField(txt, { txt = it }, Modifier.weight(1f), placeholder = { Text(if (lang == "ar") "اكتب ملاحظة…" else "Write a note…") })
            Spacer(Modifier.width(8.dp))
            DFButton("+", { if (txt.isNotBlank()) { Store.addNote(txt.trim()); txt = "" } })
        }
        LazyColumn(Modifier.padding(top = 10.dp)) {
            items(s.notes, key = { it.id }) { n ->
                DFCard(Modifier.padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(n.text, style = bodyStyle(14))
                        Text(app.dayflow.android.time.TimeFmt.dateLine(Date(n.at), lang), style = bodyStyle(11, color = pack.muted))
                    }
                }
            }
        }
    }
}

@Composable
private fun HabitsScreen(lang: String, go: (String, String?) -> Unit) {
    val s by Store.state.collectAsState()
    var txt by remember { mutableStateOf("") }
    val key = Store.dayKey()
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title = if (lang == "ar") "العادات" else "Habits", onBack = { go("tools", null) })
        Row {
            OutlinedTextField(txt, { txt = it }, Modifier.weight(1f), placeholder = { Text(if (lang == "ar") "عادة جديدة (مثال: قراءة)" else "New habit…") }, singleLine = true)
            Spacer(Modifier.width(8.dp))
            DFButton("+", { if (txt.isNotBlank()) { Store.addHabit(app.dayflow.android.data.Habit("", txt.trim(), ar = txt.trim())); txt = "" } })
        }
        LazyColumn(Modifier.padding(top = 10.dp)) {
            items(s.habits, key = { it.id }) { h ->
                val on = h.log.contains(key)
                DFCard(Modifier.padding(vertical = 4.dp)) {
                    Row(Modifier.padding(12.dp).clickable { Store.toggleHabit(h.id) }, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(h.en, style = bodyStyle(14, FontWeight.SemiBold))
                            Text("${if (lang == "ar") "سلسلة" else "streak"}: ${TimeFmt.num(h.log.size, lang)}", style = bodyStyle(11, color = pack.muted))
                        }
                        DFToggle(on, { Store.toggleHabit(h.id) }, h.en)
                    }
                }
            }
        }
    }
}

@Composable
private fun FocusScreen(lang: String, go: (String, String?) -> Unit) {
    var remaining by remember { mutableLongStateOf(25 * 60_000L) }
    var running by remember { mutableStateOf(false) }
    LaunchedEffect(running) {
        while (running && remaining > 0) { delay(1000); remaining -= 1000 }
        if (remaining <= 0) running = false
    }
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        ScreenHeader(title = if (lang == "ar") "التركيز" else "Focus", onBack = { go("tools", null) })
        Spacer(Modifier.height(30.dp))
        Ring(value = remaining / (25 * 60_000f), size = 220.dp, stroke = 10.dp) {
            val m = remaining / 60000; val sec = (remaining % 60000) / 1000
            Text("${TimeFmt.num(m.toInt(), lang)}:${TimeFmt.num("%02d".format(sec), lang)}", style = bodyStyle(44, FontWeight.Light))
        }
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            DFButton(if (running) (if (lang == "ar") "إيقاف" else "Pause") else (if (lang == "ar") "ابدأ" else "Start"), { running = !running })
            DFButton(if (lang == "ar") "إعادة" else "Reset", { running = false; remaining = 25 * 60_000L }, variant = "ghost")
        }
    }
}

@Composable
private fun CountdownsScreen(lang: String, go: (String, String?) -> Unit) {
    val s by Store.state.collectAsState()
    var title by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title = if (lang == "ar") "العد التنازلي" else "Countdowns", onBack = { go("tools", null) })
        Row {
            OutlinedTextField(title, { title = it }, Modifier.weight(1f), placeholder = { Text(if (lang == "ar") "العنوان" else "Title") }, singleLine = true)
            Spacer(Modifier.width(6.dp))
            OutlinedTextField(date, { date = it }, Modifier.width(130.dp), placeholder = { Text("yyyy-MM-dd") }, singleLine = true)
            Spacer(Modifier.width(6.dp))
            DFButton("+", { if (title.isNotBlank() && date.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) { Store.mutate { it.copy(countdowns = it.countdowns + app.dayflow.android.data.Countdown(Store.newId(), title.trim(), date)) }; title = ""; date = "" } })
        }
        LazyColumn(Modifier.padding(top = 10.dp)) {
            items(s.countdowns, key = { it.id }) { c ->
                val left = runCatching { java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(c.date)) }.getOrDefault(0L)
                DFCard(Modifier.padding(vertical = 4.dp)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(c.title, Modifier.weight(1f), style = bodyStyle(14, FontWeight.SemiBold))
                        Text(if (left >= 0) "${if (lang == "ar") "بعد" else "in"} ${TimeFmt.num(left, lang)} ${if (lang == "ar") "يوم" else "days"}" else if (lang == "ar") "انتهى" else "done", style = bodyStyle(13, FontWeight.Bold, pack.accent))
                    }
                }
            }
        }
    }
}

@Composable
private fun JournalScreen(lang: String, go: (String, String?) -> Unit) {
    val s by Store.state.collectAsState()
    var txt by remember { mutableStateOf("") }
    val today = Store.dayKey()
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title = if (lang == "ar") "اليوميات" else "Journal", onBack = { go("tools", null) })
        OutlinedTextField(txt, { txt = it }, Modifier.fillMaxWidth(), placeholder = { Text(if (lang == "ar") "حدث النهاردة إيه؟" else "How was today?") })
        Spacer(Modifier.height(8.dp))
        DFButton(if (lang == "ar") "سجّل" else "Log", {
            if (txt.isNotBlank()) {
                Store.mutate { it.copy(journal = listOf(app.dayflow.android.data.Journal(Store.newId(), today, 3, txt.trim())) + it.journal) }; txt = ""
            }
        })
        LazyColumn(Modifier.padding(top = 10.dp)) {
            items(s.journal, key = { it.id }) { j ->
                DFCard(Modifier.padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(j.date, style = bodyStyle(11, color = pack.muted))
                        Text(j.text, style = bodyStyle(14), modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun TasbihScreen(lang: String) {
    val s by Store.state.collectAsState()
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        ScreenHeader(title = if (lang == "ar") "التسبيح" else "Tasbih")
        Spacer(Modifier.height(30.dp))
        Box(Modifier.size(220.dp).clip(CircleShape).background(pack.soft).clickable { Store.mutate { it.copy(tasbih = it.tasbih + 1) } }, contentAlignment = Alignment.Center) {
            Text(TimeFmt.num(s.tasbih, lang), style = bodyStyle(56, FontWeight.Bold))
        }
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            DFButton(if (lang == "ar") "صفر" else "Reset", { Store.mutate { it.copy(tasbih = 0) } }, variant = "ghost")
            DFButton("الختمة +", { Store.mutate { it.copy(khatma = it.khatma + 1) } }, variant = "soft")
        }
        Text("${if (lang == "ar") "الختمات" else "Khatma"}: ${TimeFmt.num(s.khatma, lang)}", style = bodyStyle(13, color = pack.muted), modifier = Modifier.padding(top = 12.dp))
    }
}
