package app.dayflow.android.ai

import app.dayflow.android.data.Alarm
import app.dayflow.android.data.Store
import app.dayflow.android.time.TimeFmt
import java.util.Calendar
import java.util.regex.Pattern

/** Local Egyptian Arabic intent engine: alarms, tasks, water, notes, habits — runs offline. */
object MiniBrain {

    private val AR_DIGITS = mapOf('٠' to '0', '١' to '1', '٢' to '2', '٣' to '3', '٤' to '4', '٥' to '5', '٦' to '6', '٧' to '7', '٨' to '8', '٩' to '9')

    fun normDigits(s: String): String = buildString(s.length) { for (c in s) append(AR_DIGITS[c] ?: c) }

    /** Returns a real answer + executes actions natively (alarms scheduled through AlarmManager). */
    suspend fun answer(raw: String, lang: String, scheduleAlarm: (Alarm) -> Unit): String {
        val s = Store.current()
        val q = normDigits(raw).trim()

        // "اعمل منبه ٧" / "منبه 6:30 الصبح" / "سهرني 5:30 الفجر"
        val alarmMatch = Regex("""(?:منبه|منبّه|صحيني|شغل منبه|اعمل منبه|فكرني|ذكرني)?\s*.*?(\d{1,2})(?:[:.](\d{2}))?\s*(الصبح|الفجر|الضهر|العصر|المغرب|العشية|الليل|بالليل|صباحا|مساء)?""", RegexOption.IGNORE_CASE).find(q)
        val wantsAlarm = q.contains("منبه") || q.contains("منبّه") || q.contains("صحيني") || q.contains("فكرني") || q.contains("ذكرني")
        if (wantsAlarm && alarmMatch != null) {
            val hRaw = alarmMatch.groupValues[1].toIntOrNull() ?: return "عايز المنبّه الساعة كام؟ قولّي الوقت بصيغة واضحة، زي ٧ الصبح."
            val min = alarmMatch.groupValues[2].toIntOrNull() ?: 0
            val period = alarmMatch.groupValues[3]
            val pm = period.contains("العصر") || period.contains("المغرب") || period.contains("العشية") || period.contains("الليل") || period.contains("مساء")
            val hour24 = (hRaw % 12) + if (pm) 12 else 0
            val at = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour24); set(Calendar.MINUTE, min); set(Calendar.SECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            val label = if (lang == "ar") "منبه من الرفيق" else "Companion alarm"
            val id = Store.addAlarm(Alarm("", "%02d:%02d".format(hour24, min), days = (0..6).toList(), label = label, enabled = true))
            val alarm = Store.current().alarms.first { it.id == id }
            scheduleAlarm(alarm)
            return "تم — المنبه هيصحيك ${TimeFmt.fmt(alarm.time, lang)} ${TimeFmt.dayName(at[Calendar.DAY_OF_WEEK] - 1, lang)} (${TimeFmt.dateLine(at.time, lang)})"
        }

        // tasks
        if (q.startsWith("مهامي") || q.contains("مهام")) {
            val today = Store.dayKey()
            val mine = s.tasks.filter { it.date == today }
            return if (mine.isEmpty()) "مهامك فاضية النهاردة — استمتع! لو عايز تضيف مهمة: «اعمل مهمة ...»"
            else "عندك ${TimeFmt.num(mine.size, lang)} مهام النهاردة، منهم ${TimeFmt.num(mine.count { it.done }, lang)} خلصت: " + mine.filter { !it.done }.joinToString(" · ") { it.title }
        }
        Regex("""(?:اعمل مهمة|ضيف مهمة|مهمة)\s+(.+)""").find(q)?.groupValues?.get(1)?.let { title ->
            Store.addTask(title.trim())
            return "اتسجّلت المهمة: «${title.trim()}» — النهاردة"
        }

        // water
        if (q.contains("اشرب") || q.contains("ماية") || q.contains("مية") || q.contains("ماء")) {
            Store.addWater(250)
            val today = Store.dayKey()
            val ml = Store.current().water[today] ?: 0
            return "اتسجّل ٢٥٠ مل — مجموع النهاردة ${TimeFmt.num(String.format("%.2f", ml / 1000f), lang)} لتر"
        }

        // notes
        Regex("""(?:ملاحظة|دون|سجل)\s+(.+)""").find(q)?.groupValues?.get(1)?.let { t ->
            if (t.isNotBlank() && !t.contains("مهمة")) { Store.addNote(t.trim()); return "اتدونت كملاحظة." }
        }

        // identity / help
        if (q.contains("إنت مين") || q.contains("انت مين") || q.contains("مين انت"))
            return "أنا رفيق DAYFLOW — شغال على جهازك بالكامل، بعرف أظبط منبهات وأتنقل في التطبيق وأذكرك بمهامك، ومش ببعت أي حاجة بره من غير مفتاحك."
        if (q.contains("تعرف تعمل ايه") || q.contains("ساعد"))
            return "أقدر: اضبط منبهات («صحيني ٧ الصبح»)، أسجل مهام وملاحظات، أسجل شرب الماية، وأقولك مهامك. للنماذج الكبيرة ضف مفتاح من «مفاتيح»."

        return "سمعك — «اعمل منبه ٧ الصبح»، «ضيف مهمة ...»، «اشرب ماية»… والمفتاح يخليني أرد من النماذج الكبيرة."
    }
}

/** Remote provider calls (OpenAI-compatible chat completions), native OkHttp — no browser CORS. */
object RemoteAI
