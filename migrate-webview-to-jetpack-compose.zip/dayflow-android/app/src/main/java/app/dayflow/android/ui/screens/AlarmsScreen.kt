package app.dayflow.android.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.lazy.rememberLazyListState
import app.dayflow.android.alarm.AlarmScheduler
import app.dayflow.android.alarm.NextAlarm
import app.dayflow.android.alarm.RingScreen
import app.dayflow.android.calendar.Calendars
import app.dayflow.android.data.Alarm
import app.dayflow.android.data.SoundSource
import app.dayflow.android.data.Store
import app.dayflow.android.time.TimeFmt
import app.dayflow.android.tones.Tones
import app.dayflow.android.ui.Chip
import app.dayflow.android.ui.DFButton
import app.dayflow.android.ui.DFCard
import app.dayflow.android.ui.DFSheet
import app.dayflow.android.ui.DFToggle
import app.dayflow.android.ui.EmptyState
import app.dayflow.android.ui.Honest
import app.dayflow.android.ui.ScreenHeader
import app.dayflow.android.ui.Segmented
import app.dayflow.android.ui.bodyStyle
import app.dayflow.android.ui.pack
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

private val DAY_ORDER = listOf(6, 0, 1, 2, 3, 4, 5) // Sat → Fri (as in the design)

@Composable
fun AlarmsScreen() {
    val s by Store.state.collectAsState()
    val lang = s.lang
    val ctx = LocalContext.current
    var edit by remember { mutableStateOf<Alarm?>(null) }
    var ringing by remember { mutableStateOf<Alarm?>(null) }
    val next = NextAlarm.soonest(s.alarms)
    val fam = remember { Calendars.resolveDecor(java.time.LocalDate.now(), s.userDays, 3).primary }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = if (lang == "ar") "المنبهات" else "Alarms",
            subtitle = next?.let { "${if (lang == "ar") "التالي" else "Next"}: ${TimeFmt.fmt(it.second, lang)}" }
                ?: (if (lang == "ar") "لا منبهات مفعّلة" else "No alarms on"),
            right = {
                DFButton(if (lang == "ar") "جديد" else "New", {
                    edit = Alarm("", "07:00", days = listOf(0, 1, 2, 3, 4), label = "", enabled = true)
                })
            },
        )

        // exact-alarm access surface (Android 12+) — native, no browser wording
        if (!AlarmScheduler.canScheduleExact(ctx)) {
            DFCard(Modifier.padding(bottom = 10.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text(if (lang == "ar") "إذن المنبهات الدقيقة غير مفعّل" else "Exact-alarm access is off", style = bodyStyle(13, FontWeight.Bold))
                    Text(if (lang == "ar") "فعّله من إعدادات النظام ليعمل الرنين في معاده بدقة." else "Enable it in system settings so alarms ring exactly on time.", style = bodyStyle(12, color = pack.muted))
                    Spacer(Modifier.height(8.dp))
                    DFButton(if (lang == "ar") "افتح الإعدادات" else "Open settings", { ctx.startActivity(AlarmScheduler.exactAccessIntent(ctx)) }, variant = "soft")
                }
            }
        }

        if (s.alarms.isEmpty()) {
            EmptyState(fam, if (lang == "ar") "مفيش منبهات لسه" else "No alarms yet", if (lang == "ar") "أنشئ منبهًا في ثوانٍ." else "Create one in a few seconds.") {
                DFButton(if (lang == "ar") "اعمل منبه" else "Create alarm", { edit = Alarm("", "07:00", days = listOf(0, 1, 2, 3, 4), label = "", enabled = true) })
            }
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(1f)) {
            items(s.alarms.sortedBy { it.time }, key = { it.id }) { a ->
                DFCard(onClick = { edit = a }) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).alpha(if (a.enabled) 1f else 0.5f)) {
                            val parts = a.time.split(":").mapNotNull { it.toIntOrNull() }
                            if (parts.size >= 2) {
                                val pc = TimeFmt.clock12(parts[0], parts[1], lang)
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(pc.time, style = bodyStyle(32, FontWeight.SemiBold))
                                    Spacer(Modifier.width(5.dp))
                                    Text(pc.suffix, style = bodyStyle(14, FontWeight.Bold, pack.accent), modifier = Modifier.padding(bottom = 6.dp))
                                }
                            }
                            Text(a.label.ifBlank { if (lang == "ar") "منبه" else "Alarm" }, style = bodyStyle(14, FontWeight.Medium))
                            Text(daysLabel(a, lang) + " · " + a.soundTitle, style = bodyStyle(11, color = pack.muted))
                        }
                        DFToggle(a.enabled, { on ->
                            Store.updateAlarm(a.id) { it.copy(enabled = on) }
                            if (on) AlarmScheduler.schedule(ctx, Store.current().alarms.first { it.id == a.id })
                            else AlarmScheduler.cancel(ctx, a.id)
                        }, a.label.ifBlank { a.time })
                    }
                }
            }
        }
    }

    edit?.let { a ->
        AlarmEditor(
            alarm = a,
            lang = lang,
            onClose = { edit = null },
            onPreview = { edit = null; ringing = it },
        )
    }

    ringing?.let { a ->
        RingScreen(
            label = a.label, snoozeMin = a.snooze, alarmId = a.id, lang = lang,
            showSeconds = s.alarmLook.showSeconds, gradient = s.alarmLook.gradient,
            userDays = s.userDays, intensity = "rich",
            onDismiss = { ringing = null }, onSnooze = { ringing = null },
        )
    }
}

private fun daysLabel(a: Alarm, lang: String): String {
    if (a.date != null && a.days.isEmpty()) {
        val fmt = SimpleDateFormat(if (lang == "ar") "EEEE d MMM yyyy" else "EEEE, d MMM yyyy", if (lang == "ar") Locale("ar", "EG") else Locale.UK)
        return runCatching { fmt.format(SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(a.date)!!) }.getOrDefault(a.date)
    }
    if (a.days.isEmpty()) return if (lang == "ar") "مرة واحدة" else "Once"
    if (a.days.size == 7) return if (lang == "ar") "كل يوم" else "Every day"
    return DAY_ORDER.filter { it in a.days }.joinToString(" · ") { TimeFmt.dayName(it, lang, short = true) }
}

// ─── Editor (12-hour wheel + presets + sound picker) — the native twin of the web sheet ───

@Composable
fun AlarmEditor(alarm: Alarm, lang: String, onClose: () -> Unit, onPreview: (Alarm) -> Unit) {
    val ctx = LocalContext.current
    var a by remember { mutableStateOf(alarm) }
    var picker by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val p = pack

    val startParts = a.time.split(":").mapNotNull { it.toIntOrNull() }
    var hour12 by remember { mutableStateOf((startParts.getOrNull(0) ?: 7).let { val h = it % 12; if (h == 0) 12 else h }) }
    var minute by remember { mutableStateOf(startParts.getOrNull(1) ?: 0) }
    var pm by remember { mutableStateOf((startParts.getOrNull(0) ?: 7) >= 12) }
    fun commitTime() {
        val h24 = (if (pm) 12 else 0) + (hour12 % 12)
        a = a.copy(time = "%02d:%02d".format(h24, minute))
    }

    DFSheet(open = true, onClose = onClose, title = if (a.id.isBlank()) (if (lang == "ar") "منبه جديد" else "New alarm") else (if (lang == "ar") "تعديل المنبه" else "Edit alarm")) {
        // 12-hour wheel
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Wheel(1..12, hour12) { hour12 = it; commitTime() }
            Text(":", style = bodyStyle(40, FontWeight.Light), modifier = Modifier.padding(horizontal = 6.dp))
            Wheel(0..59, minute, pad = true) { minute = it; commitTime() }
            Spacer(Modifier.width(14.dp))
            Column {
                Chip(if (lang == "ar") "ص" else "AM", !pm) { pm = false; commitTime() }
                Spacer(Modifier.height(6.dp))
                Chip(if (lang == "ar") "م" else "PM", pm) { pm = true; commitTime() }
            }
        }

        Spacer(Modifier.height(12.dp))
        // presets + one-time-date chip
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            item {
                Chip(if (lang == "ar") "يوم معيّن" else "One specific date", a.date != null && a.days.isEmpty()) {
                    a = a.copy(date = a.date ?: Store.dayKey(), days = emptyList())
                }
            }
            item { Chip(if (lang == "ar") "الأحد–الخميس" else "Sun–Thu", a.date == null && a.days == listOf(0, 1, 2, 3, 4)) { a = a.copy(date = null, days = listOf(0, 1, 2, 3, 4)) } }
            item { Chip(if (lang == "ar") "الجمعة–السبت" else "Fri–Sat", a.date == null && a.days == listOf(5, 6)) { a = a.copy(date = null, days = listOf(5, 6)) } }
            item { Chip(if (lang == "ar") "كل يوم" else "Every day", a.date == null && a.days.size == 7) { a = a.copy(date = null, days = (0..6).toList()) } }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            DAY_ORDER.forEach { d ->
                Box(
                    Modifier.weight(1f).clip(CircleShape)
                        .background(if (a.date == null && d in a.days) p.accent else Color.Transparent)
                        .clickable {
                            a = a.copy(date = null, days = if (d in a.days) a.days - d else a.days + d)
                        }.padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(TimeFmt.dayName(d, lang, short = true).take(3), fontSize = 11.sp, color = if (a.date == null && d in a.days) p.onAccent else p.text, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        if (a.date != null && a.days.isEmpty()) {
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = a.date ?: "", onValueChange = { a = a.copy(date = it) }, label = { Text(if (lang == "ar") "تاريخ المنبّه (yyyy-MM-dd)" else "Alarm date (yyyy-MM-dd)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        }

        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = a.label, onValueChange = { a = a.copy(label = it) }, placeholder = { Text(if (lang == "ar") "الاسم (اختياري)" else "Label (optional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

        Spacer(Modifier.height(10.dp))
        DFCard(onClick = { picker = true }) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Smartphone, null, tint = p.accent, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (lang == "ar") "الصوت" else "Sound", style = bodyStyle(14, FontWeight.Medium))
                    Text(a.soundTitle, style = bodyStyle(11, color = p.muted))
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        DFCard {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (lang == "ar") "اهتزاز" else "Vibrate", Modifier.weight(1f), style = bodyStyle(14))
                DFToggle(a.vibrate, { a = a.copy(vibrate = it) })
            }
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(if (lang == "ar") "استيقاظ لطيف" else "Gentle wake", style = bodyStyle(14))
                    Text(if (lang == "ar") "يرتفع الصوت خلال ٦٠ ثانية" else "Volume rises over 60 seconds", style = bodyStyle(12, color = p.muted))
                }
                DFToggle(a.gentle, { a = a.copy(gentle = it) })
            }
        }

        if (error.isNotBlank()) Text(error, color = Color(0xffd32f2f), style = bodyStyle(12), modifier = Modifier.padding(top = 8.dp))

        Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (a.id.isNotBlank()) DFButton("🗑", {
                Store.removeAlarm(a.id); AlarmScheduler.cancel(ctx, a.id); onClose()
            }, variant = "ghost")
            DFButton(if (lang == "ar") "معاينة" else "Preview", { onPreview(a) }, variant = "soft", icon = { Icon(Icons.Filled.PlayArrow, null, tint = p.text, modifier = Modifier.size(14.dp)) })
            DFButton(if (lang == "ar") "حفظ" else "Save", {
                // validation (same rules as the web build)
                if (a.days.isEmpty() && a.date == null) { error = if (lang == "ar") "اختار تاريخ للمنبّه اللي هيشتغل مرة واحدة." else "Choose a date for a one-time alarm."; return@DFButton }
                val id = if (a.id.isBlank()) Store.addAlarm(a.copy(enabled = true)) else { Store.updateAlarm(a.id) { _ -> a }; a.id }
                val saved = Store.current().alarms.first { it.id == id }
                if (saved.enabled) AlarmScheduler.schedule(ctx, saved) else AlarmScheduler.cancel(ctx, id)
                onClose()
            }, Modifier.weight(1f))
        }
    }

    if (picker) {
        SoundPickerSheet(value = a, lang = lang, onPick = { a = it; picker = false }, onClose = { picker = false })
    }
}

/** Vertical snap wheel (hours/minutes) with big centered typography. */
@Composable
fun Wheel(range: IntRange, value: Int, pad: Boolean = false, on: (Int) -> Unit) {
    val p = pack
    rememberLazyListState(initialFirstVisibleItemIndex = (value - range.first).coerceIn(0, range.count() - 1))
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = (value - range.first).coerceIn(0, range.count() - 1))
    Column {
        Box(Modifier.height(150.dp).width(72.dp).clip(RoundedCornerShape(16.dp)).background(p.soft)) {
            LazyColumn(
                state = listState, modifier = Modifier.fillMaxHeight(),
                verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                items(range.count()) { i ->
                    val v = range.first + i
                    val sel = v == value
                    Text(
                        if (pad) "%02d".format(v).let { TimeFmt.num(it, Store.current().lang) } else TimeFmt.num(v, Store.current().lang),
                        fontSize = if (sel) 34.sp else 16.sp,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                        color = if (sel) p.text else p.muted,
                        modifier = Modifier.fillMaxWidth().height(50.dp).clickable { on(v) }.wrapContentHeight(),
                        textAlign = TextAlign.Center,
                    )
                }
            }
        }
    }
}

private fun Modifier.wrapContentHeight(): Modifier = this

// ─── Sound picker (device tones via RingtoneManager + SAF + library tabs) ───

@Composable
fun SoundPickerSheet(value: Alarm, lang: String, onPick: (Alarm) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var src by remember { mutableStateOf(value.soundSource.name) }
    val tones = remember { Tones.deviceTones(ctx) }
    val audioFiles = remember(src) { if (src == "downloaded") Tones.deviceAudio(ctx) else emptyList() }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var imported by remember { mutableStateOf<Pair<String, String>?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            imported = ((uri.lastPathSegment ?: "audio") to uri.toString())
        }
    }

    DFSheet(open = true, onClose = { Tones.stopPreview(); onClose() }, title = if (lang == "ar") "اختر صوتًا" else "Choose a sound") {
        Segmented(
            value = src, onChange = { src = it }, options = listOf(
                "library" to "DAYFLOW",
                "device" to (if (lang == "ar") "الجهاز" else "Device"),
                "files" to (if (lang == "ar") "ملفاتي" else "My files"),
                "downloaded" to (if (lang == "ar") "المنزّلة" else "Downloaded"),
            ),
        )
        Spacer(Modifier.height(12.dp))
        when (src) {
            "device" -> {
                LazyColumn(Modifier.heightIn(max = 300.dp)) {
                    items(tones, key = { it.uri }) { tone ->
                        val sel = value.soundUri == tone.uri
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                .clickable { onPick(value.copy(soundSource = SoundSource.device, soundTitle = tone.title, soundUri = tone.uri)) }
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Filled.Smartphone, null, tint = pack.accent, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(10.dp))
                            Text(tone.title, Modifier.weight(1f), style = bodyStyle(13))
                            Text(tone.type, style = bodyStyle(10, color = pack.muted))
                            Spacer(Modifier.width(8.dp))
                            Text(if (lang == "ar") "استمع" else "Play", style = bodyStyle(11, FontWeight.Bold, pack.accent), modifier = Modifier.clickable { Tones.preview(ctx, tone.uri) })
                            if (sel) { Spacer(Modifier.width(8.dp)); Text("✓", color = pack.accent, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Honest(if (lang == "ar") "نغمات هاتفك الحقيقية (من Samsung One UI أو غيره) — تُحفظ كمرجع URI مستقر وليست نسخة، وتبقى صالحة بعد إعادة التشغيل." else "Your phone's real tones — stored as a stable URI reference, persisting across reboots.")
            }
            "files" -> {
                DFButton(if (lang == "ar") "اختر ملفًا صوتيًا" else "Pick an audio file", { picker.launch(arrayOf("audio/*")) }, Modifier.fillMaxWidth(), variant = "soft", icon = { Icon(Icons.Filled.FolderOpen, null, tint = pack.text, modifier = Modifier.size(15.dp)) })
                imported?.let { (name, uri) ->
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(name.take(28), Modifier.weight(1f), style = bodyStyle(12))
                        DFButton(if (lang == "ar") "استمع" else "Play", { Tones.preview(ctx, uri) }, variant = "ghost")
                        Spacer(Modifier.width(6.dp))
                        DFButton(if (lang == "ar") "استخدم" else "Use", { onPick(value.copy(soundSource = SoundSource.files, soundTitle = name, soundUri = uri)) }, variant = "primary")
                    }
                }
                Text(if (lang == "ar") "يُحفظ الإذن بشكل دائم؛ يعمل الصوت مع المنبه حتى بعد إعادة تشغيل الهاتف." else "Permission is persisted — the tone keeps ringing alarms across reboots.", style = bodyStyle(11, color = pack.muted), modifier = Modifier.padding(top = 8.dp))
            }
            "downloaded" -> {
                Text(if (lang == "ar") "الصوتيات على مكتبة جهازك — اختر ما تحفظه من مركز الوسائط." else "Audio already on your device.", style = bodyStyle(12, color = pack.muted))
                LazyColumn(Modifier.heightIn(max = 300.dp).padding(top = 8.dp)) {
                    items(audioFiles.take(40), key = { it.uri }) { tone ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable {
                                onPick(value.copy(soundSource = SoundSource.downloaded, soundTitle = tone.title, soundUri = tone.uri))
                            }.padding(vertical = 10.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(tone.title.take(34), Modifier.weight(1f), style = bodyStyle(13))
                            Text(if (lang == "ar") "استمع" else "Play", style = bodyStyle(11, FontWeight.Bold, pack.accent), modifier = Modifier.clickable { Tones.preview(ctx, tone.uri) })
                        }
                    }
                }
            }
            else -> {
                Column(Modifier.fillMaxWidth().padding(vertical = 22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (lang == "ar") "يُعاد بناء المكتبة" else "Library being rebuilt", style = bodyStyle(14, FontWeight.SemiBold))
                    Text(if (lang == "ar") "حُذفت مكتبة الأصوات القديمة. تُضاف نغمات جديدة بعد فحص الترخيص فقط — حتى ذلك الحين لا توجد نغمات مضمّنة." else "The old sound library was removed; tones are added back only after their licenses pass the redistribution check.", style = bodyStyle(12, color = pack.muted), modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
    }
}
