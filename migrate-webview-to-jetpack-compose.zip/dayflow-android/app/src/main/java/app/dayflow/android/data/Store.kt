package app.dayflow.android.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.serialization.json.Json
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Single source of truth, persisted atomically in SharedPreferences as JSON
 * (the native replacement for the web build's localStorage "dayflow-v2" blob).
 * Off-main-thread writes are coalesced; reads are a StateFlow for Compose.
 */
object Store {

    private const val FILE = "dayflow-native"
    private const val KEY = "dayflow-v2"

    private lateinit var prefs: SharedPreferences
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; explicitNulls = false }

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY, null)
        if (raw != null) runCatching { _state.value = json.decodeFromString(State.serializer(), raw) }
        // App language follows the device on first run (same as the web build).
        if (!prefs.contains(KEY) && Locale.getDefault().language.startsWith("ar")) {
            _state.update { it.copy(lang = "ar") }
        }
    }

    fun current(): State = _state.value

    @Synchronized
    fun mutate(block: (State) -> State) {
        _state.update(block)
        // Atomic, ordered, crash-safe persistence.
        prefs.edit().putString(KEY, json.encodeToString(State.serializer(), _state.value)).apply()
    }

    fun set(block: (State) -> State) = mutate(block)

    // ── ids & dates ──────────────────────────────────────────────
    fun newId() = (1..8).joinToString("") { (('a'..'z') + ('0'..'9')).random().toString() }
    fun dayKey(d: Date = Date()): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(d)

    // ── domains (same semantics as the web store) ───────────────
    fun addAlarm(a: Alarm): String {
        val id = if (a.id.isBlank()) newId() else a.id
        mutate { it.copy(alarms = it.alarms + a.copy(id = id)) }
        return id
    }

    fun updateAlarm(id: String, patch: (Alarm) -> Alarm) =
        mutate { s -> s.copy(alarms = s.alarms.map { if (it.id == id) patch(it) else it }) }

    fun removeAlarm(id: String) = mutate { s -> s.copy(alarms = s.alarms.filterNot { it.id == id }) }

    fun addTask(title: String, date: String = dayKey(), dueTime: String? = null, urgent: Boolean = false): String {
        val id = newId()
        mutate { s ->
            s.copy(tasks = listOf(Task(id, title, date, dueTime, false, urgent, true, "todo", System.currentTimeMillis())) + s.tasks)
        }
        return id
    }

    fun toggleTask(id: String) = mutate { s ->
        s.copy(tasks = s.tasks.map { if (it.id == id) it.copy(done = !it.done, status = if (!it.done) "done" else "todo") else it })
    }

    fun removeTask(id: String) = mutate { s -> s.copy(tasks = s.tasks.filterNot { it.id == id }) }

    fun addNote(text: String) = mutate { s -> s.copy(notes = listOf(Note(newId(), text, false, System.currentTimeMillis())) + s.notes) }
    fun removeNote(id: String) = mutate { s -> s.copy(notes = s.notes.filterNot { it.id == id }) }

    fun toggleHabit(id: String, day: String = dayKey()) = mutate { s ->
        s.copy(habits = s.habits.map { h ->
            if (h.id != id) h else h.copy(log = if (h.log.contains(day)) h.log - day else h.log + day)
        })
    }

    fun addHabit(h: Habit): String {
        val id = if (h.id.isBlank()) newId() else h.id
        mutate { s -> s.copy(habits = s.habits + h.copy(id = id, createdAt = System.currentTimeMillis())) }
        return id
    }

    fun removeHabit(id: String) = mutate { s -> s.copy(habits = s.habits.filterNot { it.id == id }) }

    fun addWater(ml: Int) = mutate { s ->
        val k = dayKey()
        s.copy(water = s.water + (k to ((s.water[k] ?: 0) + ml).coerceAtLeast(0)))
    }

    fun placeWidget(designId: String, w: Int, h: Int, style: String) =
        mutate { s -> s.copy(placed = s.placed + Placed(newId(), designId, w, h, style)) }

    fun removePlaced(id: String) = mutate { s -> s.copy(placed = s.placed.filterNot { it.id == id }) }
    fun updatePlaced(id: String, patch: (Placed) -> Placed) =
        mutate { s -> s.copy(placed = s.placed.map { if (it.id == id) patch(it) else it }) }

    fun setCompanion(p: (RobotPrefs) -> RobotPrefs) = mutate { it.copy(companion = p(it.companion)) }

    fun saveWidgetCfg(appWidgetId: Int, cfg: WidgetCfg) =
        mutate { s -> s.copy(widgetConfigs = s.widgetConfigs + (appWidgetId.toString() to cfg)) }

    fun removeWidgetCfg(appWidgetId: Int) =
        mutate { s -> s.copy(widgetConfigs = s.widgetConfigs - appWidgetId.toString()) }

    // ── downloads state ─────────────────────────────────────────
    fun upsertDl(item: DlItem) = mutate { s ->
        s.copy(downloads = listOf(item) + s.downloads.filterNot { it.id == item.id })
    }

    fun patchDl(id: String, patch: (DlItem) -> DlItem) =
        mutate { s -> s.copy(downloads = s.downloads.map { if (it.id == id) patch(it) else it }) }

    fun removeDl(id: String) = mutate { s -> s.copy(downloads = s.downloads.filterNot { it.id == id }) }
}
