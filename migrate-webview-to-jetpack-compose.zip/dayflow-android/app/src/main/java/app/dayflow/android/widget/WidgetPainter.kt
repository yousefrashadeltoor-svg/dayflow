package app.dayflow.android.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import app.dayflow.android.calendar.Calendars
import app.dayflow.android.data.State
import app.dayflow.android.data.Store
import app.dayflow.android.prayer.PrayerEngine
import app.dayflow.android.time.TimeFmt
import java.time.LocalTime
import java.time.ZonedDateTime
import java.util.Calendar
import java.util.Date
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Native widget renderer. Paints the selected design onto a bitmap the launcher
 * displays — honoring the design's style token, the chosen 12-hour clock, the
 * day's ornament family and real app state. The gateway size chosen on the
 * launcher maps to the design the user picks in the catalog.
 */
object WidgetPainter {

    data class StyleTok(val bg: Int, val bg2: Int?, val text: Int, val sub: Int, val accent: Int, val corner: Float, val border: Int?)

    fun styleTokens(style: String): StyleTok = when (style) {
        "oneui" -> StyleTok(0xB8FFFFFF.toInt(), null, 0xFF10161F.toInt(), 0x9910161F.toInt(), 0xFF3E7BFA.toInt(), 26f, 0xB3FFFFFF.toInt())
        "material" -> StyleTok(0xFFEDEAF2.toInt(), null, 0xFF49454F.toInt(), 0x9949454F.toInt(), 0xFF6750A4.toInt(), 28f, null)
        "ios" -> StyleTok(0xDBFFFFFF.toInt(), null, 0xFF000000.toInt(), 0x99000000.toInt(), 0xFF007AFF.toInt(), 22f, null)
        "editorial" -> StyleTok(0xFFFAF7F0.toInt(), null, 0xFF1A1814.toInt(), 0x991A1814.toInt(), 0xFF6B2D2D.toInt(), 6f, 0x331A1814)
        "neon" -> StyleTok(0xFF0B0820.toInt(), null, 0xFFF0E9FF.toInt(), 0x99F0E9FF.toInt(), 0xFFFF3FD8.toInt(), 14f, 0xB3FF3FD8.toInt())
        "paper" -> StyleTok(0xFFF4ECD8.toInt(), null, 0xFF3A2F1C.toInt(), 0x993A2F1C.toInt(), 0xFF8A5A2B.toInt(), 10f, null)
        "clay" -> StyleTok(0xFFECE6DD.toInt(), null, 0xFF3A332B.toInt(), 0x993A332B.toInt(), 0xFFC06C4A.toInt(), 30f, null)
        "outline" -> StyleTok(0x14FFFFFF, null, 0xFFFFFFFF.toInt(), 0x99FFFFFF, 0xFFFFFFFF.toInt(), 18f, 0xD9FFFFFF.toInt())
        "amoled" -> StyleTok(0xFF000000.toInt(), null, 0xFFF5F5F5.toInt(), 0x99F5F5F5, 0xFF4FD1C5.toInt(), 22f, null)
        else -> null
    } ?: run {
        val s = Store.current()
        val fam = Calendars.resolveDecor(java.time.LocalDate.now(), s.userDays).primary
        val fs = app.dayflow.android.patterns.Patterns.FAMILY[fam]!!
        StyleTok(rgbColor(fs.c2), rgbColor(fs.c1), 0xFFFFFFFF.toInt(), 0xCCFFFFFF, 0xFFFFFFFF.toInt(), 24f, null)
    }

    private fun rgbColor(c: androidx.compose.ui.graphics.Color): Int {
        val r = (c.red * 255).toInt(); val g = (c.green * 255).toInt(); val b = (c.blue * 255).toInt(); val a = (c.alpha * 255).toInt()
        return android.graphics.Color.argb(a, r, g, b)
    }

    fun render(ctx: Context, cfgId: String, style: String, wPx: Int, hPx: Int): Bitmap {
        val bmp = Bitmap.createBitmap(wPx.coerceAtLeast(64), hPx.coerceAtLeast(64), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val s = Store.current()
        val tok = styleTokens(style)

        // background
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        if (tok.bg2 != null) bgPaint.shader = LinearGradient(0f, 0f, wPx.toFloat(), hPx.toFloat(), tok.bg, tok.bg2, Shader.TileMode.CLAMP)
        else bgPaint.color = tok.bg
        val rect = RectF(0f, 0f, wPx.toFloat(), hPx.toFloat())
        canvas.drawRoundRect(rect, tok.corner * density(ctx), tok.corner * density(ctx), bgPaint)
        tok.border?.let {
            val bp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = it; style = Paint.Style.STROKE; strokeWidth = 1.5f * density(ctx) }
            canvas.drawRoundRect(rect, tok.corner * density(ctx), tok.corner * density(ctx), bp)
        }

        val design = WidgetCatalog.byId(cfgId)
        val arche = design?.arche ?: "digital"
        val pad = 14f * density(ctx)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = tok.text; typeface = Typeface.DEFAULT }

        when (arche) {
            "analog" -> drawAnalog(canvas, tok, wPx, hPx, pad, s)
            "prayer", "nextprayer" -> drawPrayer(canvas, tok, wPx, hPx, pad, s, arche == "nextprayer")
            "countdown" -> drawNextAlarm(canvas, tok, wPx, hPx, pad, s)
            "checklist" -> drawChecklist(canvas, ctx, tok, wPx, hPx, pad, s)
            "month" -> drawMonth(canvas, tok, wPx, hPx, pad)
            "drop" -> drawWater(canvas, tok, wPx, hPx, pad, s)
            "counter" -> drawTasbih(canvas, ctx, tok, wPx, hPx, pad, s)
            "ring" -> drawDayRing(canvas, tok, wPx, hPx, pad, s)
            "portrait" -> drawCompanion(canvas, tok, wPx, hPx, pad, s)
            else -> drawDigital(canvas, tok, wPx, hPx, pad, s)
        }
        return bmp
    }

    private fun density(ctx: Context) = ctx.resources.displayMetrics.density

    private fun textPaint(tok: StyleTok, sp: Float, bold: Boolean = false, ctx: Context) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = tok.text; textSize = sp * ctx.resources.displayMetrics.scaledDensity
        typeface = if (bold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
    }

    /** Minimal digital / bold block — 12h with ص/م. */
    private fun drawDigital(c: Canvas, tok: StyleTok, w: Int, h: Int, pad: Float, s: State) {
        val ctx = DayflowHolder.ctx
        val now = Calendar.getInstance()
        val parts = TimeFmt.clock12(now[Calendar.HOUR_OF_DAY], now[Calendar.MINUTE], s.lang)
        val big = textPaint(tok, 34f, true, ctx)
        val ly = h / 2f - (big.descent() + big.ascent()) / 2
        c.drawText(parts.time, pad, ly, big)
        val sufPaint = textPaint(tok, 14f, true, ctx).apply { color = tok.accent }
        c.drawText(parts.suffix, pad + big.measureText(parts.time) + 6 * density(ctx), ly, sufPaint)
        val datePaint = textPaint(tok, 11f, false, ctx).apply { color = tok.sub }
        c.drawText(TimeFmt.dateLine(Date(), s.lang), pad, ly + 18 * density(ctx), datePaint)
        drawOrnament(c, w, h, s, tok)
    }

    private fun drawAnalog(c: Canvas, tok: StyleTok, w: Int, h: Int, pad: Float, s: State) {
        val ctx = DayflowHolder.ctx
        val cx = w / 2f; val cy = h / 2f; val r = min(w, h) / 2f - pad
        val face = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = tok.sub; style = Paint.Style.STROKE; strokeWidth = 2f * density(ctx) }
        c.drawCircle(cx, cy, r, face)
        for (i in 0 until 12) {
            val a = i * Math.PI / 6
            val p1x = cx + r * 0.86f * cos(a).toFloat(); val p1y = cy + r * 0.86f * sin(a).toFloat()
            val p2x = cx + r * cos(a).toFloat(); val p2y = cy + r * sin(a).toFloat()
            face.strokeWidth = if (i % 3 == 0) 3f * density(ctx) else 1.5f * density(ctx)
            c.drawLine(p1x, p1y, p2x, p2y, face)
        }
        val now = Calendar.getInstance()
        val hd = (now[Calendar.HOUR] % 12) / 12f + now[Calendar.MINUTE] / 720f
        val md = now[Calendar.MINUTE] / 60f
        val hand = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = tok.text; strokeCap = Paint.Cap.ROUND }
        hand.strokeWidth = 4f * density(ctx)
        var a = hd * 2 * Math.PI - Math.PI / 2
        c.drawLine(cx, cy, cx + r * 0.5f * cos(a).toFloat(), cy + r * 0.5f * sin(a).toFloat(), hand)
        hand.strokeWidth = 2.5f * density(ctx)
        a = md * 2 * Math.PI - Math.PI / 2
        c.drawLine(cx, cy, cx + r * 0.72f * cos(a).toFloat(), cy + r * 0.72f * sin(a).toFloat(), hand)
        c.drawCircle(cx, cy, 4f * density(ctx), Paint(Paint.ANTI_ALIAS_FLAG).apply { color = tok.accent })
    }

    private fun drawPrayer(c: Canvas, tok: StyleTok, w: Int, h: Int, pad: Float, s: State, nextOnly: Boolean) {
        val ctx = DayflowHolder.ctx
        val city = PrayerEngine.CITIES[s.cityIndex.coerceIn(PrayerEngine.CITIES.indices)]
        val lat = s.customLat ?: city.lat; val lng = s.customLng ?: city.lng
        val zone = java.time.ZoneId.systemDefault()
        val now = ZonedDateTime.now(zone)
        val t = PrayerEngine.timesFor(now.toLocalDate(), lat, lng, zone)
        val next = PrayerEngine.next(now, lat, lng, zone)
        val title = textPaint(tok, 12f, true, ctx)
        c.drawText(if (s.lang == "ar") "الصلاة" else "Prayer", pad, pad + title.textSize * 0.2f, title)
        if (nextOnly && next != null) {
            val name = if (s.lang == "ar") PrayerEngine.NAMES_AR[next.p] else PrayerEngine.NAMES_EN[next.p]
            val time = TimeFmt.fmt(next.at.toLocalTime().toString().substring(0, 5), s.lang)
            val big = textPaint(tok, 26f, true, ctx)
            c.drawText("$name", pad, h / 2f + 6 * density(ctx), big)
            val tp = textPaint(tok, 18f, true, ctx).apply { color = tok.accent }
            c.drawText(time, pad, h / 2f + 30 * density(ctx), tp)
        } else {
            val order = PrayerEngine.P.entries
            val paint = textPaint(tok, 11f, false, ctx)
            val cellW = (w - pad * 2) / 6
            order.forEachIndexed { i, pKey ->
                val x = pad + i * cellW
                val tt = t[pKey]?.toString()?.substring(0, 5) ?: "--:--"
                val nm = if (s.lang == "ar") PrayerEngine.NAMES_AR[pKey] else PrayerEngine.NAMES_EN[pKey]
                val np = Paint(paint)
                if (next?.p == pKey) { np.color = tok.accent; np.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
                paint.textAlign = Paint.Align.CENTER; np.textAlign = Paint.Align.CENTER
                c.drawText(nm?.take(6) ?: "", x + cellW / 2, h / 2f, paint)
                c.drawText(TimeFmt.fmt(tt, s.lang), x + cellW / 2, h / 2f + 16 * density(ctx), np)
            }
            paint.textAlign = Paint.Align.LEFT
        }
    }

    private fun drawNextAlarm(c: Canvas, tok: StyleTok, w: Int, h: Int, pad: Float, s: State) {
        val ctx = DayflowHolder.ctx
        val next = app.dayflow.android.alarm.NextAlarm.soonest(s.alarms)
        val title = textPaint(tok, 11f, false, ctx).apply { color = tok.sub }
        c.drawText(if (s.lang == "ar") "المنبه التالي" else "Next alarm", pad, pad + title.textSize * 0.4f, title)
        if (next != null) {
            val big = textPaint(tok, 30f, true, ctx)
            c.drawText(TimeFmt.fmt(next.first.time, s.lang), pad, h / 2f + 14 * density(ctx), big)
            val sub = textPaint(tok, 11f, false, ctx).apply { color = tok.sub }
            c.drawText(TimeFmt.until(next.second.time - System.currentTimeMillis(), s.lang), pad, h / 2f + 36 * density(ctx), sub)
        } else {
            val big = textPaint(tok, 13f, false, ctx).apply { color = tok.sub }
            c.drawText(if (s.lang == "ar") "لا منبهات مفعّلة" else "No alarms on", pad, h / 2f + 6 * density(ctx), big)
        }
    }

    private fun drawChecklist(c: Canvas, ctx: Context, tok: StyleTok, w: Int, h: Int, pad: Float, s: State) {
        val today = Store.dayKey()
        val list = s.tasks.filter { it.date == today }.take(4)
        val title = textPaint(tok, 11f, true, ctx)
        c.drawText(if (s.lang == "ar") "مهام اليوم" else "Today's tasks", pad, pad + title.textSize * 0.3f, title)
        val rowH = (h - pad * 2 - 20 * density(ctx)) / 4
        list.forEachIndexed { i, t ->
            val y = pad + 24 * density(ctx) + i * rowH
            val box = RectF(pad, y, pad + 16 * density(ctx), y + 16 * density(ctx))
            val bp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = tok.accent; style = if (t.done) Paint.Style.FILL else Paint.Style.STROKE; strokeWidth = 2f * density(ctx) }
            c.drawRoundRect(box, 5 * density(ctx), 5 * density(ctx), bp)
            val tp = textPaint(tok, 12f, false, ctx).apply { color = if (t.done) tok.sub else tok.text }
            c.drawText(t.title.take(24), pad + 22 * density(ctx), y + 12 * density(ctx), tp)
        }
    }

    private fun drawMonth(c: Canvas, tok: StyleTok, w: Int, h: Int, pad: Float) {
        val ctx = DayflowHolder.ctx
        val cal = Calendar.getInstance()
        val day = cal[Calendar.DAY_OF_MONTH]
        val big = textPaint(tok, 40f, true, ctx)
        c.drawText(TimeFmt.num(day, Store.current().lang), pad, h / 2f + 14 * density(ctx), big)
        val month = textPaint(tok, 12f, false, ctx).apply { color = tok.sub }
        c.drawText(TimeFmt.dateLine(Date(), Store.current().lang).substringAfter(", "), pad, h / 2f + 34 * density(ctx), month)
    }

    private fun drawWater(c: Canvas, tok: StyleTok, w: Int, h: Int, pad: Float, s: State) {
        val ctx = DayflowHolder.ctx
        val ml = s.water[Store.dayKey()] ?: 0
        val pct = (ml.toFloat() / s.waterGoal).coerceIn(0f, 1f)
        val cx = w / 2f; val cy = h / 2f; val r = min(w, h) / 2f - pad
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 7f * density(ctx); color = tok.sub }
        c.drawCircle(cx, cy, r, ring)
        ring.color = 0xFF3AA0FF.toInt(); ring.strokeCap = Paint.Cap.ROUND
        c.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -90f, 360f * pct, false, ring)
        val t = textPaint(tok, 13f, true, ctx).apply { textAlign = Paint.Align.CENTER }
        c.drawText("${TimeFmt.num(String.format("%.1f", ml / 1000f), s.lang)} L", cx, cy + 5 * density(ctx), t)
    }

    private fun drawTasbih(c: Canvas, ctx: Context, tok: StyleTok, w: Int, h: Int, pad: Float, s: State) {
        val big = textPaint(tok, 34f, true, ctx).apply { textAlign = Paint.Align.CENTER }
        c.drawText(TimeFmt.num(s.tasbih, s.lang), w / 2f, h / 2f + 12 * density(ctx), big)
        val sub = textPaint(tok, 11f, false, ctx).apply { color = tok.sub; textAlign = Paint.Align.CENTER }
        c.drawText(if (s.lang == "ar") "تسبيح — اضغط للعد" else "Tasbih — tap to count", w / 2f, h / 2f + 32 * density(ctx), sub)
    }

    private fun drawDayRing(c: Canvas, tok: StyleTok, w: Int, h: Int, pad: Float, s: State) {
        val ctx = DayflowHolder.ctx
        val now = Calendar.getInstance()
        val pct = (now[Calendar.HOUR_OF_DAY] * 60 + now[Calendar.MINUTE]) / 1440f
        val cx = w / 2f; val cy = h / 2f; val r = min(w, h) / 2f - pad
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 7f * density(ctx); color = tok.sub }
        c.drawCircle(cx, cy, r, ring)
        ring.color = tok.accent; ring.strokeCap = Paint.Cap.ROUND
        c.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -90f, 360f * pct, false, ring)
        val t = textPaint(tok, 13f, true, ctx).apply { textAlign = Paint.Align.CENTER }
        c.drawText("${TimeFmt.num((pct * 100).toInt(), s.lang)}%", cx, cy + 5 * density(ctx), t)
    }

    private fun drawCompanion(c: Canvas, tok: StyleTok, w: Int, h: Int, pad: Float, s: State) {
        val ctx = DayflowHolder.ctx
        val tip = run {
            val today = Store.dayKey()
            val mine = s.tasks.filter { it.date == today }
            if (mine.isNotEmpty() && mine.all { it.done }) "خلصت كل مهام النهاردة!"
            else if (mine.isNotEmpty()) "لسه ${TimeFmt.num(mine.count { !it.done }, s.lang)} مهام مستنياك"
            else "يومك هادي — خطط حاجة جميلة"
        }
        val t = textPaint(tok, 13f, false, ctx)
        var y = pad + t.textSize
        for (line in wrap(tip, t, w - pad * 2)) { c.drawText(line, pad, y, t); y += t.textSize * 1.3f }
        drawOrnament(c, w, h, s, tok)
    }

    private fun drawOrnament(c: Canvas, w: Int, h: Int, s: State, tok: StyleTok) {
        if (s.decorSurfaces["widgets"] != true || s.intensity == "off") return
        val fam = Calendars.resolveDecor(java.time.LocalDate.now(), s.userDays).primary
        val fs = app.dayflow.android.patterns.Patterns.FAMILY[fam]!!
        // small corner motif, low key
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = rgbColor(fs.c3).let { it and 0x00FFFFFF or 0x66000000 } ; style = Paint.Style.STROKE; strokeWidth = 2f }
        val cx = w - 26 * density(DayflowHolder.ctx); val cy = 26 * density(DayflowHolder.ctx)
        val n = 8; val r = 12 * density(DayflowHolder.ctx)
        val path = Path()
        for (i in 0 until n * 2) {
            val rr = if (i % 2 == 1) r * 0.45f else r
            val a = i * Math.PI / n - Math.PI / 2
            val x = cx + rr * cos(a).toFloat(); val yy = cy + rr * sin(a).toFloat()
            if (i == 0) path.moveTo(x, yy) else path.lineTo(x, yy)
        }
        path.close()
        c.drawPath(path, paint)
    }

    private fun wrap(text: String, paint: Paint, maxW: Float): List<String> {
        val words = text.split(" "); val lines = mutableListOf<String>(); var cur = ""
        for (wd in words) {
            val t = if (cur.isEmpty()) wd else "$cur $wd"
            if (paint.measureText(t) > maxW && cur.isNotEmpty()) { lines += cur; cur = wd } else cur = t
        }
        if (cur.isNotEmpty()) lines += cur
        return lines
    }
}

/** Lightweight holder so the painter can reach a Context from provider callbacks. */
object DayflowHolder { lateinit var ctx: Context }
