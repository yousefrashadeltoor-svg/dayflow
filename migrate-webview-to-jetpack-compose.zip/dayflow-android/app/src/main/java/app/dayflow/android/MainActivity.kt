package app.dayflow.android

import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import app.dayflow.android.data.Store
import app.dayflow.android.download.LinkAnalyzer
import app.dayflow.android.ui.DayflowTheme
import app.dayflow.android.ui.shell.AppShell
import app.dayflow.android.ui.theme.themeById
import app.dayflow.android.widget.DayflowHolder

/**
 * Native host. Everything below setContent is Jetpack Compose — no WebView.
 * Incoming share intents land straight in the Downloads tab, pre-analyzed.
 */
class MainActivity : ComponentActivity() {

    private var pendingShare by mutableStateOf<String?>(null)
    private var startTab by mutableStateOf("today")
    private var startSub by mutableStateOf<String?>(null)

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DayflowHolder.ctx = applicationContext
        app.dayflow.android.ui.shell.LocalContextHolder.ctx = applicationContext
        WindowCompat.setDecorFitsSystemWindows(window, false)

        handleIntent(intent)

        // Android 13+ notification runtime permission — asked once, in-app.
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)

        setContent {
            val s by Store.state.collectAsState()
            DayflowTheme(pack = themeById(s.themeId), rtl = s.lang == "ar") {
                AppShell(
                    initialTab = startTab,
                    initialSub = startSub,
                    sharedLink = pendingShare,
                    onShareConsumed = { pendingShare = null },
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        when (i.action) {
            Intent.ACTION_SEND -> {
                val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
                val url = LinkAnalyzer.extractUrls(text).firstOrNull() ?: text.trim()
                pendingShare = url
                startTab = "downloads"
            }
        }
        i.getStringExtra("tab")?.let { tab ->
            val parts = tab.split(":")
            startTab = parts[0]
            startSub = parts.getOrNull(1)
        }
        i.getIntExtra("widgetId", AppWidgetManager.INVALID_APPWIDGET_ID).takeIf { it != AppWidgetManager.INVALID_APPWIDGET_ID }?.let {
            startTab = "me"; startSub = "widgets"
        }
    }
}
