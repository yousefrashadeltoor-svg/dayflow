package app.dayflow.android.companion

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import app.dayflow.android.calendar.Calendars.Family
import app.dayflow.android.patterns.Patterns
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * The DAYFLOW companion, drawn natively on Canvas — the same body, same gradients,
 * same proportions as the in-app SVG robot — plus the full physics rig:
 * verlet chains for arms/legs/antennae, spring head/tilt, breathing, eye tracking,
 * blinking, and every seasonal outfit (lantern, scarf, ribbon, party hat, flower, star).
 */
object RobotModel {

    const val BW = 120f
    const val BH = 154f

    // ── physics ─────────────────────────────────────────────────
    class Pt(var x: Float, var y: Float) { var px = x; var py = y }

    class Chain(anchorX: Float, anchorY: Float, segs: Int, len: Float, val kx: Float = 0f, val ky: Float = 0f) {
        val pts = Array(segs + 1) { Pt(anchorX + kx * i(it), anchorY + ky * i(it)) }
        private fun i(n: Int) = n * len
        fun step(ax: Float, ay: Float, gx: Float, gy: Float, dt: Float, stiffness: Float) {
            pts[0].x = ax; pts[0].y = ay
            for (i in 1 until pts.size) {
                val p = pts[i]
                val vx = (p.x - p.px) * 0.92f
                val vy = (p.y - p.py) * 0.92f
                p.px = p.x; p.py = p.y
                p.x += vx + gx * dt * dt * 0.05f
                p.y += vy + gy * dt * dt * 0.05f
            }
            repeat(2) {
                for (i in 0 until pts.size - 1) {
                    val a = pts[i]; val b = pts[i + 1]
                    val dx = b.x - a.x; val dy = b.y - a.y
                    val d = sqrt(dx * dx + dy * dy).coerceAtLeast(0.001f)
                    val diff = (d - i(1)) / d * stiffness
                    val ox = dx * diff; val oy = dy * diff
                    if (i == 0) { b.x -= ox; b.y -= oy } else { a.x += ox / 2; b.x -= ox / 2; a.y += oy / 2; b.y -= oy / 2 }
                }
            }
        }
    }

    class Spring(var v: Float = 0f, var w: Float = 0f) {
        fun step(target: Float, k: Float, damp: Float, dt: Float, lo: Float, hi: Float) {
            w += ((target - v) * k - w * damp) * dt
            v = (v + w * dt).coerceIn(lo, hi)
        }
    }

    /** Whole-body rig state, matching the web chains configuration. */
    class Rig {
        val arms = listOf(Chain(34f, 78f, 3, 18f, 1.9f * 0.55f, 1.3f * 0.7f), Chain(86f, 78f, 3, 18f, 1.25f * 0.55f, 1.3f * 0.7f))
        val legs = listOf(Chain(48f, 118f, 2, 16f, -0.3f, 1.0f), Chain(72f, 118f, 2, 16f, 0.3f, 1.0f))
        val ant = listOf(Chain(50f, 22f, 3, 11f, -0.5f, -0.9f), Chain(70f, 22f, 3, 11f, 0.5f, -0.9f))
        val head = Spring(); val tilt = Spring()
        var lookX = 0f; var lookY = 0f
        var vx = 0f; var vy = 0f
        var gx = 0f; var gy = 900f
        var dragging = false

        fun step(nowMs: Long, dt: Float) {
            val breathe = sin(nowMs / 900f) * 0.6f
            tilt.step(max(-0.5f, min(0.5f, -vx / 1600f)), 60f, 9f, dt, -0.5f, 0.5f)
            head.step(lookX * 0.18f + gx / 5000f - vx / 4000f, 40f, 7f, dt, -0.45f, 0.45f)
            arms.forEachIndexed { i, c -> c.step(if (i == 1) 86f else 34f, 78f + breathe, gx - vx * 3, gy - vy * 2, dt, 0.5f) }
            legs.forEachIndexed { i, c -> c.step(if (i == 1) 72f else 48f, 118f, gx - vx * 3, gy - vy * 2, dt, 0.5f) }
            val h = head.v * 0.52f
            ant.forEachIndexed { i, c ->
                val ax = if (i == 1) 70f else 50f; val ay = 22f
                val rx = 60f + (ax - 60f) * cos(h) - (64f - 64f) * sin(h) - (ay - 64f) * sin(h)
                val ry = 64f + (ax - 60f) * sin(h) + (ay - 64f) * cos(h)
                c.step(rx, ry, gx * 0.6f, gy * 0.6f, dt, 0.5f)
            }
        }
    }

    // ── drawing (exact port of RobotBody) ───────────────────────
    fun DrawScope.drawRobot(
        rig: Rig?, mood: String, family: Family, accent: Color, accent2: Color,
        nowMs: Long, headStatic: Float = 0f, eyeOff: Offset = Offset.Zero,
    ) {
        val breathe = sin(nowMs / 900f) * 0.6f
        val bodyGrad = Brush.radialGradient(
            listOf(Color.White, if (mood == "cold") Color(0xffcfe3f5) else Color(0xffd9e2ee), Color(0xff8d9bb0)),
            center = Offset(BW * 0.35f, BH * 0.3f), radius = BH * 0.8f,
        )
        val visorGrad = Brush.radialGradient(
            listOf(if (mood == "sad") Color(0xff3d3a52) else Color(0xff3a4a66), Color(0xff0d1424)),
            center = Offset(BW * 0.4f, BH * 0.3f), radius = 90f,
        )
        val limbGrad = Brush.linearGradient(listOf(Color(0xffc3cddb), Color(0xff7d8aa0)))

        // ground shadow
        drawOval(Color.Black.copy(alpha = 0.15f), topLeft = Offset(60f - 26f, 142f), size = androidx.compose.ui.geometry.Size(52f, 8f))

        // celebrate stars
        if (mood == "celebrate") {
            for (i in 0..4) {
                val tw = 0.25f + 0.75f * abs(sin(nowMs / 480f + i))
                drawPath(Patterns.star(18f + i * 22f, 8f + (i % 2) * 8f, 5, 4f, 1.6f), accent2, alpha = tw)
            }
        }

        val legs = rig?.legs?.map { c -> c.pts.map { Offset(it.x, it.y) } }
            ?: listOf(listOf(Offset(48f, 118f), Offset(46f, 134f)), listOf(Offset(72f, 118f), Offset(74f, 134f)))
        legs.forEach { poly ->
            val path = Path().apply { moveTo(poly[0].x, poly[0].y); poly.drop(1).forEach { lineTo(it.x, it.y) } }
            drawPath(path, limbGrad, style = Stroke(9f, cap = androidx.compose.ui.graphics.StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
        }

        val arms = rig?.arms?.map { c -> c.pts.map { Offset(it.x, it.y) } }
            ?: listOf(
                listOf(Offset(34f, 78f), Offset(24f, 96f), Offset(20f, 114f)),
                listOf(Offset(86f, 78f), Offset(96f, 96f), Offset(100f, 114f)),
            )
        arms.forEach { poly ->
            val path = Path().apply { moveTo(poly[0].x, poly[0].y); poly.drop(1).forEach { lineTo(it.x, it.y) } }
            drawPath(path, limbGrad, style = Stroke(8f, cap = androidx.compose.ui.graphics.StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
            val hand = poly.last()
            drawCircle(Color(0xffe7edf5), radius = 5.5f, center = hand)
            drawCircle(Color(0xff8d9bb0), radius = 5.5f, center = hand, style = Stroke(1f))
        }

        // body
        drawRoundRect(bodyGrad, topLeft = Offset(34f, 66f), size = androidx.compose.ui.geometry.Size(52f, 56f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f))
        drawRoundRect(Color(0xff7f8ca2), topLeft = Offset(34f, 66f), size = androidx.compose.ui.geometry.Size(52f, 56f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f), style = Stroke(1f))
        // chest screen
        drawRoundRect(Color(0xff0f1a2c), topLeft = Offset(47f, 80f), size = androidx.compose.ui.geometry.Size(26f, 16f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(5f))
        val tw = 0.6f + 0.4f * sin(nowMs / 700f)
        drawCircle(accent, radius = 4f, center = Offset(60f, 88f), alpha = tw)

        // head (rotates around 60,64)
        val headA = rig?.head?.v ?: headStatic
        rotate(degrees = headA * 30f, pivot = Offset(60f, 64f)) {
            val ant = rig?.ant?.map { c -> c.pts.map { Offset(it.x, it.y) } }
                ?: listOf(listOf(Offset(50f, 22f), Offset(44f, 10f), Offset(40f, 0f)), listOf(Offset(70f, 22f), Offset(76f, 10f), Offset(80f, 0f)))
            ant.forEach { poly ->
                val path = Path().apply { moveTo(poly[0].x, poly[0].y); poly.drop(1).forEach { lineTo(it.x, it.y) } }
                drawPath(path, Color(0xff7d8aa0), style = Stroke(2.5f, cap = androidx.compose.ui.graphics.StrokeCap.Round))
                val tip = poly.last()
                val thinking = mood == "think"
                val tipGlow = if (thinking) 0.5f + 0.5f * abs(sin(nowMs / 300f)) else 1f
                drawCircle(if (thinking) Color(0xffffd36b) else accent2, radius = 4f, center = tip, alpha = tipGlow)
            }
            drawRoundRect(bodyGrad, topLeft = Offset(30f, 20f), size = androidx.compose.ui.geometry.Size(60f, 46f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(20f))
            drawRoundRect(Color(0xff7f8ca2), topLeft = Offset(30f, 20f), size = androidx.compose.ui.geometry.Size(60f, 46f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(20f), style = Stroke(1f))
            drawRoundRect(visorGrad, topLeft = Offset(37f, 29f), size = androidx.compose.ui.geometry.Size(46f, 28f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(13f))

            val looks = rig?.let { Offset(it.lookX, it.lookY) } ?: eyeOff
            val eyeY = 43f + looks.y * 2f - if (mood == "think") 2f else 0f
            val blink = 0.75f + 0.25f * abs(sin(nowMs / 1450f))
            when (mood) {
                "sleep", "wink" -> {
                    val p1 = Path().apply { moveTo(46f, 44f); quadraticTo(50f, 47f, 54f, 44f) }
                    drawPath(p1, Color(0xff7fd6ff), style = Stroke(2.5f, cap = androidx.compose.ui.graphics.StrokeCap.Round))
                    if (mood == "wink") drawLine(Color(0xff7fd6ff), Offset(66f, 44f), Offset(74f, 44f), strokeWidth = 2.5f, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                    else drawPath(Path().apply { moveTo(66f, 44f); quadraticTo(70f, 47f, 74f, 44f) }, Color(0xff7fd6ff), style = Stroke(2.5f, cap = androidx.compose.ui.graphics.StrokeCap.Round))
                }
                "sad" -> {
                    drawPath(Path().apply { moveTo(46f, 46f); quadraticTo(50f, 43f, 54f, 46f) }, Color(0xff7fd6ff), style = Stroke(2.5f, cap = androidx.compose.ui.graphics.StrokeCap.Round))
                    drawPath(Path().apply { moveTo(66f, 46f); quadraticTo(70f, 43f, 74f, 46f) }, Color(0xff7fd6ff), style = Stroke(2.5f, cap = androidx.compose.ui.graphics.StrokeCap.Round))
                }
                "happy", "celebrate" -> {
                    drawPath(Path().apply { moveTo(46f, 46f); quadraticTo(50f, 41f, 54f, 46f) }, Color(0xff7fd6ff), style = Stroke(2.8f, cap = androidx.compose.ui.graphics.StrokeCap.Round))
                    drawPath(Path().apply { moveTo(66f, 46f); quadraticTo(70f, 41f, 74f, 46f) }, Color(0xff7fd6ff), style = Stroke(2.8f, cap = androidx.compose.ui.graphics.StrokeCap.Round))
                }
                else -> {
                    drawOval(Color(0xff7fd6ff), topLeft = Offset(50f + looks.x * 3f - 4f, eyeY - if (mood == "worried") 5.5f else 5f), size = androidx.compose.ui.geometry.Size(8f, if (mood == "worried") 11f else 10f), alpha = blink)
                    drawOval(Color(0xff7fd6ff), topLeft = Offset(70f + looks.x * 3f - 4f, eyeY - if (mood == "worried") 5.5f else 5f), size = androidx.compose.ui.geometry.Size(8f, if (mood == "worried") 11f else 10f), alpha = blink)
                }
            }
            if (mood == "happy") { drawOval(Color(0xffff9ab5), topLeft = Offset(39f, 50.8f), size = androidx.compose.ui.geometry.Size(8f, 4.4f), alpha = 0.65f); drawOval(Color(0xffff9ab5), topLeft = Offset(73f, 50.8f), size = androidx.compose.ui.geometry.Size(8f, 4.4f), alpha = 0.65f) }
            if (mood == "cold") { drawOval(Color(0xff9fd6ff), topLeft = Offset(39f, 50.8f), size = androidx.compose.ui.geometry.Size(8f, 4.4f), alpha = 0.5f); drawOval(Color(0xff9fd6ff), topLeft = Offset(73f, 50.8f), size = androidx.compose.ui.geometry.Size(8f, 4.4f), alpha = 0.5f) }
            if (mood == "sad") drawPath(Path().apply { moveTo(71f, 50f); quadraticTo(73f, 55f, 71f, 57f); quadraticTo(68f, 55f, 71f, 50f); close() }, Color(0xff8fd8ff), alpha = 0.9f)
            if (mood == "worried") drawPath(Path().apply { moveTo(82f, 34f); quadraticTo(85f, 39f, 82f, 41f); quadraticTo(78f, 39f, 82f, 34f); close() }, Color(0xffbfe8ff), alpha = 0.9f)
            // visor glint
            drawOval(Color.White, topLeft = Offset(36f, 23.5f), size = androidx.compose.ui.geometry.Size(16f, 6f), alpha = 0.7f)
        }

        // outfit (same seasonal logic as the SVG <Outfit/>)
        val hand = arms.last().last()
        val st = Patterns.FAMILY[family] ?: return
        when (family) {
            Family.ramadan -> {
                Patterns.lantern(hand.x, hand.y, 22f).forEachIndexed { i, p ->
                    drawPath(p, if (i == 1) st.c3 else st.c1, alpha = if (i == 1) 0.95f else 1f, style = if (i == 1) androidx.compose.ui.graphics.drawscope.Fill else Stroke(1f))
                    if (i != 1) drawPath(p, st.c1, style = Stroke(1f))
                }
                drawCircle(Color(0xffffd36b), radius = 3f, center = Offset(hand.x, hand.y + 12f), alpha = 0.9f)
            }
            Family.winter -> {
                drawPath(Path().apply { moveTo(42f, 64f); quadraticTo(60f, 74f, 78f, 64f); lineTo(82f, 78f); quadraticTo(60f, 88f, 38f, 78f); close() }, Color(0xffc8453b))
                drawPath(Path().apply { moveTo(42f, 64f); quadraticTo(60f, 74f, 78f, 64f); lineTo(82f, 78f); quadraticTo(60f, 88f, 38f, 78f); close() }, Color(0xff8f2a22), style = Stroke(0.8f))
                drawPath(Path().apply { moveTo(72f, 80f); lineTo(79f, 106f); lineTo(70f, 106f); close() }, Color(0xffc8453b))
            }
            Family.national -> {
                drawLine(Color(0xffce1126), Offset(40f, 70f), Offset(82f, 100f), strokeWidth = 5f, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                drawLine(Color.White, Offset(40f, 75f), Offset(80f, 104f), strokeWidth = 4f, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                drawLine(Color(0xff111111), Offset(40f, 80f), Offset(78f, 108f), strokeWidth = 4f, cap = androidx.compose.ui.graphics.StrokeCap.Round)
            }
            Family.eid, Family.birthday, Family.newyear -> {
                drawPath(Path().apply { moveTo(50f, 22f); lineTo(60f, -4f); lineTo(70f, 22f); close() }, st.c1)
                drawPath(Path().apply { moveTo(50f, 22f); lineTo(60f, -4f); lineTo(70f, 22f); close() }, st.c2, style = Stroke(1f))
                drawCircle(st.c2, radius = 3f, center = Offset(60f, -5f))
            }
            Family.spring, Family.love -> {
                if (family == Family.love) drawPath(Patterns.heart(80f, 26f, 8f), st.c1)
                else drawPath(Patterns.lotus(80f, 26f, 10f, 5), st.c1)
            }
            Family.islamic, Family.friday -> drawPath(Patterns.star(60f, 54f, 8, 8f, 3f), st.c2)
            else -> { if (mood == "happy") drawPath(Patterns.lotus(80f, 26f, 10f, 5), st.c1) }
        }

        if (mood == "celebrate") {
            drawCircle(st.c3, radius = 2f, center = Offset(18f, 30f), alpha = 0.9f)
            drawCircle(st.c3, radius = 2.5f, center = Offset(104f, 24f), alpha = 0.9f)
            drawCircle(st.c3, radius = 1.8f, center = Offset(100f, 60f), alpha = 0.9f)
        }
    }
}

private val Fill = androidx.compose.ui.graphics.drawscope.Fill
