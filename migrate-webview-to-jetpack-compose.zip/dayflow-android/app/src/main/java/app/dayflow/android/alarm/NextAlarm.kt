package app.dayflow.android.alarm

import app.dayflow.android.data.Alarm
import java.util.Calendar
import java.util.Date

/**
 * Next-occurrence resolver — exact port of the web `nextAlarmTime` semantics:
 * - one-time dated alarm fires once, then auto-disables;
 * - weekly alarms repeat on selected days (0=Sun..6=Sat);
 * - an optional `date` acts as a start anchor for repeat alarms.
 */
object NextAlarm {

    fun validTime(t: String): Boolean {
        val p = t.split(":")
        return p.size >= 2 && p[0].toIntOrNull() in 0..23 && p[1].toIntOrNull() in 0..59
    }

    fun nextTime(a: Alarm, from: Date = Date()): Date? {
        if (!a.enabled || !validTime(a.time)) return null
        val h = a.time.substringBefore(":").toInt()
        val m = a.time.substringAfter(":").substringBefore(":").toInt()
        if (a.date != null && a.days.isEmpty()) {
            val c = Calendar.getInstance()
            runCatching {
                val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                c.time = fmt.parse(a.date)!!
            }
            c.set(Calendar.HOUR_OF_DAY, h); c.set(Calendar.MINUTE, m)
            c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
            return if (c.time.after(from)) c.time else null
        }
        val anchor = Calendar.getInstance()
        runCatching {
            if (a.date != null && a.days.isNotEmpty()) {
                val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                val d = fmt.parse(a.date)!!
                if (d.after(from)) anchor.time = d
            }
        }
        for (i in 0..7) {
            val c = anchor.clone() as Calendar
            c.add(Calendar.DAY_OF_YEAR, i)
            c.set(Calendar.HOUR_OF_DAY, h); c.set(Calendar.MINUTE, m)
            c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
            if (!c.time.after(from)) continue
            if (a.date != null) {
                val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                if (fmt.format(c.time) < a.date) continue
            }
            val dow = c.get(Calendar.DAY_OF_WEEK) - 1 // Calendar Sunday=1 → our Sunday=0
            if (a.days.isNotEmpty() && dow !in a.days) continue
            return c.time
        }
        return null
    }

    fun soonest(alarms: List<Alarm>, from: Date = Date()): Pair<Alarm, Date>? =
        alarms.mapNotNull { a -> nextTime(a, from)?.let { a to it } }.minByOrNull { it.second }
}
