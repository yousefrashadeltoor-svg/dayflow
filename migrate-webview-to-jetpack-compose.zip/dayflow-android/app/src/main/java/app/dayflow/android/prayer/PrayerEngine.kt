package app.dayflow.android.prayer

import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tan

/**
 * On-device astronomical prayer-time engine.
 *
 * Fixes in the web build that are resolved here:
 *  - The web version used a hard-coded fixed UTC offset per city (Egypt = +2 always),
 *    which is wrong during DST (Egypt observes GMT+3 from the last Friday of April
 *    to the last Thursday of October). This engine reads the **device time-zone rules**
 *    through java.time (`Africa/Cairo` etc.), so results are correct year-round.
 *  - The city list lacked Giza and most Egyptian cities — added below.
 *  - Next-prayer rollover past midnight now carries the actual next-day Fajr,
 *    not a duplicated same-day time.
 *
 * Method (unchanged from the app's design): Egyptian General Survey Authority —
 * Fajr 19.5°, Isha 17.5°, Sunrise/Sunset 0.833°, Asr standard (Shafi'i, shadow factor 1).
 */
object PrayerEngine {

    data class City(val lat: Double, val lng: Double, val en: String, val ar: String)

    val CITIES = listOf(
        City(30.0444, 31.2357, "Cairo", "القاهرة"),
        City(30.0131, 31.2089, "Giza", "الجيزة"),
        City(31.2001, 29.9187, "Alexandria", "الإسكندرية"),
        City(30.5965, 32.2715, "Port Said", "بورسعيد"),
        City(29.9668, 32.5498, "Suez", "السويس"),
        City(31.0348, 31.3785, "Mansoura", "المنصورة"),
        City(30.4665, 31.1848, "Qalyub", "قليوب"),
        City(30.5927, 30.5080, "Zagazig", "الزقازيق"),
        City(27.2579, 33.8116, "Hurghada", "الغردقة"),
        City(27.9158, 34.3299, "Sharm El-Sheikh", "شرم الشيخ"),
        City(25.6872, 32.6396, "Luxor", "الأقصر"),
        City(24.0889, 32.8998, "Aswan", "أسوان"),
        City(21.4225, 39.8262, "Makkah", "مكة المكرمة"),
        City(24.4686, 39.6142, "Madinah", "المدينة المنورة"),
        City(25.2048, 55.2708, "Dubai", "دبي"),
        City(51.5074, -0.1278, "London", "لندن"),
    )

    const val FAJR_ANGLE = 19.5
    const val ISHA_ANGLE = 17.5
    const val SUN_ALT = 0.833

    enum class P { FAJR, SUNRISE, DHUHR, ASR, MAGHRIB, ISHA }

    val NAMES_AR = mapOf(
        P.FAJR to "الفجر", P.SUNRISE to "الشروق", P.DHUHR to "الظهر",
        P.ASR to "العصر", P.MAGHRIB to "المغرب", P.ISHA to "العشاء",
    )
    val NAMES_EN = mapOf(
        P.FAJR to "Fajr", P.SUNRISE to "Sunrise", P.DHUHR to "Dhuhr",
        P.ASR to "Asr", P.MAGHRIB to "Maghrib", P.ISHA to "Isha",
    )

    /** Prayer → LocalTime for one civil date, in the given zone (device zone by default). */
    fun timesFor(date: LocalDate, lat: Double, lng: Double, zone: ZoneId = ZoneId.systemDefault()): Map<P, LocalTime?> {
        val jd = julian(date)
        val d = jd - 2451545.0
        val g = deg2rad(357.529 + 0.98560028 * d)
        val q = 280.459 + 0.98564736 * d
        val L = deg2rad(norm360(q + 1.915 * sin(g) + 0.020 * sin(2 * g)))
        val e = deg2rad(23.439 - 0.00000036 * d)
        val ra = norm24(rad2deg(atan2(cos(e) * sin(L), cos(L))) / 15)
        val decl = asin(sin(e) * sin(L))
        val eqt = q / 15 - norm24(ra)

        // True zone offset for THIS date (honors Egypt's DST windows automatically).
        val offsetHours = zone.rules.getOffset(
            ZonedDateTime.of(date, LocalTime.NOON, zone).toInstant()
        ).totalSeconds / 3600.0

        val midDay = norm24(12 + offsetHours - lng / 15 - eqt)

        fun hourAngle(alt: Double): Double? {
            val cosH = (sin(deg2rad(alt)) - sin(deg2rad(lat)) * sin(decl)) /
                (cos(deg2rad(lat)) * cos(decl))
            if (cosH > 1 || cosH < -1) return null
            return rad2deg(acos(cosH)) / 15
        }

        fun atAngle(alt: Double, before: Boolean): Double? =
            hourAngle(alt)?.let { norm24(if (before) midDay - it else midDay + it) }

        // Asr (Shafi'i: shadow factor = 1)
        val asrAlt = rad2deg(atan(1.0 / (1.0 + tan(kotlin.math.abs(deg2rad(lat)) - decl))))
        val asr = atAngle(asrAlt, before = false)

        fun toTime(h: Double?): LocalTime? {
            if (h == null || h.isNaN()) return null
            val totalMin = (h * 60).roundToInt()
            return LocalTime.of((totalMin / 60) % 24, totalMin % 60)
        }

        return mapOf(
            P.FAJR to toTime(atAngle(-FAJR_ANGLE, before = true)),
            P.SUNRISE to toTime(atAngle(-SUN_ALT, before = true)),
            P.DHUHR to toTime(midDay),
            P.ASR to toTime(asr),
            P.MAGHRIB to toTime(atAngle(-SUN_ALT, before = false)),
            P.ISHA to toTime(atAngle(-ISHA_ANGLE, before = false)),
        )
    }

    data class Next(val p: P, val at: ZonedDateTime)

    /** Next upcoming prayer (rolls over to tomorrow's Fajr after Isha). */
    fun next(now: ZonedDateTime, lat: Double, lng: Double, zone: ZoneId = ZoneId.systemDefault()): Next? {
        val today = timesFor(now.toLocalDate(), lat, lng, zone)
        val order = listOf(P.FAJR, P.SUNRISE, P.DHUHR, P.ASR, P.MAGHRIB, P.ISHA)
        for (p in order) {
            val t = today[p] ?: continue
            val at = ZonedDateTime.of(now.toLocalDate(), t, zone)
            if (at.isAfter(now)) return Next(p, at)
        }
        val tomorrow = timesFor(now.toLocalDate().plusDays(1), lat, lng, zone)
        return tomorrow[P.FAJR]?.let { Next(P.FAJR, ZonedDateTime.of(now.toLocalDate().plusDays(1), it, zone)) }
    }

    /** Daylight period buckets used by the ambience system (same boundaries as the web build). */
    fun periodAt(now: ZonedDateTime, t: Map<P, LocalTime?>): String {
        fun m(p: P, fallback: Int) = t[p]?.let { it.hour * 60 + it.minute } ?: fallback
        val cur = now.hour * 60 + now.minute
        val f = m(P.FAJR, 270); val sr = m(P.SUNRISE, 360); val dh = m(P.DHUHR, 720)
        val asr = m(P.ASR, 900); val mg = m(P.MAGHRIB, 1065); val ish = m(P.ISHA, 1150)
        return when {
            cur in f until sr + 60 -> "fajr"
            cur in sr + 60 until dh - 30 -> "morning"
            cur in dh - 30 until asr -> "noon"
            cur in asr until mg - 20 -> "asr"
            cur in mg - 20 until ish + 30 -> "maghrib"
            else -> "night"
        }
    }

    // ── math helpers ─────────────────────────────────────────────
    private fun julian(date: LocalDate): Double {
        var y = date.year; var m = date.monthValue; val d = date.dayOfMonth
        if (m <= 2) { y -= 1; m += 12 }
        val a = floor(y / 100.0).toInt(); val b = 2 - a + floor(a / 4.0).toInt()
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + d + b - 1524.5
    }

    private fun deg2rad(v: Double) = v * PI / 180
    private fun rad2deg(v: Double) = v * 180 / PI
    private fun norm24(h: Double) = ((h % 24) + 24) % 24
    private fun norm360(v: Double) = ((v % 360) + 360) % 360
}
