package app.dayflow.android.data

import kotlinx.serialization.Serializable

enum class SoundSource { library, device, files, downloaded }

@Serializable
data class Alarm(
    val id: String,
    val time: String,                 // "HH:mm" (24h storage, 12h display everywhere)
    val date: String? = null,         // "yyyy-MM-dd" for one-time alarms
    val days: List<Int> = emptyList(),// 0=Sun..6=Sat
    val label: String = "",
    val enabled: Boolean = true,
    val soundSource: SoundSource = SoundSource.device,
    val soundTitle: String = "منبه الجهاز الافتراضي",
    /** Persisted Android tone reference (RingtoneManager URI or SAF content:// with persisted permission). */
    val soundUri: String? = null,
    val vibrate: Boolean = true,
    val snooze: Int = 10,
    val gentle: Boolean = true,
)

@Serializable
data class Task(
    val id: String, val title: String, val date: String, val dueTime: String? = null,
    val done: Boolean = false, val urgent: Boolean = false, val important: Boolean = false,
    val status: String = "todo", val createdAt: Long = 0,
)

@Serializable data class Note(val id: String, val text: String, val pinned: Boolean = false, val at: Long = 0)

@Serializable
data class Habit(
    val id: String, val en: String, val ar: String? = null, val log: List<String> = emptyList(),
    val type: String = "build", val days: List<Int> = emptyList(), val startDate: String? = null,
    val target: Int? = null, val unit: String? = null, val details: String? = null,
    val color: String? = null, val reminder: String? = null, val createdAt: Long = 0,
)

@Serializable
data class Placed(val id: String, val designId: String, val w: Int, val h: Int, val style: String, val tapOpens: Boolean = false)

@Serializable data class Journal(val id: String, val date: String, val mood: Int, val text: String)
@Serializable data class Countdown(val id: String, val title: String, val date: String)

@Serializable
data class UserDay(val id: String, val date: String /* MM-DD */, val en: String, val ar: String, val kind: String = "custom", val family: String = "birthday")

@Serializable
data class RobotPrefs(
    val enabled: Boolean = true, val hidden: Boolean = false, val notify: Boolean = true,
    val bubbles: Boolean = true, val emotion: String = "idle", val sound: Boolean = false,
    val size: Float = 1f, val opacity: Float = 1f, val outfit: String = "auto",
)

@Serializable
data class NotifPrefs(
    val preview: Boolean = true, val style: String = "detailed", val sound: Boolean = true,
    val vibrate: Boolean = true, val quiet: Boolean = false, val dailyReview: String = "21:30",
    val weeklyReview: Boolean = false,
)

@Serializable
data class AlarmLook(val layout: String = "ornate", val showSeconds: Boolean = false, val gradient: Boolean = true, val weatherLine: Boolean = false)

@Serializable
data class WidgetCfg(val designId: String, val style: String, val tapOpens: Boolean = false)

@Serializable
data class DlItem(
    val id: String, val url: String, val name: String, val kind: String, val host: String,
    val site: String, val secure: Boolean, val thumb: String? = null, val quality: String? = null,
    val format: String? = null, val variantUrl: String? = null,
    val size: Long = 0, val got: Long = 0, val state: String = "queued",
    val engine: String? = null, val notices: List<String> = emptyList(), val error: String? = null,
    val addedAt: Long = 0, val doneAt: Long? = null, val speed: Long = 0, val eta: Long = 0,
    val resumable: Boolean = false, val parts: Int = 0, val priority: Int = 1,
    val savedAs: String? = null, val mime: String? = null,
)

@Serializable
data class ApiKeyEntry(val id: String, val provider: String, val label: String, val key: String, val models: List<String> = emptyList())

@Serializable
data class ChatMsg(val role: String, val text: String, val at: Long = 0, val reasoning: String? = null)

@Serializable
data class Convo(val id: String, val title: String, val provider: String, val model: String, val msgs: List<ChatMsg>, val at: Long)

/** Mirrors the web `dayflow-v2` persisted shape (same names/semantics). */
@Serializable
data class State(
    val lang: String = "ar",
    val themeId: String = "paper-white",
    val favThemes: List<String> = emptyList(),
    val intensity: String = "subtle",                 // off | subtle | rich | festival
    val decorSurfaces: Map<String, Boolean> = mapOf("app" to true, "notifications" to true, "widgets" to true, "icon" to false, "companion" to true),
    val decorLayer: String = "behind",
    val powerMode: Boolean = false,
    val reduceMotion: Boolean = false,
    val examSeason: Boolean = false,
    val hour12: Boolean = true,                        // native build is 12-hour by design
    val companion: RobotPrefs = RobotPrefs(),
    val alarms: List<Alarm> = emptyList(),
    val tasks: List<Task> = emptyList(),
    val notes: List<Note> = emptyList(),
    val habits: List<Habit> = emptyList(),
    val water: Map<String, Int> = emptyMap(),
    val waterGoal: Int = 2500,
    val userDays: List<UserDay> = emptyList(),
    val placed: List<Placed> = emptyList(),
    val journal: List<Journal> = emptyList(),
    val countdowns: List<Countdown> = emptyList(),
    val tasbih: Int = 0,
    val khatma: Int = 0,
    val apiKeys: List<ApiKeyEntry> = emptyList(),
    val activeKeyId: String? = null,
    val activeModel: String = "",
    val convos: List<Convo> = emptyList(),
    val notif: NotifPrefs = NotifPrefs(),
    val alarmLook: AlarmLook = AlarmLook(),
    val widgetFont: String = "sans",
    val cityIndex: Int = 0,
    val customLat: Double? = null,
    val customLng: Double? = null,
    val autoTimeTheme: Boolean = true,
    val widgetConfigs: Map<String, WidgetCfg> = emptyMap(),   // appWidgetId -> chosen design (the picked widget)
    val downloads: List<DlItem> = emptyList(),
)
