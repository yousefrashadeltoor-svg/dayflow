package app.dayflow.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.calendar.Calendars
import app.dayflow.android.data.Store
import app.dayflow.android.patterns.Patterns
import app.dayflow.android.prayer.PrayerEngine
import app.dayflow.android.time.TimeFmt
import app.dayflow.android.ui.DecorDivider
import app.dayflow.android.ui.DFCard
import app.dayflow.android.ui.EmptyState
import app.dayflow.android.ui.HeaderCrown
import app.dayflow.android.ui.MotifView
import app.dayflow.android.ui.Ring
import app.dayflow.android.ui.bodyStyle
import app.dayflow.android.ui.pack
import app.dayflow.android.alarm.NextAlarm
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.ZonedDateTime
import java.util.Date

/** Today — hero with the day's family, three calendars, prayer strip, alarms, tasks, water, habits, upcoming occasions. */
@Composable
fun TodayScreen(go: (String, String?) -> Unit) {
    val s by Store.state.collectAsState()
    val lang = s.lang
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(30_000) } }
    val today = LocalDate.now()
    val decor = remember(today, s.userDays, s.examSeason) { Calendars.resolveDecor(today, s.userDays, 3, s.examSeason) }
    val fam = decor.primary
    val st = Patterns.FAMILY[fam]!!
    val rich = s.intensity != "off"

    val key = Store.dayKey(now)
    val tasks = s.tasks.filter { it.date == key }
    val done = tasks.count { it.done }
    val next = NextAlarm.soonest(s.alarms, now)
    val water = s.water[key] ?: 0
    val cal = java.util.Calendar.getInstance().apply { time = now }
    val hr = cal[java.util.Calendar.HOUR_OF_DAY]
    val greet = if (lang == "ar") (if (hr < 5) "طابت ليلتك" else if (hr < 12) "صباح الخير" else if (hr < 17) "طاب يومك" else "مساء الخير")
    else (if (hr < 5) "Good night" else if (hr < 12) "Good morning" else if (hr < 17) "Good afternoon" else "Good evening")

    val hj = Calendars.hijri(today)
    val cp = Calendars.coptic(today)
    val city = PrayerEngine.CITIES[s.cityIndex.coerceIn(PrayerEngine.CITIES.indices)]
    val zone = java.time.ZoneId.systemDefault()
    val prTimes = remember(today, s.cityIndex, s.customLat, s.customLng) {
        PrayerEngine.timesFor(today, s.customLat ?: city.lat, s.customLng ?: city.lng, zone)
    }
    val nextPrayer = remember(now) { PrayerEngine.next(ZonedDateTime.now(zone), s.customLat ?: city.lat, s.customLng ?: city.lng, zone) }
    val up = remember(today) { Calendars.upcoming(today.plusDays(1), 6) }
    var quick by remember { mutableStateOf("") }
    val occ = decor.occasions.firstOrNull()
    val p = pack

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = 6.dp, bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

        // ── Hero ───────────────────────────────────────────────
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(st.c2, st.c1)))) {
            if (rich) {
                Column { HeaderCrown(fam, 56.dp) }
            }
            Column(Modifier.padding(start = 20.dp, end = 20.dp, top = if (rich) 42.dp else 20.dp, bottom = 20.dp)) {
                Text(greet, color = Color.White.copy(alpha = 0.85f), style = bodyStyle(14))
                Text(TimeFmt.dateLine(now, lang), color = Color.White, style = bodyStyle(24, FontWeight.Bold), modifier = Modifier.padding(top = 2.dp))
                Text(
                    "${TimeFmt.num(hj.d, lang)} ${(if (lang == "ar") Calendars.HIJRI_MONTHS_AR else Calendars.HIJRI_MONTHS_EN)[hj.m - 1]} ${TimeFmt.num(hj.y, lang)} · ${TimeFmt.num(cp.d, lang)} ${(if (lang == "ar") Calendars.COPTIC_MONTHS_AR else Calendars.COPTIC_MONTHS_EN)[cp.m - 1]} ${TimeFmt.num(cp.y, lang)}",
                    color = Color.White.copy(alpha = 0.85f), style = bodyStyle(13), modifier = Modifier.padding(top = 4.dp),
                )
                Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    decor.layers.take(3).forEach { l ->
                        Box(Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.18f)).padding(horizontal = 10.dp, vertical = 4.dp)) {
                            Text(if (lang == "ar") l.ar else l.en, color = Color.White, style = bodyStyle(11, FontWeight.SemiBold))
                        }
                    }
                }
            }
            Box(Modifier.align(Alignment.BottomEnd).alpha(0.95f)) { MotifView(fam, 86.dp, mono = Color.White.copy(alpha = 0.87f)) }
        }

        // ── occasion banner ────────────────────────────────────
        if (occ != null && occ.priority >= 80) {
            DFCard(onClick = { go("calendar", null) }) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    MotifView(occ.family, 42.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(if (lang == "ar") "مناسبة اليوم" else "Today's occasion", style = bodyStyle(12, color = p.muted))
                        Text(if (lang == "ar") occ.ar else occ.en, style = bodyStyle(15, FontWeight.Bold))
                    }
                }
            }
        }

        // ── prayer strip ───────────────────────────────────────
        DFCard(onClick = { go("me", "prayer") }) {
            Column(Modifier.padding(12.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("🕌 ${if (lang == "ar") "الصلاة" else "Prayer"} · ${if (lang == "ar") city.ar else city.en}", style = bodyStyle(12, FontWeight.Bold), modifier = Modifier.weight(1f))
                    Text(
                        "${if (lang == "ar") "القادمة" else "Next"}: ${if (lang == "ar") PrayerEngine.NAMES_AR[nextPrayer?.p] else PrayerEngine.NAMES_EN[nextPrayer?.p]} ${nextPrayer?.let { TimeFmt.fmt(it.at.toLocalTime().toString().substring(0, 5), lang) } ?: ""}",
                        style = bodyStyle(11, FontWeight.Bold, p.accent),
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth()) {
                    PrayerEngine.P.entries.forEach { pk ->
                        val t = prTimes[pk]?.toString()?.substring(0, 5) ?: "—"
                        val isNext = nextPrayer?.p == pk
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(8.dp))
                                .background(if (isNext) p.accent else p.soft).padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text((if (lang == "ar") PrayerEngine.NAMES_AR[pk] else PrayerEngine.NAMES_EN[pk]) ?: "", style = bodyStyle(9, color = if (isNext) p.onAccent else p.muted), maxLines = 1)
                            Text(TimeFmt.fmt(t, lang), style = bodyStyle(10, FontWeight.Bold, if (isNext) p.onAccent else p.text), maxLines = 1)
                        }
                        Spacer(Modifier.width(2.dp))
                    }
                }
            }
        }

        // ── next alarm + day ring ──────────────────────────────
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            DFCard(Modifier.weight(1f), onClick = { go("alarms", null) }) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Alarm, null, tint = p.muted, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (lang == "ar") "المنبه التالي" else "Next alarm", style = bodyStyle(12, color = p.muted))
                    }
                    if (next != null) {
                        Text(TimeFmt.fmt(next.first.time, lang), style = bodyStyle(28, FontWeight.Bold), modifier = Modifier.padding(top = 8.dp))
                        Text(TimeFmt.until(next.second.time - now.time, lang), style = bodyStyle(12, color = p.muted))
                    } else Text(if (lang == "ar") "لا منبهات مفعّلة" else "No alarms on", style = bodyStyle(13, color = p.muted), modifier = Modifier.padding(top = 8.dp))
                }
            }
            DFCard(Modifier.weight(1f)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Ring(value = (hr * 60 + cal[java.util.Calendar.MINUTE]) / 1440f) {
                        Text("${TimeFmt.num(((hr * 60 + cal[java.util.Calendar.MINUTE]) * 100 / 1440), lang)}%", style = bodyStyle(11, FontWeight.Bold))
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(if (lang == "ar") "اليوم" else "Day", style = bodyStyle(12, color = p.muted))
                        Text("${TimeFmt.num(done, lang)}/${TimeFmt.num(tasks.size, lang)}", style = bodyStyle(15, FontWeight.Bold))
                        Text(if (lang == "ar") "مهام" else "tasks", style = bodyStyle(11, color = p.muted))
                    }
                }
            }
        }

        // ── downloader entry ───────────────────────────────────
        DFCard(onClick = { go("downloads", null) }) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(p.accent), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Download, null, tint = p.onAccent, modifier = Modifier.size(18.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (lang == "ar") "التحميل" else "Downloader", style = bodyStyle(14, FontWeight.Bold))
                    Text(if (lang == "ar") "الصق أو شارك أي رابط — فيديو، صوت، صور، ملفات" else "Paste or share any link", style = bodyStyle(11, color = p.muted))
                }
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = p.muted, modifier = if (LocalLayoutDirection.current == LayoutDirection.Rtl) Modifier else Modifier)
            }
        }

        // ── tasks ──────────────────────────────────────────────
        DFCard {
            Column(Modifier.padding(14.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (lang == "ar") "مهام اليوم" else "Today's tasks", style = bodyStyle(15, FontWeight.Bold), modifier = Modifier.weight(1f))
                    Text(if (lang == "ar") "الكل" else "All", style = bodyStyle(12, FontWeight.SemiBold, p.accent), modifier = Modifier.clickable { go("tools", "tasks") })
                }
                Row(Modifier.padding(vertical = 8.dp)) {
                    OutlinedTextField(value = quick, onValueChange = { quick = it }, modifier = Modifier.weight(1f), placeholder = { Text(if (lang == "ar") "ضيف مهمة للنهاردة…" else "Add a task for today…") }, singleLine = true)
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(p.accent).clickable { if (quick.isNotBlank()) { Store.addTask(quick.trim()); quick = "" } }, contentAlignment = Alignment.Center) {
                        Text("+", color = p.onAccent, fontSize = 22.sp)
                    }
                }
                if (tasks.isEmpty()) EmptyState(fam, if (lang == "ar") "يوم فاضي وهادي" else "A clear day", if (lang == "ar") "لسه مفيش حاجة متخططة." else "Nothing planned yet.")
                tasks.forEach { t ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp).clickable { Store.toggleTask(t.id) }, verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(24.dp).clip(RoundedCornerShape(7.dp))
                                .background(if (t.done) p.accent else Color.Transparent)
                                .then(Modifier.clip(RoundedCornerShape(7.dp))),
                        ) {
                            if (t.done) Text("✓", color = p.onAccent, modifier = Modifier.align(Alignment.Center))
                            else Box(Modifier.fillMaxSize().padding(1.dp).clip(RoundedCornerShape(7.dp)).background(Color.Transparent), contentAlignment = Alignment.Center) {
                                Box(Modifier.fillMaxSize().clip(RoundedCornerShape(6.dp)).background(Color.Transparent).alpha(1f))
                            }
                        }
                        if (!t.done) Box(Modifier.size(24.dp).clip(RoundedCornerShape(7.dp)).padding(2.dp)) {}
                        Spacer(Modifier.width(10.dp))
                        Text(t.title, style = bodyStyle(14, color = if (t.done) p.muted else p.text), modifier = Modifier.weight(1f))
                        if (t.urgent && !t.done) Box(Modifier.size(8.dp).clip(CircleShape).background(Color(0xffe5484d)))
                    }
                }
                if (rich) DecorDivider(fam, Modifier.padding(top = 8.dp).alpha(0.7f))
            }
        }

        // ── water + habits ─────────────────────────────────────
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            DFCard(Modifier.weight(1f)) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.WaterDrop, null, tint = p.muted, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (lang == "ar") "الماء" else "Water", style = bodyStyle(12, color = p.muted))
                    }
                    Text("${TimeFmt.num(String.format("%.2f", water / 1000f), lang)} / ${TimeFmt.num(s.waterGoal / 1000, lang)} لتر", style = bodyStyle(20, FontWeight.Bold), modifier = Modifier.padding(top = 6.dp))
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(p.line)) {
                        Box(Modifier.fillMaxWidth((water / s.waterGoal.toFloat()).coerceIn(0f, 1f)).height(8.dp).clip(CircleShape).background(Color(0xff3aa0ff)))
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(p.soft).clickable { Store.addWater(250) }.padding(vertical = 8.dp), horizontalArrangement = Arrangement.Center) {
                        Text("+٢٥٠ مل", style = bodyStyle(12, FontWeight.SemiBold))
                    }
                }
            }
            DFCard(Modifier.weight(1f)) {
                Column(Modifier.padding(14.dp)) {
                    Text(if (lang == "ar") "العادات" else "Habits", style = bodyStyle(12, color = p.muted))
                    Spacer(Modifier.height(8.dp))
                    s.habits.take(4).forEach { h ->
                        val on = h.log.contains(key)
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { Store.toggleHabit(h.id) }, verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(16.dp).clip(CircleShape).background(if (on) p.accent else Color.Transparent).then(Modifier.clip(CircleShape)))
                            Spacer(Modifier.width(8.dp))
                            Text(h.en, style = bodyStyle(12, color = if (on) p.muted else p.text), maxLines = 1)
                        }
                    }
                }
            }
        }

        // ── upcoming occasions ─────────────────────────────────
        Text(if (lang == "ar") "قريبًا" else "Coming up", style = bodyStyle(15, FontWeight.Bold), modifier = Modifier.padding(horizontal = 4.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(up) { (date, o) ->
                val f = Patterns.FAMILY[o.family]!!
                val d = java.time.temporal.ChronoUnit.DAYS.between(today, date).toInt()
                Box(Modifier.width(160.dp).clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(listOf(f.c2, f.c1)))) {
                    Column(Modifier.padding(12.dp, 12.dp, 12.dp, 12.dp)) {
                        Text(if (lang == "ar") "بعد ${TimeFmt.num(d, lang)} يومًا" else "in $d days", color = Color.White.copy(alpha = 0.85f), style = bodyStyle(11))
                        Text(if (lang == "ar") o.ar else o.en, color = Color.White, style = bodyStyle(13, FontWeight.Bold), modifier = Modifier.padding(vertical = 6.dp).height(40.dp))
                        Text(date.toString(), color = Color.White.copy(alpha = 0.85f), style = bodyStyle(11))
                    }
                    Box(Modifier.align(Alignment.BottomEnd).alpha(0.75f)) { MotifView(o.family, 54.dp, mono = Color.White.copy(alpha = 0.75f)) }
                }
            }
        }
    }
}
