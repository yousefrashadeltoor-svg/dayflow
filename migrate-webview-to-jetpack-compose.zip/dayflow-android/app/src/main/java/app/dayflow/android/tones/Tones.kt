package app.dayflow.android.tones

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.provider.MediaStore

/**
 * Real device-tone access.
 *  - RingtoneManager lists every real tone the phone ships (incl. Samsung One UI tones).
 *  - The picker stores a stable URI reference (never a copy) — the URI survives reboots.
 *  - SAF import uses ACTION_OPEN_DOCUMENT with takePersistableUriPermission.
 *  - MediaStore query surfaces audio the user already has on the device.
 */
object Tones {

    data class Tone(val title: String, val uri: String, val type: String)

    fun deviceTones(ctx: Context): List<Tone> {
        val out = linkedMapOf<String, Tone>()
        for (type in listOf(RingtoneManager.TYPE_ALARM, RingtoneManager.TYPE_RINGTONE, RingtoneManager.TYPE_NOTIFICATION)) {
            val rm = RingtoneManager(ctx).apply { setType(type) }
            val c = rm.cursor
            val typeName = when (type) {
                RingtoneManager.TYPE_ALARM -> "alarm"
                RingtoneManager.TYPE_RINGTONE -> "ringtone"
                else -> "notification"
            }
            var i = 0
            while (c.moveToPosition(i)) {
                val title = c.getString(RingtoneManager.TITLE_COLUMN_INDEX) ?: continue
                val uri = rm.getRingtoneUri(i).toString()
                out.putIfAbsent(uri, Tone(title, uri, typeName))
                i++
            }
        }
        // Defaults always visible first (same names as the web picker).
        val defaults = mutableListOf<Tone>()
        RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)?.let { defaults += Tone("منبه الجهاز الافتراضي", it.toString(), "alarm") }
        RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)?.let { defaults += Tone("نغمة الرنين الافتراضية", it.toString(), "ringtone") }
        RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)?.let { defaults += Tone("صوت الإشعار الافتراضي", it.toString(), "notification") }
        return defaults + out.values.filter { o -> defaults.none { it.uri == o.uri } }
    }

    fun pickFileIntent(): Intent =
        Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }

    /** Persist a chosen SAF URI so alarms keep working after reboot. */
    fun persistUri(activity: Activity, uri: Uri): String? {
        return runCatching {
            activity.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            uri.toString()
        }.getOrNull()
    }

    fun deviceAudio(ctx: Context, limit: Int = 60): List<Tone> {
        val out = mutableListOf<Tone>()
        val proj = arrayOf(MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media._ID)
        runCatching {
            ctx.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
                "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
                "${MediaStore.Audio.Media.DATE_ADDED} DESC",
            )?.use { c ->
                val nameIdx = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val idIdx = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                while (c.moveToNext() && out.size < limit) {
                    val id = c.getLong(idIdx)
                    out += Tone(c.getString(nameIdx) ?: "audio", Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString()).toString(), "file")
                }
            }
        }
        return out
    }

    private var preview: MediaPlayer? = null
    fun preview(ctx: Context, uri: String) {
        stopPreview()
        preview = MediaPlayer().apply {
            runCatching {
                setDataSource(ctx, Uri.parse(uri))
                isLooping = false
                prepare(); start()
            }
        }
    }
    fun stopPreview() { preview?.runCatching { stop(); release() }; preview = null }
}
