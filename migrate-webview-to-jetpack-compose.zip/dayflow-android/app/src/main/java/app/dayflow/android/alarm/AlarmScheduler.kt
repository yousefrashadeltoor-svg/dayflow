package app.dayflow.android.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import app.dayflow.android.MainActivity
import app.dayflow.android.data.Alarm
import app.dayflow.android.data.Store
import java.util.Date

/**
 * Native exact-alarm scheduling.
 *  - Uses AlarmManager.setAlarmClock (most reliable: rings with the app closed/killed,
 *    shows next-alarm info in the system, exempt from Doze).
 *  - Handles Android 12+ SCHEDULE_EXACT_ALARM access with an explicit settings flow.
 *  - Cancels and re-arms with the same PendingIntent identity per alarm id.
 */
object AlarmScheduler {

    const val ACTION_FIRE = "app.dayflow.android.ALARM_FIRE"
    const val ACTION_REMINDER = "app.dayflow.android.REMINDER_FIRE"

    fun canScheduleExact(ctx: Context): Boolean {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
    }

    /** Opens the system screen where the user grants exact-alarm access. */
    fun exactAccessIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    private fun pi(ctx: Context, alarmId: String): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).setAction(ACTION_FIRE).setData(Uri.parse("dayflow://alarm/$alarmId"))
        return PendingIntent.getBroadcast(ctx, alarmId.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun schedule(ctx: Context, alarm: Alarm) {
        cancel(ctx, alarm.id)
        val at = NextAlarm.nextTime(alarm) ?: return
        if (!alarm.enabled) return
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java).putExtra("tab", "alarms"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val info = AlarmManager.AlarmClockInfo(at.time, show)
        try {
            if (canScheduleExact(ctx)) am.setAlarmClock(info, pi(ctx, alarm.id))
            else am.setWindow(AlarmManager.RTC_WAKEUP, at.time, 60_000, pi(ctx, alarm.id)) // graceful fallback
        } catch (se: SecurityException) {
            am.setWindow(AlarmManager.RTC_WAKEUP, at.time, 120_000, pi(ctx, alarm.id))
        }
    }

    fun cancel(ctx: Context, alarmId: String) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pi(ctx, alarmId))
    }

    /** Increments a ringing alarm by its snooze minutes once. */
    fun snooze(ctx: Context, alarmId: String, minutes: Int) {
        cancel(ctx, alarmId)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val at = System.currentTimeMillis() + minutes * 60_000L
        val show = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi(ctx, alarmId))
        } catch (se: SecurityException) {
            am.setWindow(AlarmManager.RTC_WAKEUP, at, 30_000, pi(ctx, alarmId))
        }
    }

    /** Re-arm every enabled alarm (boot, time change, process restart). */
    fun restoreAll(ctx: Context) {
        for (a in Store.current().alarms) {
            if (a.enabled) schedule(ctx, a) else cancel(ctx, a.id)
        }
        Reminders.scheduleDailyReview(ctx)
    }
}
