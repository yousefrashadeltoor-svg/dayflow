package app.dayflow.android.decor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.withSave
import app.dayflow.android.calendar.Calendars.Family
import app.dayflow.android.patterns.Patterns
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Realistic seasonal decoration engine (native Canvas port + expansion).
 *
 * What was upgraded vs the web build (kept identical placement & motion families):
 *  - autumn: 3D tumbling leaves (flip + rotate + sinus sway) — already good, kept.
 *  - winter: layered snowfall with depth (size/speed/alpha by parallax layer).
 *  - NEW realistic sets for seasons that previously had flat emoji-like sprites:
 *      spring → tumbling sakura petals with two-tone blush,
 *      summer → translucent rising bubbles with specular highlight,
 *      ramadan → glowing lanterns + crescents (radial glow),
 *      islamic/friday → shimmer star-field,
 *      national → ribbon doves + tricolor confetti,
 *      love → soft beating hearts,
 *      birthday/newyear/eid → balloons with knots & wavy strings + rotating confetti,
 *      study → drifting pages + ink stars,
 *      nile → lotus petals over gentle ripples,
 *      coptic → warm candle-glow motes,
 *  - plus two brand-new ambience modes available to all "wet / cold" days:
 *      wind-slanted rain with ground streak-splashes and slow fireflies for warm nights.
 *
 * Performance: one Canvas per layer, a single frame-clock state read inside `onDraw`
 * (Compose invalidates *drawing only* — no layout/recomposition per frame), fixed
 * deterministic seeds, allocation-free paths reused across frames.
 */
object DecorCanvas {

    enum class Motion { FALL, FLOAT, DRIFT, RAIN, FIREFLY }

    data class Seed(val x: Float, val delay: Float, val dur: Float, val size: Float, val dx: Float, val o: Float, val variant: Int)

    val MOTION = mapOf(
        Family.autumn to Motion.FALL, Family.winter to Motion.FALL, Family.newyear to Motion.FALL,
        Family.spring to Motion.DRIFT, Family.national to Motion.DRIFT, Family.nile to Motion.DRIFT,
        Family.summer to Motion.FLOAT, Family.ramadan to Motion.FLOAT, Family.islamic to Motion.FLOAT,
        Family.friday to Motion.FLOAT, Family.eid to Motion.FLOAT, Family.love to Motion.FLOAT,
        Family.study to Motion.FLOAT, Family.birthday to Motion.FLOAT, Family.coptic to Motion.FLOAT,
    )

    private fun seedsFor(f: Family, count: Int): List<Seed> {
        val r = Patterns.mulberry32(f.ordinal * 97 + count)
        return List(count) { Seed(r() * 100f, -r() * 22f, 13f + r() * 15f, 18f + r() * 22f, (r() - 0.5f) * 140f, 0.55f + r() * 0.4f, (r() * 4).toInt()) }
    }

    fun count(intensity: String, lowEnd: Boolean): Int =
        minOf(if (lowEnd) 14 else 48, when (intensity) { "off" -> 0; "subtle" -> 9; "rich" -> 20; "festival" -> 34; else -> 0 })

    /** Piecewise keyframe sampled exactly like the CSS fall/float/drift tracks. */
    private class Track(val keys: List<Triple<Float, Offset, Float>>) {
        fun angle(t: Float): Float {
            var prev = keys.first(); for (k in keys) { if (t <= k.first) { val span = (k.first - prev.first).coerceAtLeast(0.0001f); val f = (t - prev.first) / span; return prev.third + (k.third - prev.third) * f }; prev = k }
            return keys.last().third
        }
        fun offset(t: Float, dx: Float, h: Float, driftN: Float): Offset {
            var prev = keys.first(); for (k in keys) { if (t <= k.first) { val span = (k.first - prev.first).coerceAtLeast(0.0001f); val f = (t - prev.first) / span; return Offset(prev.second.x + (k.second.x - prev.second.x) * f, prev.second.y + (k.second.y - prev.second.y) * f) }; prev = k }
            return keys.last().second
        }
        companion object {
            fun fall(dx: Float) = Track(listOf(
                Triple(0f, Offset(0f, -10f), 0f), Triple(0.25f, Offset(dx * 0.4f, 0.25f), 90f),
                Triple(0.5f, Offset(dx * -0.3f, 0.52f), 200f), Triple(0.75f, Offset(dx * 0.6f, 0.78f), 290f),
                Triple(1f, Offset(dx, 1.08f), 380f),
            ))
            fun floatUp(dx: Float) = Track(listOf(
                Triple(0f, Offset(0f, 0f), 0f), Triple(0.5f, Offset(dx * 0.5f, -55f), 0f), Triple(1f, Offset(dx, -112f), 0f),
            ))
        }
    }

    @Composable
    fun Layer(family: Family, intensity: String, modifier: Modifier = Modifier, lowEnd: Boolean = false) {
        val n = count(intensity, lowEnd)
        if (n == 0) return
        val seeds = remember(family, n) { seedsFor(family, n) }
        val clock = remember { mutableLongStateOf(0L) }
        LaunchedEffect(family, n) {
            val t0 = System.nanoTime()
            while (true) {
                androidx.compose.runtime.withFrameNanos { clock.longValue = (System.nanoTime() - t0) / 1_000_000 }
            }
        }
        Canvas(modifier.fillMaxSize()) {
            val ms = clock.longValue // draw-phase read → redraw without recomposition
            for (p in seeds) drawParticle(family, p, ms)
        }
    }

    private fun DrawScope.drawParticle(f: Family, p: Seed, ms: Long) {
        val t = ((ms / 1000f + p.delay) % p.dur + p.dur) % p.dur / p.dur // 0..1 looping
        val alpha = when {
            t < 0.08f -> t / 0.08f
            t > 0.9f -> (1 - t) / 0.1f
            else -> 1f
        } * p.o
        val st = Patterns.FAMILY[f]!!
        val x0 = size.width * (if (f == Family.autumn) 0.55f + p.x * 0.0045f else p.x / 100f)
        val s = p.size

        withSave({
            when (MOTION[f]) {
                Motion.FALL -> {
                    val tr = Track.fall(p.dx)
                    val pos = tr.offset(t, p.dx, size.height, 0f)
                    translate(x0 + pos.x, pos.y * size.height) {}
                    rotate(tr.angle(t), Offset(0f, 0f))
                    // tumble illusion: scaleX follows the CSS rotateY flips (0→720° over the track)
                    val flip = abs(cos(t * 4 * PI.toFloat()))
                    scale(scaleX = 0.35f + 0.65f * flip, scaleY = 1f, pivot = Offset.Zero)
                }
                Motion.FLOAT -> {
                    val tr = Track.floatUp(p.dx)
                    val pos = tr.offset(t, p.dx, size.height, 0f)
                    translate(x0 + pos.x, size.height + 60 + pos.y * size.height / 100f) {}
                }
                Motion.DRIFT -> {
                    val x = x0 - size.width * 0.1f + t * (size.width * 0.1f + p.dx * 3f)
                    val y = size.height * 0.5f * t + sin(t * PI.toFloat() * 2) * 26f
                    translate(x, y + s) {}
                    rotate(sin(t * 6f) * 18f - 10f, Offset.Zero)
                }
                Motion.RAIN -> translate(x0 + t * p.dx * 0.25f, size.height * -0.1f + size.height * 1.2f * t) {}
                Motion.FIREFLY -> {
                    translate(x0 + sin(t * 4 * PI.toFloat()) * 30f, size.height * (0.25f + 0.6f * ((p.delay % 1 + 1) % 1)) + cos(t * 2 * PI.toFloat()) * 30f) {}
                }
            }
            drawShape(f, s, alpha, st, p.variant, t)
        }) {}
    }

    private fun DrawScope.drawShape(f: Family, s: Float, alpha: Float, st: Patterns.FamilyStyle, variant: Int, t: Float) {
        when (f) {
            Family.autumn -> {
                val leaf = Patterns.leaf(0f, 0f, s * 0.5f, 0f)
                val c = when (variant % 3) { 0 -> st.c1; 1 -> st.c2; else -> Color(0xffa8463a) }
                shadowed(leaf, s, alpha) { drawPath(leaf, c, alpha = alpha) }
            }
            Family.winter -> {
                if (variant % 3 == 2) drawCircle(Color(0xfff0f7ff), radius = s * 0.14f, alpha = alpha)
                else drawPath(Patterns.snowflake(0f, 0f, s * 0.45f), Color(0xffe2f1fd), alpha = alpha * 0.95f, style = Stroke(s * 0.06f, cap = androidx.compose.ui.graphics.StrokeCap.Round))
            }
            Family.spring -> {
                val petal = Patterns.petal(0f, 0f, s * 0.5f, 0f)
                drawPath(petal, Brush.verticalGradient(listOf(Color(0xffffd7e2), st.c1)), alpha = alpha)
                drawCircle(Color(0xffffb7c9), radius = s * 0.07f, center = Offset(0f, s * 0.55f), alpha = alpha)
            }
            Family.summer -> {
                // translucent bubble with specular highlight
                drawCircle(st.c3, radius = s * 0.45f, alpha = alpha * 0.35f)
                drawCircle(st.c1, radius = s * 0.45f, alpha = alpha * 0.5f, style = Stroke(s * 0.03f))
                drawCircle(Color.White, radius = s * 0.1f, center = Offset(-s * 0.14f, -s * 0.16f), alpha = alpha * 0.8f)
            }
            Family.ramadan -> {
                when (variant % 3) {
                    0 -> {
                        val glow = Brush.radialGradient(listOf(Color(0xffffe9a8), Color(0x00ffd36b)), center = Offset.Zero, radius = s * 0.9f)
                        drawCircle(glow, radius = s * 0.9f, alpha = alpha)
                        Patterns.lantern(0f, -s * 0.55f, s).forEachIndexed { i, path ->
                            drawPath(path, if (i == 1) Color(0xffe8b93e) else Color(0xffb8860b), alpha = alpha)
                        }
                        drawCircle(Color(0xffffd36b), radius = s * 0.06f, center = Offset(0f, s * 0.12f), alpha = alpha)
                    }
                    1 -> drawPath(Patterns.crescent(0f, 0f, s * 0.45f), st.c1, alpha = alpha)
                    else -> drawPath(Patterns.sparkle(0f, 0f, s * 0.3f), st.c3, alpha = alpha)
                }
            }
            Family.islamic, Family.friday, Family.study -> {
                val tw = 0.6f + 0.4f * sin(t * 6.28f)
                drawPath(Patterns.star(0f, 0f, 8, s * 0.4f, s * 0.19f), if (f == Family.study) st.c1 else st.c2, alpha = alpha * tw)
                if (variant % 2 == 0) drawPath(Patterns.sparkle(0f, 0f, s * 0.18f), st.c3, alpha = alpha)
            }
            Family.coptic -> {
                val glow = Brush.radialGradient(listOf(Color(0xffffdca0), Color(0x00ffb46b)), radius = s * 0.8f)
                drawCircle(glow, radius = s * 0.8f, alpha = alpha)
                drawCircle(Color(0xffffe3b3), radius = s * 0.12f, alpha = alpha)
            }
            Family.love -> {
                val pulse = 1f + 0.1f * sin(t * 6.28f)
                drawPath(Patterns.heart(0f, 0f, s * 0.5f * pulse), if (variant % 2 == 0) st.c1 else st.c2, alpha = alpha)
            }
            Family.nile -> {
                if (variant % 2 == 0) drawPath(Patterns.lotus(0f, 0f, s * 0.45f, 5), st.c2, alpha = alpha)
                else {
                    drawCircle(st.c3, radius = s * 0.4f, alpha = alpha * 0.4f, style = Stroke(s * 0.04f))
                    drawCircle(st.c1, radius = s * 0.22f, alpha = alpha * 0.5f, style = Stroke(s * 0.04f))
                }
            }
            Family.national -> {
                if (variant % 2 == 0) { // dove
                    val flap = sin(t * 12f) * 0.35f
                    val wing = s * 0.42f
                    val body = Path().apply { moveTo(-s * 0.3f, 0f); quadraticTo(0f, -s * 0.16f, s * 0.3f, -s * 0.05f); quadraticTo(s * 0.12f, s * 0.12f, -s * 0.3f, s * 0.05f); close() }
                    drawPath(body, Color.White, alpha = alpha)
                    rotate(-14f) { drawPath(Path().apply { moveTo(0f, -s * 0.05f); quadraticTo(s * 0.1f, -wing * (1 + flap), s * 0.05f, -wing * (1 + flap) * 0.55f); quadraticTo(-s * 0.08f, -s * 0.2f, 0f, -s * 0.05f); close() }, Color(0xfff1f1f1), alpha = alpha) }
                } else { // tricolor confetti
                    val col = listOf(Color(0xffce1126), Color.White, Color(0xff111111))[variant % 3]
                    rotate(t * 720f, Offset.Zero)
                    drawRect(col, topLeft = Offset(-s * 0.14f, -s * 0.05f), size = androidx.compose.ui.geometry.Size(s * 0.28f, s * 0.1f), alpha = alpha)
                }
            }
            Family.eid, Family.birthday, Family.newyear -> when (variant % 3) {
                0 -> { // balloon with knot + string
                    val c = if (variant > 1) st.c2 else st.c1
                    shadowed(null, s, alpha) {
                        drawOval(c, topLeft = Offset(-s * 0.32f, -s * 0.55f), size = androidx.compose.ui.geometry.Size(s * 0.64f, s * 0.72f), alpha = alpha)
                        drawOval(Color.White, topLeft = Offset(-s * 0.2f, -s * 0.42f), size = androidx.compose.ui.geometry.Size(s * 0.2f, s * 0.26f), alpha = alpha * 0.5f)
                        drawPath(Path().apply { moveTo(-s * 0.05f, s * 0.18f); lineTo(s * 0.05f, s * 0.18f); lineTo(0f, s * 0.26f); close() }, c, alpha = alpha)
                        val sway = sin(t * 6f) * s * 0.06f
                        drawPath(Path().apply { moveTo(0f, s * 0.26f); quadraticTo(sway + s * 0.08f, s * 0.5f, sway, s * 0.75f) }, c.copy(alpha = alpha), style = Stroke(s * 0.02f))
                    }
                }
                else -> { // confetti / sparkles
                    val c = listOf(st.c1, st.c2, st.c3, Color(0xffff6f91))[variant % 4]
                    rotate(t * 540f, Offset.Zero)
                    scale(scaleX = 0.4f + 0.6f * abs(cos(t * 8 * PI.toFloat())), scaleY = 1f, pivot = Offset.Zero) {
                        drawRect(c, topLeft = Offset(-s * 0.16f, -s * 0.06f), size = androidx.compose.ui.geometry.Size(s * 0.32f, s * 0.12f), alpha = alpha)
                    }
                    if (variant % 2 == 0) drawPath(Patterns.sparkle(0f, 0f, s * 0.16f), Color.White, alpha = alpha * 0.9f)
                }
            }
        }
    }

    private inline fun DrawScope.shadowed(path: Path?, s: Float, alpha: Float, block: () -> Unit) {
        translate(2f, 3f) {
            path?.let { drawPath(it, Color.Black.copy(alpha = 0.10f * alpha)) }
        }
        block()
    }

    /** Static corner piece used on ring screens and widgets. */
    fun DrawScope.cornerArt(f: Family, center: Offset, size: Float) {
        val st = Patterns.FAMILY[f]!!
        translate(center.x, center.y) {}
        Patterns.run { with(this@cornerArt) { drawMotif(f, 0f, 0f, size, mono = null) } }
        drawCircle(st.c3.copy(alpha = 0.12f), radius = size * 0.75f)
    }
}
