package app.dayflow.android.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatterySaver
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.alarm.RingScreen
import app.dayflow.android.calendar.Calendars
import app.dayflow.android.companion.RobotOverlayService
import app.dayflow.android.data.Store
import app.dayflow.android.notify.Notifications
import app.dayflow.android.prayer.PrayerEngine
import app.dayflow.android.time.TimeFmt
import app.dayflow.android.tones.Tones
import app.dayflow.android.ui.Chip
import app.dayflow.android.ui.DFCard
import app.dayflow.android.ui.DFToggle
import app.dayflow.android.ui.Group
import app.dayflow.android.ui.Honest
import app.dayflow.android.ui.MotifView
import app.dayflow.android.ui.RowItem
import app.dayflow.android.ui.ScreenHeader
import app.dayflow.android.ui.Segmented
import app.dayflow.android.ui.bodyStyle
import app.dayflow.android.ui.pack
import app.dayflow.android.ui.theme.THEMES
import app.dayflow.android.ui.theme.themeById
import app.dayflow.android.widget.WidgetCatalogView

/** Me hub + every sub-screen from the design (Themes, Widgets, Decor, Companion, Prayer, Alarm look, Notifications, Settings, About). */
@Composable
fun MeScreen(sub: String?, go: (String, String?) -> Unit) {
    val back = { go("me", null) }
    when (sub) {
        "themes" -> ThemesScreen(back)
        "widgets" -> Column(Modifier.fillMaxSize()) { WidgetCatalogView(lang = Store.current().lang, onBack = back) }
        "companion" -> CompanionSettingsScreen(back)
        "prayer" -> PrayerScreen(back)
        "alarmlook" -> AlarmLookScreen(back)
        "notifs" -> NotifScreen(back)
        "decor" -> DecorSettingsScreen(back)
        "settings" -> SettingsScreen(back)
        "about" -> AboutScreen(back)
        else -> MeHub(go)
    }
}

@Composable
private fun MeHub(go: (String, String?) -> Unit) {
    val s by Store.state.collectAsState()
    val lang = s.lang
    val fam = remember { Calendars.resolveDecor(java.time.LocalDate.now(), s.userDays).primary }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 96.dp)) {
        ScreenHeader(title = if (lang == "ar") "أنا" else "Me")
        DFCard(Modifier.padding(bottom = 14.dp)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                MotifView(fam, 44.dp)
                Spacer(Modifier.size(14.dp))
                Column {
                    Text("DAYFLOW", style = bodyStyle(16, FontWeight.Bold))
                    Text(if (lang == "ar") "أصلي · على جهازك · بلا WebView" else "Native · on this device", style = bodyStyle(12, color = pack.muted))
                    Text(themeById(s.themeId).let { if (lang == "ar") it.ar else it.en }, style = bodyStyle(12, color = pack.accent), modifier = Modifier.padding(top = 2.dp))
                }
            }
        }
        Group(if (lang == "ar") "المظهر" else "Look & feel") {
            RowItem(if (lang == "ar") "السمات" else "Themes", "${THEMES.size} حزمة", { Icon(Icons.Filled.Palette, null, Modifier.size(18.dp)) }) { go("me", "themes") }
            RowItem(if (lang == "ar") "المواسم والزينة" else "Seasons & decoration", if (lang == "ar") "الشدة، الواجهات" else "Intensity, surfaces", { Icon(Icons.Filled.Nightlight, null, Modifier.size(18.dp)) }) { go("me", "decor") }
            RowItem(if (lang == "ar") "الودجات" else "Widgets", "${app.dayflow.android.widget.WidgetCatalog.ALL.size} تصميمًا", { Icon(Icons.Filled.Widgets, null, Modifier.size(18.dp)) }) { go("me", "widgets") }
            RowItem(if (lang == "ar") "الإشعارات" else "Notifications", null, { Icon(Icons.Filled.Notifications, null, Modifier.size(18.dp)) }) { go("me", "notifs") }
            RowItem(if (lang == "ar") "شاشة المنبه" else "Alarm screen", null, { Icon(Icons.Filled.BatterySaver, null, Modifier.size(18.dp)) }) { go("me", "alarmlook") }
            RowItem(if (lang == "ar") "مواقيت الصلاة والمدينة" else "Prayer times & city", null, { Icon(Icons.Filled.CheckCircle, null, Modifier.size(18.dp)) }) { go("me", "prayer") }
            RowItem(if (lang == "ar") "الرفيق" else "Companion", if (s.companion.enabled) (if (lang == "ar") "مفعّل" else "On") else (if (lang == "ar") "ملغي" else "Off"), { Icon(Icons.Filled.SmartToy, null, Modifier.size(18.dp)) }, right = {
                DFToggle(s.companion.enabled) { on ->
                    Store.setCompanion { it.copy(enabled = on, hidden = false) }
                    val appCtx = ctxHolder()
                    if (on && Settings.canDrawOverlays(appCtx)) RobotOverlayService.start(appCtx) else RobotOverlayService.stop(appCtx)
                }
            }) { go("me", "companion") }
        }
        Group(if (lang == "ar") "التطبيق" else "App") {
            RowItem(if (lang == "ar") "الإعدادات" else "Settings", null, { Icon(Icons.Filled.Info, null, Modifier.size(18.dp)) }) { go("me", "settings") }
            RowItem(if (lang == "ar") "حول" else "About", null, { Icon(Icons.Filled.Person, null, Modifier.size(18.dp)) }) { go("me", "about") }
        }
    }
}

fun ctxHolder(): android.content.Context = app.dayflow.android.ui.shell.LocalContextHolder.ctx

@Composable
private fun ThemesScreen(back: () -> Unit) {
    val s by Store.state.collectAsState()
    val lang = s.lang
    var cat by remember { mutableStateOf("all") }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title = if (lang == "ar") "السمات" else "Themes", onBack = back)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            item { Chip(if (lang == "ar") "الكل" else "All", cat == "all") { cat = "all" } }
            items(CATEGORIES.size) { i ->
                val c = CATEGORIES[i]
                Chip(if (lang == "ar") c.second else c.first, cat == c.first) { cat = c.first }
            }
        }
        Spacer(Modifier.height(10.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 110.dp)) {
            items(THEMES.filter { cat == "all" || it.cat == cat }, key = { it.id }) { th ->
                val sel = s.themeId == th.id
                DFCard(onClick = { Store.mutate { it.copy(themeId = th.id) } }) {
                    Column(Modifier.padding(10.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(th.bg, th.surface, th.accent, th.accent2).forEach { c ->
                                Box(Modifier.size(22.dp).clip(CircleShape).background(c))
                            }
                        }
                        Text(if (lang == "ar") th.ar else th.en, style = bodyStyle(12, FontWeight.Bold), modifier = Modifier.padding(top = 8.dp))
                        Text(th.cat, style = bodyStyle(10, color = pack.muted))
                        if (sel) Text("✓ " + (if (lang == "ar") "نشطة" else "active"), style = bodyStyle(11, FontWeight.Bold, pack.accent))
                    }
                }
            }
        }
    }
}

val CATEGORIES = listOf(
    "light" to ("Light editorial" to "فاتح تحريري"), "dark" to ("Dark" to "داكن"), "egypt" to ("Egyptian heritage" to "تراث مصري"),
    "islamic" to ("Islamic & geometric" to "إسلامي وهندسي"), "nature" to ("Nature" to "طبيعة"), "glass" to ("Glass & depth" to "زجاج وعمق"),
    "tech" to ("Tech" to "تقني"), "warm" to ("Warm" to "دافئ"), "playful" to ("Playful" to "مرح"),
)

@Composable
private fun CompanionSettingsScreen(back: () -> Unit) {
    val s by Store.state.collectAsState()
    val lang = s.lang
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 96.dp)) {
        ScreenHeader(title = if (lang == "ar") "الرفيق" else "Companion", onBack = back)

        if (!Settings.canDrawOverlays(ctx)) {
            DFCard(Modifier.padding(bottom = 10.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text(if (lang == "ar") "إذن «الظهور فوق التطبيقات»" else "“Display over other apps” permission", style = bodyStyle(13, FontWeight.Bold))
                    Text(if (lang == "ar") "من غيره الروبوت يظل ظاهرًا داخل التطبيق فقط. افتح إعدادات النظام مرة واحدة ويصبح حرًّا على الشاشة كلها." else "Without it the robot stays inside the app only. Grant it once and it floats over everything.", style = bodyStyle(12, color = pack.muted))
                    Spacer(Modifier.height(8.dp))
                    app.dayflow.android.ui.DFButton(if (lang == "ar") "افتح الإعدادات" else "Open settings", {
                        ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:${ctx.packageName}")))
                    }, variant = "soft")
                }
            }
        }

        Group(null) {
            RowItem(if (lang == "ar") "تفعيل الرفيق" else "Enable companion", if (lang == "ar") "يطفو فوق كل التطبيقات" else "Floats over every app", right = {
                DFToggle(s.companion.enabled) { on ->
                    Store.setCompanion { it.copy(enabled = on, hidden = false) }
                    if (on && Settings.canDrawOverlays(ctx)) RobotOverlayService.start(ctx) else RobotOverlayService.stop(ctx)
                }
            })
            RowItem(if (lang == "ar") "فقاعات التذكير" else "Reminder bubbles", null, right = { DFToggle(s.companion.bubbles) { Store.setCompanion { cp -> cp.copy(bubbles = it) } } })
            RowItem(if (lang == "ar") "إشعار لإرجاعه" else "Bring-back notification", null, right = { DFToggle(s.companion.notify) { Store.setCompanion { cp -> cp.copy(notify = it) } } })
        }

        Group(if (lang == "ar") "شكله" else "Appearance") {
            Column(Modifier.padding(14.dp)) {
                Text(if (lang == "ar") "الحجم" else "Size", style = bodyStyle(13, FontWeight.SemiBold))
                Slider(value = s.companion.size, onValueChange = { Store.setCompanion { cp -> cp.copy(size = it) } }, valueRange = 0.7f..1.6f)
                Text(if (lang == "ar") "الشفافية" else "Opacity", style = bodyStyle(13, FontWeight.SemiBold))
                Slider(value = s.companion.opacity, onValueChange = { Store.setCompanion { cp -> cp.copy(opacity = it) } }, valueRange = 0.4f..1f)
                Text(if (lang == "ar") "الزي الموسمي" else "Outfit", style = bodyStyle(13, FontWeight.SemiBold), modifier = Modifier.padding(top = 4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf("auto" to "تلقائي", "gold" to "فانوس رمضان", "snow" to "شال الشتا", "national" to "شريط وطني", "none" to "بدون").size) { i ->
                        val (id, label) = listOf("auto" to "تلقائي", "gold" to "فانوس رمضان", "snow" to "شال الشتا", "national" to "شريط وطني", "none" to "بدون")[i]
                        Chip(label, s.companion.outfit == id) { Store.setCompanion { cp -> cp.copy(outfit = id) } }
                    }
                }
            }
        }

        Group(if (lang == "ar") "المزاج" else "Mood") {
            LazyRow(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(listOf("idle" to "عادي", "happy" to "فرحان", "sad" to "زعلان", "cold" to "بردان", "celebrate" to "مبسوط", "think" to "بيفكر", "wink" to "وينك", "sleep" to "نايم", "worried" to "قلقان").size) { i ->
                    val (id, label) = listOf("idle" to "عادي", "happy" to "فرحان", "sad" to "زعلان", "cold" to "بردان", "celebrate" to "مبسوط", "think" to "بيفكر", "wink" to "وينك", "sleep" to "نايم", "worried" to "قلقان")[i]
                    Chip(label, s.companion.emotion == id) { Store.setCompanion { cp -> cp.copy(emotion = id) } }
                }
            }
        }
    }
}

@Composable
private fun PrayerScreen(back: () -> Unit) {
    val s by Store.state.collectAsState()
    val lang = s.lang
    val city = PrayerEngine.CITIES[s.cityIndex.coerceIn(PrayerEngine.CITIES.indices)]
    val zone = java.time.ZoneId.systemDefault()
    val next = PrayerEngine.next(java.time.ZonedDateTime.now(zone), s.customLat ?: city.lat, s.customLng ?: city.lng, zone)
    val times = PrayerEngine.timesFor(java.time.LocalDate.now(), s.customLat ?: city.lat, s.customLng ?: city.lng, zone)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 96.dp)) {
        ScreenHeader(title = if (lang == "ar") "مواقيت الصلاة" else "Prayer times", subtitle = if (lang == "ar") city.ar else city.en, onBack = back)
        DFCard {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (lang == "ar") "الصلاة القادمة" else "Next prayer", style = bodyStyle(12, color = pack.muted))
                        if (next != null) {
                            Text("${(if (lang == "ar") PrayerEngine.NAMES_AR[next.p] else PrayerEngine.NAMES_EN[next.p]) ?: ""} · ${TimeFmt.fmt(next.at.toLocalTime().toString().substring(0, 5), lang)}", style = bodyStyle(22, FontWeight.Bold))
                            Text(TimeFmt.until(next.at.toInstant().toEpochMilli() - System.currentTimeMillis(), lang), style = bodyStyle(12, color = pack.muted))
                        }
                    }
                    MotifView(Calendars.Family.islamic, 44.dp)
                }
                PrayerEngine.P.entries.forEach { pk ->
                    val t = times[pk]?.toString()?.substring(0, 5) ?: "—"
                    val isNext = next?.p == pk
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(if (isNext) pack.soft else Color.Transparent).padding(horizontal = 10.dp, vertical = 8.dp),
                    ) {
                        Text((if (lang == "ar") PrayerEngine.NAMES_AR[pk] else PrayerEngine.NAMES_EN[pk]) ?: "", Modifier.weight(1f), style = bodyStyle(13))
                        Text(TimeFmt.fmt(t, lang), style = bodyStyle(13, FontWeight.Bold))
                    }
                }
            }
        }
        Group(if (lang == "ar") "المدينة" else "City") {
            LazyRow(Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(PrayerEngine.CITIES.size) { i ->
                    val c = PrayerEngine.CITIES[i]
                    Chip(if (lang == "ar") c.ar else c.en, s.cityIndex == i) { Store.mutate { it.copy(cityIndex = i, customLat = null, customLng = null) } }
                }
            }
        }
        Honest(if (lang == "ar") "الحساب فلكي على الجهاز (الفجر ١٩٫٥°، العشاء ١٧٫٥°، العصر القياسي) ويقرأ توقيت النظام الحقيقي — التوقيت الصيفي المصري مضبوط تلقائيًا." else "Astronomical, on-device (Fajr 19.5°, Isha 17.5°, standard Asr); Egypt DST is handled by the system time zone automatically.")
    }
}

@Composable
private fun AlarmLookScreen(back: () -> Unit) {
    val s by Store.state.collectAsState()
    val lang = s.lang
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 96.dp)) {
        ScreenHeader(title = if (lang == "ar") "شاشة المنبه" else "Alarm screen", onBack = back)
        DFCard {
            Box(Modifier.fillMaxWidth().height(240.dp).clip(RoundedCornerShape(20.dp))) {
                RingScreen("منبه", 10, "", lang, s.alarmLook.showSeconds, s.alarmLook.gradient, s.userDays, "subtle", {}, {})
            }
        }
        Group(if (lang == "ar") "الشكل" else "Layout") {
            LazyRow(Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(listOf("ornate" to "مزخرف", "midnight" to "ليل", "minimal" to "بسيط", "glass" to "زجاج").size) { i ->
                    val (id, label) = listOf("ornate" to "مزخرف", "midnight" to "ليل", "minimal" to "بسيط", "glass" to "زجاج")[i]
                    Chip(label, s.alarmLook.layout == id) { Store.mutate { it.copy(alarmLook = it.alarmLook.copy(layout = id)) } }
                }
            }
        }
        Group(null) {
            RowItem(if (lang == "ar") "إظهار الثواني" else "Show seconds", right = { DFToggle(s.alarmLook.showSeconds) { Store.mutate { st -> st.copy(alarmLook = st.alarmLook.copy(showSeconds = it)) } } })
            RowItem(if (lang == "ar") "تدرج موسمي" else "Seasonal gradient", right = { DFToggle(s.alarmLook.gradient) { Store.mutate { st -> st.copy(alarmLook = st.alarmLook.copy(gradient = it)) } } })
        }
        Honest(if (lang == "ar") "هذه معاينة حية؛ شاشة الرنين الفعلية أصلية وتظهر فوق شاشة القفل والشاشة المطفأة." else "Live preview; the real ring screen is native, on the lock screen too.")
    }
}

@Composable
private fun NotifScreen(back: () -> Unit) {
    val s by Store.state.collectAsState()
    val lang = s.lang
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 96.dp)) {
        ScreenHeader(title = if (lang == "ar") "الإشعارات" else "Notifications", onBack = back)
        if (!Notifications.hasPermission(ctx)) {
            DFCard(Modifier.padding(bottom = 10.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text(if (lang == "ar") "إذن الإشعارات غير ممنوح" else "Notification permission missing", style = bodyStyle(13, FontWeight.Bold))
                    app.dayflow.android.ui.DFButton(if (lang == "ar") "اطلب الإذن" else "Ask", {
                        if (android.os.Build.VERSION.SDK_INT >= 33) {
                            (ctx as? android.app.Activity)?.requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 999)
                        }
                    }, variant = "soft", modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
        Group(null) {
            RowItem(if (lang == "ar") "معاينة المحتوى" else "Content preview", right = { DFToggle(s.notif.preview) { Store.mutate { st -> st.copy(notif = st.notif.copy(preview = it)) } } })
            RowItem(if (lang == "ar") "الصوت" else "Sound", right = { DFToggle(s.notif.sound) { Store.mutate { st -> st.copy(notif = st.notif.copy(sound = it)) } } })
            RowItem(if (lang == "ar") "الاهتزاز" else "Vibrate", right = { DFToggle(s.notif.vibrate) { Store.mutate { st -> st.copy(notif = st.notif.copy(vibrate = it)) } } })
            RowItem(if (lang == "ar") "ساعات الهدوء" else "Quiet hours", right = { DFToggle(s.notif.quiet) { Store.mutate { st -> st.copy(notif = st.notif.copy(quiet = it)) } } })
        }
        Group(null) {
            RowItem(if (lang == "ar") "جرّب إشعارًا حقيقيًا" else "Fire a real test notification", null) {
                Notifications.reminderHit(ctx)
            }
        }
    }
}

@Composable
private fun DecorSettingsScreen(back: () -> Unit) {
    val s by Store.state.collectAsState()
    val lang = s.lang
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 96.dp)) {
        ScreenHeader(title = if (lang == "ar") "المواسم والزينة" else "Seasons & decoration", onBack = back)
        Segmented(
            listOf("off" to (if (lang == "ar") "إيقاف" else "Off"), "subtle" to (if (lang == "ar") "هادئ" else "Subtle"), "rich" to (if (lang == "ar") "غني" else "Rich"), "festival" to (if (lang == "ar") "احتفالي" else "Festival")),
            s.intensity, { Store.mutate { st -> st.copy(intensity = it) } },
        )
        Group(if (lang == "ar") "أين تظهر" else "Where to decorate") {
            (listOf("app", "notifications", "widgets", "icon", "companion")).forEach { k ->
                RowItem(if (lang == "ar") mapOf("app" to "داخل التطبيق", "notifications" to "الإشعارات", "widgets" to "الودجات", "icon" to "أيقونة التطبيق", "companion" to "زي الرفيق")[k]!! else k, right = { DFToggle(s.decorSurfaces[k] == true) { on -> Store.mutate { st -> st.copy(decorSurfaces = st.decorSurfaces + (k to on)) } } })
            }
        }
        Honest(if (lang == "ar") "الزخارف الموسمية الجديدة (ثلج بطبقات عمق، زهور ساكورا، فقاعات صيف، فوانيس مضيئة، يراعات، بالونات) كلها متجهة احترافية على Canvas — بلا أي ملفات خارجية." else "New realistic seasonal sets (depth-layered snow, sakura, summer bubbles, glowing lanterns, fireflies, balloons) — professional vector Canvas art.")
    }
}

@Composable
private fun SettingsScreen(back: () -> Unit) {
    val s by Store.state.collectAsState()
    val lang = s.lang
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 96.dp)) {
        ScreenHeader(title = if (lang == "ar") "الإعدادات" else "Settings", onBack = back)
        Group(if (lang == "ar") "عام" else "General") {
            RowItem(if (lang == "ar") "اللغة" else "Language", right = {
                Segmented(listOf("ar" to "ع", "en" to "EN"), s.lang) { Store.mutate { st -> st.copy(lang = it) } }
            })
            RowItem(if (lang == "ar") "الساعة بنظام ١٢ ساعة" else "12-hour clock", hint = if (lang == "ar") "مفعّل دائمًا في النسخة الأصلية" else "Always on in the native build", right = { DFToggle(true) {} })
            RowItem(if (lang == "ar") "تقليل الحركة" else "Reduce motion", right = { DFToggle(s.reduceMotion) { Store.mutate { st -> st.copy(reduceMotion = it) } } })
            RowItem(if (lang == "ar") "زينة موسم الامتحانات" else "Exam season decor", right = { DFToggle(s.examSeason) { Store.mutate { st -> st.copy(examSeason = it) } } })
        }
    }
}

@Composable
private fun AboutScreen(back: () -> Unit) {
    val lang = Store.current().lang
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 96.dp)) {
        ScreenHeader(title = if (lang == "ar") "حول والاعتمادات" else "About & credits", onBack = back)
        Group(if (lang == "ar") "مزوّدات مفتوحة المصدر" else "Open-source used here") {
            listOf(
                "Kotlin + Jetpack Compose" to "Apache-2.0", "OkHttp" to "Apache-2.0", "Jsoup" to "MIT",
                "kotlinx-serialization" to "Apache-2.0", "Coil" to "Apache-2.0", "ZXing" to "Apache-2.0",
                "ML Kit" to "Google", "Material 3" to "Google",
            ).forEach { (a, b) -> RowItem(a, right = { Text(b, fontSize = 10.sp, color = pack.muted) }) }
        }
        Text("DAYFLOW — نسخة أندرويد أصلية", style = bodyStyle(12, color = pack.muted), modifier = Modifier.padding(16.dp).fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}
