package app.dayflow.android.widget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import app.dayflow.android.data.Store
import app.dayflow.android.data.WidgetCfg
import app.dayflow.android.ui.DayflowTheme
import app.dayflow.android.ui.screens.WidgetCatalogView
import app.dayflow.android.ui.theme.themeById
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

/**
 * Dropping any DAYFLOW gateway size onto the home screen routes here first:
 * the full in-app widget catalog opens, the user picks one design, and that
 * design is bound to this exact widget instance immediately.
 */
class WidgetConfigActivity : ComponentActivity() {

    private var appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        appWidgetId = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }

        // Hosts MUST receive a cancelled result until a design is truly chosen.
        setResult(Activity.RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId))

        setContent {
            val s = runBlocking { Store.state.first() }
            DayflowTheme(pack = themeById(s.themeId), rtl = s.lang == "ar") {
                WidgetCatalogView(
                    lang = s.lang,
                    banner = if (s.lang == "ar") "اختار تصميم واحد ليكون هو الودجت" else "Pick one design — it becomes this widget",
                    onPick = { def, style -> bind(def.id, style) },
                    onBack = { finish() },
                )
            }
        }
    }

    private fun bind(designId: String, style: String) {
        Store.saveWidgetCfg(appWidgetId, WidgetCfg(designId, style, tapOpens = true))
        val mgr = AppWidgetManager.getInstance(this)
        GatewayWidget.updateOne(this, mgr, appWidgetId)
        setResult(Activity.RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId))
        finish()
    }
}
