package app.dayflow.android

import android.app.Application
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat
import app.dayflow.android.alarm.AlarmScheduler
import app.dayflow.android.companion.RobotOverlayService
import app.dayflow.android.data.Store
import app.dayflow.android.notify.Notifications
import app.dayflow.android.widget.WidgetSync
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

/** DAYFLOW native application shell — no WebView anywhere in the core UI. */
class DayflowApp : Application() {

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Notifications.createChannels(this)

        // Restore every scheduled alarm/reminder at app start (covers process death).
        appScope.launch(Dispatchers.IO) { AlarmScheduler.restoreAll(this@DayflowApp) }

        // Any state change that affects home-screen widgets repaints them natively.
        Store.state
            .onEach { WidgetSync.pushAll(this@DayflowApp) }
            .launchIn(appScope)

        // The companion overlay auto-starts if the user enabled it and granted access.
        if (Store.current().companion.enabled && !Store.current().companion.hidden &&
            Settings.canDrawOverlays(this)
        ) {
            ContextCompat.startForegroundService(this, Intent(this, RobotOverlayService::class.java))
        }
    }
}
