package app.dayflow.android.companion

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.service.quicksettings.TileService
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import app.dayflow.android.MainActivity
import app.dayflow.android.R
import app.dayflow.android.calendar.Calendars
import app.dayflow.android.data.Store
import app.dayflow.android.notify.Notifications
import app.dayflow.android.time.TimeFmt
import app.dayflow.android.ui.theme.THEMES
import app.dayflow.android.ui.theme.themeById
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.hypot

/**
 * The real deal: a TYPE_APPLICATION_OVERLAY foreground service that renders the
 * same companion above the launcher and every other app — draggable with fling
 * physics and edge docking, tappable for the quick panel, with reminder bubbles.
 */
class RobotOverlayService : android.app.Service(), LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {

    companion object {
        const val ACTION_STOP = "app.dayflow.android.STOP_OVERLAY"
        fun start(ctx: Context) {
            if (!android.provider.Settings.canDrawOverlays(ctx)) return
            androidx.core.content.ContextCompat.startForegroundService(ctx, Intent(ctx, RobotOverlayService::class.java))
        }
        fun stop(ctx: Context) = ctx.stopService(Intent(ctx, RobotOverlayService::class.java))
    }

    // Minimal owners so a WindowManager-hosted ComposeView composes correctly.
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateController = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()
    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateController.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    private lateinit var wm: WindowManager
    private var root: View? = null
    private var panel: View? = null
    private val rig = RobotModel.Rig()
    private var vx = 0f; private var vy = 0f
    private var dragging = false
    private var downX = 0f; private var downY = 0f; private var downT = 0L
    private var grabX = 0f; private var grabY = 0f
    private var histPos = ArrayDeque<Triple<Float, Float, Long>>()

    override fun onCreate() {
        super.onCreate()
        savedStateController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.CREATED
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        startForeground(Notifications.ID_COMPANION + 9, overlayNotification(), if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0)
        showRobot()
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Store.setCompanion { it.copy(hidden = true) }
            Notifications.companionHidden(this)
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun overlayNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).putExtra("tab", "me:companion"), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, RobotOverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, Notifications.CH_COMPANION)
            .setSmallIcon(R.drawable.ic_launcher_fg)
            .setContentTitle(getString(R.string.overlay_running))
            .setContentText("اسحبه أي مكان · اضغط عليه للوحة السريعة")
            .setContentIntent(open)
            .addAction(0, getString(R.string.overlay_stop), stop)
            .setOngoing(true)
            .build()
    }

    private fun density() = resources.displayMetrics.density
    private fun robotW(): Float = 120 * 0.74f * Store.current().companion.size * 62 * density() / 60f
    private fun robotH(): Float = 154 * 0.74f * Store.current().companion.size * density() * 0.95f

    private fun showRobot() {
        if (root != null) return
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (screenW - robotW()).toInt() - 10
            y = (screenH - robotH()).toInt() - 140
        }

        val view = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@RobotOverlayService)
            setViewTreeViewModelStoreOwner(this@RobotOverlayService)
            setViewTreeSavedStateRegistryOwner(this@RobotOverlayService)
            setContent { OverlayRobot() }
        }

        view.setOnTouchListener { v, e -> onTouch(lp, v, e) }
        wm.addView(view, lp)
        root = view

        // physics ticker — visible only while moving/interacting, like the web idle-stop
        android.os.Handler(mainLooper).post(object : Runnable {
            var last = System.nanoTime()
            override fun run() {
                val now = System.nanoTime()
                val dt = ((now - last) / 1e9f).coerceAtMost(0.05f)
                last = now
                if (!dragging) {
                    vx *= 0.94f; vy *= 0.94f
                    val maxX = resources.displayMetrics.widthPixels - robotW() - 6
                    val maxY = resources.displayMetrics.heightPixels - robotH() - 80
                    if (abs(vx) < 40 && abs(vy) < 40) {
                        val tx = if (lp.x + robotW() / 2 < resources.displayMetrics.widthPixels / 2) 6f else maxX
                        vx += (tx - lp.x) * 18 * dt
                    }
                    lp.x = (lp.x + vx * dt).toInt().coerceIn(6, maxX.toInt())
                    lp.y = (lp.y + vy * dt).toInt().coerceIn(10, maxY.toInt())
                    rig.vx = vx; rig.vy = vy
                    if (abs(vx) > 2 || abs(vy) > 2) runCatching { wm.updateViewLayout(view, lp) }
                    rig.step(System.currentTimeMillis(), dt)
                } else {
                    rig.step(System.currentTimeMillis(), dt)
                }
                if (root != null) android.os.Handler(mainLooper).postDelayed(this, 16)
            }
        })
    }

    private fun onTouch(lp: WindowManager.LayoutParams, v: View, e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = false
                downX = e.rawX; downY = e.rawY; downT = System.currentTimeMillis()
                grabX = e.rawX - lp.x; grabY = e.rawY - lp.y
                histPos.clear()
            }
            MotionEvent.ACTION_MOVE -> {
                if (hypot(e.rawX - downX, e.rawY - downY) > 8 * density()) dragging = true
                rig.lookX = ((e.rawX - (lp.x + robotW() / 2)) / (200 * density())).coerceIn(-1f, 1f)
                rig.lookY = ((e.rawY - (lp.y + robotH() * 0.3f)) / (200 * density())).coerceIn(-1f, 1f)
                if (dragging) {
                    val nx = e.rawX - grabX; val ny = e.rawY - grabY
                    val now = System.currentTimeMillis()
                    histPos.addLast(Triple(nx, ny, now))
                    while (histPos.isNotEmpty() && now - histPos.first().third > 90) histPos.removeFirst()
                    val h0 = histPos.peekFirst()
                    if (h0 != null) {
                        val dt = ((now - h0.third) / 1000f).coerceAtLeast(0.016f)
                        vx = (nx - h0.first) / dt; vy = (ny - h0.second) / dt
                    }
                    lp.x = nx.toInt(); lp.y = ny.toInt()
                    runCatching { wm.updateViewLayout(v, lp) }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val isTap = hypot(e.rawX - downX, e.rawY - downY) < 16 * density() && System.currentTimeMillis() - downT < 550
                if (isTap) {
                    vx = 0f; vy = 0f
                    togglePanel(lp)
                }
                dragging = false
            }
        }
        return true
    }

    // ── quick panel (same tabs as the in-app panel) ──────────────
    private fun togglePanel(robotLp: WindowManager.LayoutParams) {
        if (panel != null) { wm.removeView(panel); panel = null; return }
        val lp = WindowManager.LayoutParams(
            (232 * density() * 1.55f).toInt().coerceAtMost(resources.displayMetrics.widthPixels - 24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val onLeft = robotLp.x + robotW() / 2 < resources.displayMetrics.widthPixels / 2
            x = if (onLeft) robotLp.x else (robotLp.x + robotW() - (232 * density() * 1.55f)).toInt().coerceAtLeast(12)
            y = (robotLp.y - (60 * density()).toInt()).coerceAtLeast(20)
        }
        val view = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@RobotOverlayService)
            setViewTreeViewModelStoreOwner(this@RobotOverlayService)
            setViewTreeSavedStateRegistryOwner(this@RobotOverlayService)
            setContent { OverlayPanel(onClose = { panel?.let { wm.removeView(it); panel = null } }) }
        }
        wm.addView(view, lp)
        panel = view
    }

    // ── Compose content ──────────────────────────────────────────
    @Composable
    private fun OverlayRobot() {
        val s = Store.state.collectAsState().value
        val family = when (s.companion.outfit) {
            "gold" -> Calendars.Family.ramadan
            "snow" -> Calendars.Family.winter
            "national" -> Calendars.Family.national
            "none" -> Calendars.Family.friday
            else -> Calendars.resolveDecor(java.time.LocalDate.now(), s.userDays, 2).primary
        }
        val theme = themeById(s.themeId)
        val now = remember { mutableLongStateOf(System.currentTimeMillis()) }
        LaunchedEffect(Unit) { while (true) { androidx.compose.runtime.withFrameNanos { now.longValue = System.currentTimeMillis() } } }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (s.companion.bubbles) OverlayBubble(s)
            Canvas(
                Modifier
                    .size(width = (120 * 0.74f * s.companion.size * 1.9f).dp, height = (154 * 0.74f * s.companion.size * 1.9f).dp)
                    .alpha(s.companion.opacity),
            ) {
                val scale = size.width / (120f * 0.9f)
                androidx.compose.ui.graphics.drawscope.scale(scale, scale, pivot = androidx.compose.ui.geometry.Offset.Zero) {
                    RobotModel.run { drawRobot(rig, s.companion.emotion, family, theme.accent, theme.accent2, now.longValue) }
                }
            }
        }
    }

    @Composable
    private fun OverlayBubble(s: app.dayflow.android.data.State) {
        val today = Store.dayKey()
        val mine = s.tasks.filter { it.date == today }
        val doneAll = mine.isNotEmpty() && mine.all { it.done }
        val next = app.dayflow.android.alarm.NextAlarm.soonest(s.alarms)
        val line = when {
            next != null -> "فاضل ${TimeFmt.until(next.second.time - System.currentTimeMillis(), s.lang)} على «${next.first.label.ifBlank { "المنبه" }}»"
            doneAll -> "خلصت كل مهام النهاردة! أنا فخور بيك"
            mine.isNotEmpty() -> "لسه ${TimeFmt.num(mine.count { !it.done }, s.lang)} مهام مستنياك"
            else -> "أنا معاك — اضغط عليّا للوحة السريعة"
        }
        Column(
            Modifier.padding(bottom = 4.dp).width(220.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White.copy(alpha = 0.94f))
                .border(1.dp, Color(0x22000000), RoundedCornerShape(16.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
        ) {
            Text("DAYFLOW", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0x99000000))
            Text(line, fontSize = 12.5f.sp, color = Color(0xff1d1c1a))
        }
    }

    @Composable
    private fun OverlayPanel(onClose: () -> Unit) {
        val s by Store.state.collectAsState()
        val theme = themeById(s.themeId)
        val today = Store.dayKey()
        Column(
            Modifier.clip(RoundedCornerShape(24.dp)).background(theme.surface).border(1.dp, theme.line, RoundedCornerShape(24.dp))
                .padding(14.dp).verticalScroll(rememberScrollState()),
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("الرفيق", fontWeight = FontWeight.Bold, color = theme.text, fontSize = 15.sp)
                Spacer(Modifier.weight(1f))
                Box(Modifier.size(26.dp).clip(CircleShape).background(theme.soft).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
                    Text("✕", color = theme.text, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("مهام اليوم", fontSize = 12.sp, color = theme.muted, fontWeight = FontWeight.SemiBold)
            s.tasks.filter { it.date == today }.take(6).forEach { t ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { Store.toggleTask(t.id) }, verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(18.dp).clip(RoundedCornerShape(5.dp)).border(2.dp, theme.accent, RoundedCornerShape(5.dp)).background(if (t.done) theme.accent else Color.Transparent))
                    Spacer(Modifier.width(8.dp))
                    Text(t.title, fontSize = 13.sp, color = if (t.done) theme.muted else theme.text)
                }
            }
            if (s.tasks.none { it.date == today }) Text("مفيش مهام النهاردة", fontSize = 12.sp, color = theme.muted)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PanelBtn("+٢٥٠ مل", theme) { Store.addWater(250) }
                PanelBtn("فتح التطبيق", theme) { startActivity(Intent(this@RobotOverlayService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); onClose() }
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PanelBtn("إخفاء", theme) { Store.setCompanion { it.copy(hidden = true) }; Notifications.companionHidden(this@RobotOverlayService); stopSelf() }
                PanelBtn("المنبهات", theme) { startActivity(Intent(this@RobotOverlayService, MainActivity::class.java).putExtra("tab", "alarms").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); onClose() }
            }
        }
    }

    @Composable
    private fun PanelBtn(label: String, theme: app.dayflow.android.ui.theme.ThemePack, onClick: () -> Unit) {
        Box(Modifier.clip(RoundedCornerShape(12.dp)).background(theme.soft).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp)) {
            Text(label, fontSize = 12.sp, color = theme.text, fontWeight = FontWeight.SemiBold)
        }
    }

    override fun onDestroy() {
        root?.let { runCatching { wm.removeView(it) } }; root = null
        panel?.let { runCatching { wm.removeView(it) } }; panel = null
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        store.clear()
        super.onDestroy()
    }
}
