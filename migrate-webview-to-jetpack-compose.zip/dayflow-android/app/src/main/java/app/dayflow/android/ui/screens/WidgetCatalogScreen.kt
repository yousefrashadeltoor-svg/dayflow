package app.dayflow.android.ui.screens

import android.app.Activity
import android.appwidget.AppWidgetManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.data.Store
import app.dayflow.android.ui.Chip
import app.dayflow.android.ui.DFCard
import app.dayflow.android.ui.DFButton
import app.dayflow.android.ui.DFSheet
import app.dayflow.android.ui.Honest
import app.dayflow.android.ui.ScreenHeader
import app.dayflow.android.ui.Segmented
import app.dayflow.android.ui.bodyStyle
import app.dayflow.android.ui.pack
import app.dayflow.android.widget.WidgetCatalog

val WSTYLES = listOf(
    "oneui" to ("One UI Glass" to "زجاج One UI"),
    "material" to ("Material You" to "Material You"),
    "ios" to ("iOS-inspired" to "مستوحى من iOS"),
    "editorial" to ("Editorial" to "تحريري"),
    "neon" to ("Neon" to "نيون"),
    "paper" to ("Paper" to "ورق"),
    "clay" to ("Soft Clay" to "صلصال"),
    "outline" to ("Minimal Outline" to "خطوط بسيطة"),
    "amoled" to ("AMOLED" to "أموليد"),
    "seasonal" to ("Seasonal" to "موسمي"),
)

/**
 * The WidgetHub catalog — same screen inside the app and inside the launcher
 * widget-config flow. onPick!=null means "choose the design for this widget".
 */
@Composable
fun WidgetCatalogView(
    lang: String,
    banner: String? = null,
    onPick: ((WidgetCatalog.Def, String) -> Unit)? = null, // style as String
    onBack: (() -> Unit)? = null,
    onAddToBoard: ((WidgetCatalog.Def, String) -> Unit)? = null,
) {
    var mode by rememberSaveable { mutableStateOf("catalog") }
    var q by rememberSaveable { mutableStateOf("") }
    var cat by rememberSaveable { mutableStateOf("all") }
    var style by rememberSaveable { mutableStateOf("oneui") }
    var sel by remember { mutableStateOf<WidgetCatalog.Def?>(null) }
    val p = pack

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = if (lang == "ar") "الودجات" else "Widgets",
            subtitle = if (lang == "ar") "${WidgetCatalog.ALL.size} تصميمًا · كل تصميم يتغير شكله عند تغيير الحجم" else "${WidgetCatalog.ALL.size} designs · every one changes shape when resized",
            onBack = onBack,
        )
        if (banner != null) {
            DFCard(Modifier.padding(bottom = 10.dp)) {
                Text(banner, style = bodyStyle(14, FontWeight.Bold, p.accent), modifier = Modifier.padding(12.dp))
            }
        }
        Segmented(
            options = listOf("catalog" to (if (lang == "ar") "الكتالوج" else "Catalog"), "board" to (if (lang == "ar") "معاينة الشاشة (${Store.current().placed.size})" else "Home preview (${Store.current().placed.size})")),
            value = mode, onChange = { mode = it },
        )
        Spacer(Modifier.height(10.dp))

        if (mode == "catalog") {
            OutlinedTextField(
                value = q, onValueChange = { q = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text(if (lang == "ar") "ابحث في الودجات" else "Search widgets") },
                leadingIcon = { Icon(Icons.Filled.Search, null, tint = p.muted) },
                singleLine = true,
            )
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                item { Chip(if (lang == "ar") "الكل" else "All", cat == "all") { cat = "all" } }
                items(WidgetCatalog.cats) { (id, names) -> Chip(if (lang == "ar") names.second else names.first, cat == id) { cat = id } }
            }
            Spacer(Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(WSTYLES) { (id, names) -> Chip(if (lang == "ar") names.second else names.first, style == id) { style = id } }
            }
            Spacer(Modifier.height(10.dp))

            val list = WidgetCatalog.ALL.filter {
                (cat == "all" || it.cat == cat) && (q.isBlank() || (it.en + it.ar).contains(q, true))
            }
            LazyVerticalGrid(columns = GridCells.Adaptive(120.dp), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 120.dp)) {
                items(list, key = { it.id }) { def ->
                    DFCard(onClick = { sel = def }) {
                        Column(Modifier.padding(10.dp)) {
                            WidgetPreviewTile(def, style, lang)
                            Text(if (lang == "ar") def.ar else def.en, style = bodyStyle(11, FontWeight.SemiBold), maxLines = 1)
                            Text("${def.forms.size} " + (if (lang == "ar") "أشكال" else "forms") + if (def.interactive) " · " + (if (lang == "ar") "تفاعلي" else "interactive") else "", style = bodyStyle(10, color = p.muted))
                        }
                    }
                }
            }
            Honest(
                if (lang == "ar")
                    "أندرويد هو من يحدد شكل منتقي الودجات. ضع أي حجم من بوابات DAYFLOW على شاشتك فيفتح هذا الكتالوج فورًا لتختار التصميم، وسيُرسم على الشاشة الرئيسية ببياناتك الحقيقية."
                else "Android itself owns the widget picker. Drop any DAYFLOW gateway size and this catalog opens right away; your pick renders on the home screen with your real data.",
            )
        } else {
            BoardPreview(lang)
        }
    }

    sel?.let { def ->
        DFSheet(open = true, onClose = { sel = null }, title = if (lang == "ar") def.ar else def.en) {
            WidgetPreviewTile(def, style, lang, big = true)
            Spacer(Modifier.height(10.dp))
            Text(if (lang == "ar") "النمط" else "Style", style = bodyStyle(12, FontWeight.SemiBold, p.muted))
            Spacer(Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(WSTYLES) { (id, names) -> Chip(if (lang == "ar") names.second else names.first, style == id) { style = id } }
            }
            Spacer(Modifier.height(12.dp))
            DFButton(
                if (onPick != null) (if (lang == "ar") "استخدم هذا التصميم" else "Use this design") else (if (lang == "ar") "أضف إلى معاينة الشاشة" else "Add to home preview"),
                onClick = {
                    if (onPick != null) onPick(def, style) else {
                        Store.placeWidget(def.id, 2, 2, style)
                        onAddToBoard?.invoke(def, style)
                    }
                    sel = null
                },
                modifier = Modifier.fillMaxWidth(),
                icon = { Icon(Icons.Filled.Add, null, tint = pack.onAccent) },
            )
        }
    }
}

/** Design glyph preview (same wallpaper strip vibe). */
@Composable
fun WidgetPreviewTile(def: WidgetCatalog.Def, style: String, lang: String, big: Boolean = false) {
    val tok = WidgetPreview.paletteFor(style)
    Box(
        Modifier.fillMaxWidth().height(if (big) 160.dp else 84.dp).verticalScroll(rememberScrollState()),
        contentAlignment = androidx.compose.ui.Alignment.Center,
    ) {
        androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(if (big) 150.dp else 76.dp)) {
            val w = size.width; val h = size.height
            val r = if (def.arche == "note" || style == "editorial") 6.dp.toPx() else 22.dp.toPx()
            drawRoundRect(tok.bg2?.let { androidx.compose.ui.graphics.Brush.linearGradient(listOf(tok.bg, it)) } ?: androidx.compose.ui.graphics.Brush.linearGradient(listOf(tok.bg, tok.bg)), cornerRadius = androidx.compose.ui.geometry.CornerRadius(r), size = size)
            when (def.arche) {
                "analog" -> {
                    val cx = w / 2; val cy = h / 2; val rad = minOf(w, h) / 2 - 12
                    drawCircle(tok.text.copy(alpha = 0.3f), radius = rad, center = androidx.compose.ui.geometry.Offset(cx, cy), style = androidx.compose.ui.graphics.drawscope.Stroke(3f))
                    drawLine(tok.text, androidx.compose.ui.geometry.Offset(cx, cy), androidx.compose.ui.geometry.Offset(cx + rad * 0.4f, cy - rad * 0.2f), strokeWidth = 5f, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                    drawLine(tok.accent, androidx.compose.ui.geometry.Offset(cx, cy), androidx.compose.ui.geometry.Offset(cx - rad * 0.3f, cy - rad * 0.55f), strokeWidth = 3f, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                }
                "checklist" -> {
                    repeat(3) { i ->
                        val y = h * 0.22f + i * h * 0.26f
                        drawRoundRect(tok.accent, topLeft = androidx.compose.ui.geometry.Offset(w * 0.12f, y), size = androidx.compose.ui.geometry.Size(14f, 14f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f))
                        drawRoundRect(tok.text.copy(alpha = if (i == 2) 0.25f else 0.6f), topLeft = androidx.compose.ui.geometry.Offset(w * 0.12f + 22f, y + 3f), size = androidx.compose.ui.geometry.Size(w * 0.6f * (1f - i * 0.15f), 8f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f))
                    }
                }
                "prayer", "nextprayer" -> {
                    drawRoundRect(tok.accent.copy(alpha = 0.25f), topLeft = androidx.compose.ui.geometry.Offset(w * 0.1f, h * 0.2f), size = androidx.compose.ui.geometry.Size(w * 0.8f, h * 0.28f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f))
                    repeat(6) { i ->
                        drawCircle(tok.text.copy(alpha = if (i == 3) 1f else 0.35f), radius = if (i == 3) 7f else 5f, center = androidx.compose.ui.geometry.Offset(w * 0.14f + i * (w * 0.72f / 5), h * 0.66f))
                    }
                }
                "ring", "dial" -> {
                    drawArc(tok.text.copy(alpha = 0.15f), -90f, 360f, false, topLeft = androidx.compose.ui.geometry.Offset(w / 2 - 24, h / 2 - 24), size = androidx.compose.ui.geometry.Size(48f, 48f), style = androidx.compose.ui.graphics.drawscope.Stroke(6f, cap = androidx.compose.ui.graphics.StrokeCap.Round))
                    drawArc(tok.accent, -90f, 250f, false, topLeft = androidx.compose.ui.geometry.Offset(w / 2 - 24, h / 2 - 24), size = androidx.compose.ui.geometry.Size(48f, 48f), style = androidx.compose.ui.graphics.drawscope.Stroke(6f, cap = androidx.compose.ui.graphics.StrokeCap.Round))
                }
                "month" -> {
                    val rows = 3; val cols = 5
                    for (rr in 0 until rows) for (cc in 0 until cols) {
                        val today = rr == 1 && cc == 2
                        drawRoundRect(if (today) tok.accent else tok.text.copy(alpha = 0.18f), topLeft = androidx.compose.ui.geometry.Offset(w * 0.1f + cc * w * 0.16f, h * 0.18f + rr * h * 0.24f), size = androidx.compose.ui.geometry.Size(w * 0.12f, h * 0.17f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f))
                    }
                }
                else -> { // digital & misc glyphs
                    drawRoundRect(tok.text, topLeft = androidx.compose.ui.geometry.Offset(w * 0.1f, h * 0.3f), size = androidx.compose.ui.geometry.Size(w * 0.5f, h * 0.22f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f))
                    drawRoundRect(tok.text.copy(alpha = 0.35f), topLeft = androidx.compose.ui.geometry.Offset(w * 0.1f, h * 0.6f), size = androidx.compose.ui.geometry.Size(w * 0.3f, h * 0.1f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f))
                    drawCircle(tok.accent, radius = 6.dp.toPx(), center = androidx.compose.ui.geometry.Offset(w * 0.85f, h * 0.3f))
                }
            }
        }
    }
}

/** Home-preview board — the placed widgets laid out on the device-style wallpaper strip. */
@Composable
fun BoardPreview(lang: String) {
    val p = pack
    val placed = Store.current().placed
    if (placed.isEmpty()) {
        DFCard(Modifier.padding(top = 12.dp)) {
            Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                Text(if (lang == "ar") "معاينة الشاشة فارغة" else "Your home preview is empty", style = bodyStyle(15, FontWeight.SemiBold))
                Spacer(Modifier.height(4.dp))
                Text(if (lang == "ar") "أضف ودجات من الكتالوج ثم غيّر حجمها هنا." else "Add widgets from the catalog, then resize them here.", style = bodyStyle(13, color = p.muted))
            }
        }
        return
    }
    Column {
        placed.forEach { pl ->
            val def = WidgetCatalog.byId(pl.designId) ?: return@forEach
            DFCard(Modifier.padding(vertical = 6.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(if (lang == "ar") def.ar else def.en, style = bodyStyle(13, FontWeight.Bold))
                            Text("${pl.w}×${pl.h} · ${WSTYLES.find { it.first == pl.style }?.second?.let { if (lang == "ar") it else null } ?: pl.style}", style = bodyStyle(11, color = p.muted))
                        }
                        WidgetPreviewTile(def, pl.style, lang)
                    }
                }
            }
        }
    }
}

object WidgetPreview {
    data class Pal(val bg: androidx.compose.ui.graphics.Color, val bg2: androidx.compose.ui.graphics.Color?, val text: androidx.compose.ui.graphics.Color, val accent: androidx.compose.ui.graphics.Color)
    fun paletteFor(style: String) = when (style) {
        "oneui" -> Pal(androidx.compose.ui.graphics.Color(0xB8FFFFFF), null, androidx.compose.ui.graphics.Color(0xFF10161F), androidx.compose.ui.graphics.Color(0xFF3E7BFA))
        "material" -> Pal(androidx.compose.ui.graphics.Color(0xFFEDEAF2), null, androidx.compose.ui.graphics.Color(0xFF49454F), androidx.compose.ui.graphics.Color(0xFF6750A4))
        "ios" -> Pal(androidx.compose.ui.graphics.Color(0xDBFFFFFF), null, androidx.compose.ui.graphics.Color.Black, androidx.compose.ui.graphics.Color(0xFF007AFF))
        "editorial" -> Pal(androidx.compose.ui.graphics.Color(0xFFFAF7F0), null, androidx.compose.ui.graphics.Color(0xFF1A1814), androidx.compose.ui.graphics.Color(0xFF6B2D2D))
        "neon" -> Pal(androidx.compose.ui.graphics.Color(0xFF0B0820), null, androidx.compose.ui.graphics.Color(0xFFF0E9FF), androidx.compose.ui.graphics.Color(0xFFFF3FD8))
        "paper" -> Pal(androidx.compose.ui.graphics.Color(0xFFF4ECD8), null, androidx.compose.ui.graphics.Color(0xFF3A2F1C), androidx.compose.ui.graphics.Color(0xFF8A5A2B))
        "clay" -> Pal(androidx.compose.ui.graphics.Color(0xFFECE6DD), null, androidx.compose.ui.graphics.Color(0xFF3A332B), androidx.compose.ui.graphics.Color(0xFFC06C4A))
        "outline" -> Pal(androidx.compose.ui.graphics.Color(0x14FFFFFF), null, androidx.compose.ui.graphics.Color.White, androidx.compose.ui.graphics.Color.White)
        "amoled" -> Pal(androidx.compose.ui.graphics.Color.Black, null, androidx.compose.ui.graphics.Color(0xFFF5F5F5), androidx.compose.ui.graphics.Color(0xFF4FD1C5))
        else -> Pal(androidx.compose.ui.graphics.Color(0xFF1F4E5F), androidx.compose.ui.graphics.Color(0xFFD4A237), androidx.compose.ui.graphics.Color.White, androidx.compose.ui.graphics.Color(0xFFF3DFA2))
    }
}
