package app.dayflow.android.alarm

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import app.dayflow.android.R
import app.dayflow.android.data.Alarm
import app.dayflow.android.data.Store
import app.dayflow.android.notify.Notifications
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Continuous alarm output: real device tone (persisted URI), optional 60-second
 * gentle volume ramp, looping vibration — all kept alive by a foreground service
 * so audio continues regardless of the ring activity's lifecycle.
 */
class AlarmSoundService : Service() {

    companion object {
        const val EXTRA_ALARM_ID = "alarmId"
        const val ACTION_DISMISS = "app.dayflow.android.DISMISS_ALARM"
        const val ACTION_SNOOZE = "app.dayflow.android.SNOOZE_ALARM"

        fun dismissIntent(ctx: Context, alarmId: String) =
            Intent(ctx, AlarmSoundService::class.java).setAction(ACTION_DISMISS).putExtra(EXTRA_ALARM_ID, alarmId)

        fun snoozeIntent(ctx: Context, alarmId: String) =
            Intent(ctx, AlarmSoundService::class.java).setAction(ACTION_SNOOZE).putExtra(EXTRA_ALARM_ID, alarmId)
    }

    private var player: MediaPlayer? = null
    private var rampJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)
    private var alarmId: String = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_DISMISS -> { stopRinging(); stopSelf(); return START_NOT_STICKY }
            ACTION_SNOOZE -> {
                val id = intent.getStringExtra(EXTRA_ALARM_ID) ?: alarmId
                val snoozeMin = Store.current().alarms.find { it.id == id }?.snooze ?: 10
                stopRinging(); stopSelf()
                AlarmScheduler.snooze(this, id, snoozeMin)
                Notifications.snoozed(this, id, snoozeMin)
                return START_NOT_STICKY
            }
        }
        alarmId = intent?.getStringExtra(EXTRA_ALARM_ID) ?: return START_NOT_STICKY
        val alarm = Store.current().alarms.find { it.id == alarmId }
        startForeground(1401, ongoingNotification(alarm))
        startRinging(alarm)
        return START_STICKY
    }

    private fun toneUri(a: Alarm?): Uri {
        a?.soundUri?.let { runCatching { return Uri.parse(it) } }
        return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)!!
    }

    private fun startRinging(alarm: Alarm?) {
        val gentle = alarm?.gentle != false
        player = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build(),
            )
            setDataSource(this@AlarmSoundService, toneUri(alarm))
            isLooping = true
            if (gentle) setVolume(0.02f, 0.02f)
            prepare()
            start()
        }
        if (gentle) {
            rampJob = scope.launch {
                val steps = 60
                repeat(steps) { i ->
                    val v = (i + 1) / steps.toFloat()
                    player?.setVolume(v, v)
                    delay(1000)
                }
            }
        }
        if (alarm?.vibrate != false) {
            val vib: Vibrator = if (Build.VERSION.SDK_INT >= 31)
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            else @Suppress("DEPRECATION") ContextCompat.getSystemService(this, Vibrator::class.java)!!
            if (Build.VERSION.SDK_INT >= 26) {
                vib.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400), 0))
            } else @Suppress("DEPRECATION") vib.vibrate(longArrayOf(0, 400, 200, 400), 0)
        }
    }

    private fun stopRinging() {
        rampJob?.cancel()
        player?.runCatching { stop() }
        player?.release(); player = null
        val vib: Vibrator = if (Build.VERSION.SDK_INT >= 31)
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        else @Suppress("DEPRECATION") getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        vib.cancel()
        getSystemService(NotificationManager::class.java).cancel(Notifications.ID_ALARM)
    }

    private fun ongoingNotification(alarm: Alarm?): Notification {
        val dismiss = PendingIntent.getService(this, 1, dismissIntent(this, alarmId), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val snooze = PendingIntent.getService(this, 2, snoozeIntent(this, alarmId), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, Notifications.CH_ALARMS)
            .setSmallIcon(R.drawable.ic_launcher_fg)
            .setContentTitle(alarm?.label?.ifBlank { getString(R.string.app_name) } ?: getString(R.string.app_name))
            .setContentText("المنبه يرن")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .addAction(0, getString(R.string.alarm_snooze), snooze)
            .addAction(0, getString(R.string.alarm_dismiss), dismiss)
            .build()
    }

    override fun onDestroy() {
        stopRinging()
        super.onDestroy()
    }
}
