package app.dayflow.android.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.util.TypedValue
import android.widget.RemoteViews
import app.dayflow.android.MainActivity
import app.dayflow.android.R
import app.dayflow.android.data.Store
import app.dayflow.android.data.WidgetCfg

/** The 137-design catalog, ported with archetypes so native layouts render faithfully. */
object WidgetCatalog {

    data class Def(val id: String, val en: String, val ar: String, val cat: String, val arche: String, val interactive: Boolean, val forms: List<String>)

    val cats = listOf(
        "clock" to ("Clock" to "الساعة"), "alarms" to ("Alarms" to "المنبهات"), "calendar" to ("Calendar" to "التقويم"),
        "occasions" to ("Occasions" to "المناسبات"), "plan" to ("Plan & today" to "الخطة واليوم"), "tasks" to ("Tasks & notes" to "المهام والملاحظات"),
        "habits" to ("Habits & health" to "العادات والصحة"), "focus" to ("Focus & study" to "التركيز والدراسة"), "review" to ("Review & stats" to "المراجعة والإحصاءات"),
        "media" to ("Media Hub" to "مركز الوسائط"), "utility" to ("Utility" to "أدوات"), "companion" to ("Companion" to "الرفيق"),
    )

    private fun slug(s: String) = s.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-')
    private fun row(cat: String, en: String, ar: String, arche: String, interactive: Boolean, forms: List<String> = listOf("1x1", "2x1", "2x2", "4x1", "4x2", "4x4")) =
        Def("$cat-${slug(en)}", en, ar, cat, arche, interactive, forms)

    private val MatrixForms = listOf("2x2", "4x2", "4x4")
    private val NoteForms = listOf("2x1", "2x2", "4x2", "4x4")

    private fun D(cat: String, vararg rows: Array<out Any?>): List<Def> = rows.map { r ->
        val arche = r[2] as String
        row(cat, r[0] as String, r[1] as String, arche, r[3] == true,
            if (arche == "matrix" || arche == "kanban" || arche == "month") MatrixForms else if (arche == "note") NoteForms else listOf("1x1", "2x1", "2x2", "4x1", "4x2", "4x4"))
    }

    val ALL: List<Def> = (
        D("clock", arrayOf("Minimal digital", "رقمية بسيطة", "digital"), arrayOf("Bold block", "كتلة عريضة", "digital"), arrayOf("Split flap", "لوحة متقلبة", "flip"), arrayOf("Flip clock", "ساعة قلّابة", "flip"), arrayOf("Dot-matrix", "مصفوفة نقطية", "digital"), arrayOf("Stacked words", "كلمات متراصة", "digital"), arrayOf("Analog classic", "عقارب كلاسيكية", "analog"), arrayOf("Analog skeleton", "عقارب هيكلية", "analog"), arrayOf("Analog luxury", "عقارب فاخرة", "analog"), arrayOf("Analog minimal", "عقارب بسيطة", "analog"), arrayOf("Sun-arc clock", "ساعة قوس الشمس", "sunarc"), arrayOf("Orbit clock", "ساعة المدار", "analog"), arrayOf("World clock", "ساعة عالمية", "world"), arrayOf("Dual-time", "توقيت مزدوج", "world"), arrayOf("Clock + day summary", "ساعة + ملخص اليوم", "digital"), arrayOf("Bedside clock", "ساعة السرير", "digital")) +
        D("alarms", arrayOf("Next alarm pill", "كبسولة المنبه التالي", "countdown", true), arrayOf("Alarm ring-dial", "قرص المنبه", "dial", true), arrayOf("Alarm list + toggles", "قائمة المنبهات", "checklist", true), arrayOf("Alarm timeline strip", "شريط المنبهات الزمني", "timeline"), arrayOf("Alarm week grid", "شبكة أسبوع المنبهات", "week"), arrayOf("Countdown to alarm", "عد تنازلي للمنبه", "countdown"), arrayOf("Sleep-alarm combo", "النوم والمنبه", "dial", true), arrayOf("Snooze tracker", "متتبع الغفوة", "bars")) +
        D("calendar", arrayOf("Month compact", "شهر مدمج", "month"), arrayOf("Month with artwork", "شهر بالزخارف", "month"), arrayOf("Month heatmap", "خريطة حرارية شهرية", "heatmap"), arrayOf("Week strip", "شريط الأسبوع", "week"), arrayOf("Week columns", "أعمدة الأسبوع", "week"), arrayOf("Agenda list", "قائمة الأجندة", "list"), arrayOf("Agenda with artwork", "أجندة بالزخارف", "list"), arrayOf("Year dots", "نقاط السنة", "mosaic"), arrayOf("Hijri month", "الشهر الهجري", "month"), arrayOf("Coptic month", "الشهر القبطي", "month"), arrayOf("Tri-calendar date card", "بطاقة التقاويم الثلاثة", "tri"), arrayOf("Day ring (24h)", "حلقة اليوم", "ring"), arrayOf("Schedule river", "نهر الجدول", "timeline"), arrayOf("Date flip", "تاريخ قلاب", "flip")) +
        D("occasions", arrayOf("Occasion hero", "بطل المناسبة", "hero"), arrayOf("Occasion countdown ring", "حلقة العد للمناسبة", "ring"), arrayOf("Upcoming carousel", "المناسبات القادمة", "list"), arrayOf("Ramadan imsakiya", "إمساكية رمضان", "list"), arrayOf("Iftar countdown", "العد للإفطار", "countdown"), arrayOf("Eid greeting card", "بطاقة تهنئة العيد", "hero"), arrayOf("Season greeting", "تحية الموسم", "hero"), arrayOf("Nile & Egyptian seasons", "النيل والمواسم المصرية", "hero"), arrayOf("National-day card", "بطاقة اليوم الوطني", "hero"), arrayOf("Friday card", "بطاقة الجمعة", "hero"), arrayOf("Hijri date card", "بطاقة التاريخ الهجري", "tri")) +
        D("plan", arrayOf("Current activity", "النشاط الحالي", "timeline"), arrayOf("Now · Next · Later", "الآن · التالي · لاحقًا", "list"), arrayOf("Timeline vertical", "خط زمني رأسي", "timeline"), arrayOf("Timeline horizontal", "خط زمني أفقي", "timeline"), arrayOf("Free-time gauge", "مقياس الوقت الحر", "dial"), arrayOf("Day progress ring", "حلقة تقدم اليوم", "ring"), arrayOf("Daily brief", "موجز اليوم", "list"), arrayOf("Top priorities", "أهم الأولويات", "checklist", true), arrayOf("Focus window", "نافذة التركيز", "timeline"), arrayOf("Plan board", "لوحة الخطة", "kanban"), arrayOf("Yesterday · Today · Tomorrow", "أمس · اليوم · غدًا", "week"), arrayOf("Schedule health", "صحة الجدول", "ring"), arrayOf("Routine checklist", "قائمة الروتين", "checklist", true)) +
        D("tasks", arrayOf("Checklist", "قائمة تحقق", "checklist", true), arrayOf("Task rings", "حلقات المهام", "ring"), arrayOf("Eisenhower matrix", "مصفوفة أيزنهاور", "matrix", true), arrayOf("Kanban strip", "شريط كانبان", "kanban"), arrayOf("Quick-add bar", "شريط إضافة سريعة", "quick", true), arrayOf("Pinned note paper", "ورقة ملاحظة مثبتة", "note"), arrayOf("Sticky-note stack", "كومة ملاحظات لاصقة", "note"), arrayOf("Notes grid", "شبكة الملاحظات", "mosaic"), arrayOf("Handwritten note", "ملاحظة بخط اليد", "note"), arrayOf("Checklist cards", "بطاقات تحقق", "checklist", true), arrayOf("Overdue list", "المتأخرات", "list"), arrayOf("Subtasks tree", "شجرة المهام الفرعية", "list", true), arrayOf("Shopping list", "قائمة التسوق", "checklist", true), arrayOf("Voice-note button", "زر ملاحظة صوتية", "quick", true), arrayOf("Journal prompt", "سؤال اليوميات", "note")) +
        D("habits", arrayOf("Habit grid", "شبكة العادات", "heatmap", true), arrayOf("Habit heatmap", "خريطة العادات", "heatmap"), arrayOf("Streak card", "بطاقة السلسلة", "counter"), arrayOf("Water drop", "قطرة ماء", "drop", true), arrayOf("Water bottle", "زجاجة ماء", "drop", true), arrayOf("Water cups", "أكواب الماء", "bars", true), arrayOf("Sleep dial", "قرص النوم", "dial"), arrayOf("Bedtime countdown", "العد لوقت النوم", "countdown"), arrayOf("Workout today", "تمرين اليوم", "ring", true), arrayOf("Workout week", "تمارين الأسبوع", "bars"), arrayOf("Medication schedule", "جدول الأدوية", "checklist", true), arrayOf("Mood strip", "شريط المزاج", "mosaic", true)) +
        D("focus", arrayOf("Focus timer ring", "حلقة مؤقت التركيز", "ring", true), arrayOf("Pomodoro cycle", "دورة بومودورو", "dial", true), arrayOf("Study planner", "مخطط الدراسة", "list"), arrayOf("Exam countdown stack", "عد الامتحانات", "countdown"), arrayOf("Subject progress", "تقدم المواد", "bars"), arrayOf("Deep-work block", "فترة عمل عميق", "timeline"), arrayOf("Break reminder", "تذكير الاستراحة", "countdown"), arrayOf("Study streak", "سلسلة الدراسة", "counter")) +
        D("review", arrayOf("Daily score ring", "حلقة نتيجة اليوم", "ring"), arrayOf("Weekly radar", "رادار الأسبوع", "radar"), arrayOf("Yearly mosaic", "فسيفساء السنة", "mosaic"), arrayOf("Strengths card", "بطاقة نقاط القوة", "bars"), arrayOf("What you did", "ماذا أنجزت", "list"), arrayOf("Productivity sparkline", "خط الإنتاجية", "spark"), arrayOf("Time-budget donut", "دونات ميزانية الوقت", "donut"), arrayOf("Consistency calendar", "تقويم الاستمرارية", "heatmap"), arrayOf("Trend arrow", "سهم الاتجاه", "spark"), arrayOf("Milestone card", "بطاقة الإنجاز", "counter"), arrayOf("Personal records", "الأرقام الشخصية", "bars")) +
        D("media", arrayOf("Active downloads", "التنزيلات النشطة", "download", true), arrayOf("Paste-link tile", "بلاطة لصق الرابط", "quick", true), arrayOf("Download history", "سجل التنزيلات", "list"), arrayOf("Recent audio", "أحدث الصوتيات", "list"), arrayOf("Recent video", "أحدث الفيديو", "mosaic"), arrayOf("Storage usage", "استخدام التخزين", "donut")) +
        D("utility", arrayOf("Battery ring", "حلقة البطارية", "battery"), arrayOf("Battery detail", "تفاصيل البطارية", "battery"), arrayOf("Quick actions grid", "شبكة الإجراءات السريعة", "quick", true), arrayOf("Stopwatch", "ساعة إيقاف", "digital", true), arrayOf("Timer", "مؤقت", "ring", true), arrayOf("Unit tile", "بلاطة الوحدات", "quick"), arrayOf("Tasbih counter", "عداد التسبيح", "counter", true), arrayOf("Khatma tracker", "متتبع الختمة", "bars", true), arrayOf("Prayer schedule", "جدول الصلوات", "prayer"), arrayOf("Qibla compass", "بوصلة القبلة", "compass"), arrayOf("Prayer times strip", "شريط مواقيت الصلاة", "prayer"), arrayOf("Next prayer", "الصلاة القادمة", "nextprayer"), arrayOf("Prayer times (ornate)", "المواقيت بالزخرفة", "prayer"), arrayOf("Next prayer ring", "حلقة الصلاة القادمة", "nextprayer"), arrayOf("Fajr & Maghrib card", "بطاقة الفجر والمغرب", "nextprayer"), arrayOf("Mosque board", "لوحة المسجد", "prayer"), arrayOf("Adhkar & Tasbih", "الأذكار والتسبيح", "counter", true), arrayOf("Khatma + prayer", "الختمة والصلاة", "bars"), arrayOf("Countdown", "عد تنازلي", "countdown"), arrayOf("Anniversary card", "بطاقة الذكرى", "hero"), arrayOf("Date calculator", "حاسبة التاريخ", "tri"), arrayOf("QR quick scan", "مسح QR سريع", "quick", true)) +
        D("companion", arrayOf("Companion portrait", "صورة الرفيق", "portrait"), arrayOf("Companion quick-actions", "إجراءات الرفيق", "quick", true), arrayOf("Companion mood", "مزاج الرفيق", "portrait"), arrayOf("Companion tip", "نصيحة الرفيق", "portrait"))
        )

    fun byId(id: String): Def? = ALL.find { it.id == id }
}

/** All five gateway providers share one renderer base. */
abstract class GatewayWidget : AppWidgetProvider() {

    abstract val providerClass: Class<*>

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        DayflowHolder.ctx = context
        for (id in ids) updateOne(context, mgr, id)
    }

    override fun onAppWidgetOptionsChanged(context: Context, mgr: AppWidgetManager, id: Int, newOptions: Bundle?) {
        updateOne(context, mgr, id)
    }

    override fun onDeleted(context: Context, ids: IntArray) {
        for (id in ids) Store.removeWidgetCfg(id)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        DayflowHolder.ctx = context
        when (intent.action) {
            "app.dayflow.android.W_TASBIH" -> {
                Store.mutate { it.copy(tasbih = it.tasbih + 1) }
                pushAll(context)
            }
            "app.dayflow.android.W_TASK" -> {
                intent.getStringExtra("taskId")?.let { Store.toggleTask(it) }
                pushAll(context)
            }
        }
    }

    companion object {
        fun updateOne(context: Context, mgr: AppWidgetManager, id: Int) {
            DayflowHolder.ctx = context
            val views = RemoteViews(context.packageName, R.layout.widget_host)
            val cfg = Store.current().widgetConfigs[id.toString()]
            val opts = mgr.getAppWidgetOptions(id)
            val wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 110)
            val hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110)
            val dm = context.resources.displayMetrics
            val wPx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, wDp.toFloat(), dm).toInt()
            val hPx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, hDp.toFloat(), dm).toInt()

            if (cfg == null) {
                // Not yet personalized: paint an inviting placeholder that opens the catalog.
                val bmp = WidgetPainter.render(context, "clock-minimal-digital", "oneui", wPx, hPx)
                views.setImageViewBitmap(R.id.widget_canvas, bmp)
                val open = PendingIntent.getActivity(
                    context, id, Intent(context, MainActivity::class.java).putExtra("tab", "me:widgets").putExtra("widgetId", id),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                )
                views.setOnClickPendingIntent(R.id.widget_canvas, open)
            } else {
                val bmp: Bitmap = WidgetPainter.render(context, cfg.designId, cfg.style, wPx, hPx)
                views.setImageViewBitmap(R.id.widget_canvas, bmp)
                val design = WidgetCatalog.byId(cfg.designId)
                when (design?.arche) {
                    "counter" -> views.setOnClickPendingIntent(R.id.widget_canvas, broadcast(context, id, "app.dayflow.android.W_TASBIH"))
                    else -> {
                        val target = Intent(context, if (cfg.tapOpens || design?.interactive != true) MainActivity::class.java else MainActivity::class.java)
                        val pi = PendingIntent.getActivity(context, id, target, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                        views.setOnClickPendingIntent(R.id.widget_canvas, pi)
                    }
                }
            }
            mgr.updateAppWidget(id, views)
        }

        private fun broadcast(context: Context, id: Int, action: String) = PendingIntent.getBroadcast(
            context, id * 31 + 7, Intent(context, GatewayWidgetWide::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        fun pushAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            for (cls in listOf(GatewayWidgetSmall::class.java, GatewayWidgetWide::class.java, GatewayWidgetMedium::class.java, GatewayWidgetLarge::class.java, GatewayWidgetXL::class.java)) {
                val ids = mgr.getAppWidgetIds(ComponentName(context, cls))
                for (id in ids) updateOne(context, mgr, id)
            }
        }
    }
}

class GatewayWidgetSmall : GatewayWidget() { override val providerClass = GatewayWidgetSmall::class.java }
class GatewayWidgetWide : GatewayWidget() { override val providerClass = GatewayWidgetWide::class.java }
class GatewayWidgetMedium : GatewayWidget() { override val providerClass = GatewayWidgetMedium::class.java }
class GatewayWidgetLarge : GatewayWidget() { override val providerClass = GatewayWidgetLarge::class.java }
class GatewayWidgetXL : GatewayWidget() { override val providerClass = GatewayWidgetXL::class.java }

/** Pushes the latest render to every placed DAYFLOW widget. */
object WidgetSync {
    fun pushAll(context: Context) = GatewayWidget.pushAll(context)
}
