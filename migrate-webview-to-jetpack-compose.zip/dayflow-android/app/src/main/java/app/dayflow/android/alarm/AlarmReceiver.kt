package app.dayflow.android.alarm

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import app.dayflow.android.data.Store
import app.dayflow.android.notify.Notifications

/**
 * Alarm clock hit. Starts the continuous sound service and posts a
 * full-screen-intent notification; the ring activity is also launched
 * directly when the device policy allows it.
 */
class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        val alarmId = intent.data?.lastPathSegment ?: intent.getStringExtra("id") ?: return

        if (intent.action == AlarmScheduler.ACTION_REMINDER) {
            Notifications.reminderHit(ctx)
            return
        }

        val alarm = Store.current().alarms.find { it.id == alarmId } ?: return

        // Repeating alarms re-arm for the next occurrence; one-time alarms consume themselves.
        if (alarm.days.isNotEmpty()) {
            AlarmScheduler.schedule(ctx, alarm) // schedules the next occurrence
        } else {
            Store.updateAlarm(alarmId) { it.copy(enabled = false) }
        }

        // Start continuous ringing (audio + vibration) as a foreground service.
        val svc = Intent(ctx, AlarmSoundService::class.java)
            .putExtra(AlarmSoundService.EXTRA_ALARM_ID, alarmId)
        ContextCompat.startForegroundService(ctx, svc)

        // High-priority alarm notification with full-screen intent (rings over the lock screen).
        Notifications.alarmFire(ctx, alarm)

        // Directly present the ring screen when the device is locked or the app is backgrounded.
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val launch = Intent(ctx, AlarmActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra(AlarmSoundService.EXTRA_ALARM_ID, alarmId)
        if (km.isKeyguardLocked || Build.VERSION.SDK_INT < 27 || true) ctx.startActivity(launch)
    }
}

/** Restores alarms & reminders after reboot / time change / package replacement. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_LOCALE_CHANGED,
            "android.intent.action.QUICKBOOT_POWERON",
            -> AlarmScheduler.restoreAll(ctx)
        }
    }
}
