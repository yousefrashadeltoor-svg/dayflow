# DAYFLOW — Native Android (Kotlin + Jetpack Compose)

نفس وجهة التطبيق الأصلي ١:١، والمنطق أصلي بالكامل (no WebView).

- فرع `app/` يحتوي التطبيق الكامل: UI بـ Compose، منبه بـ AlarmManager، تعويم الروبوت عبر TYPE_APPLICATION_OVERLAY، ودجات Home Screen حقيقية عبر AppWidgetProvider + نشاط إعداد يفتح الكتالوج، محلل ومحمّل ملفات بـ OkHttp (Range متعدد المسارات + HLS + Open Graph)، إشعارات بخمس قنوات، مواقيت صلاة فلكية صحيحة بقواعد المنطقة الزمنية، وزخارف مواسم Canvas واقعية.
- README_FIXES.md فيه قائمة كل المشاكل والمحاكاة وإصلاحاتها.

البناء: gradle wrapper --gradle-version 8.9 && ./gradlew assembleDebug
