package app.dayflow.android

import app.dayflow.android.alarm.AlarmEntry
import app.dayflow.android.alarm.nextOccurrence
import app.dayflow.android.alarm.formatTime12
import app.dayflow.android.download.StreamExtractor
import app.dayflow.android.download.parsePageMetadata
import app.dayflow.android.prayer.calculatePrayers
import app.dayflow.android.prayer.nextPrayer
import app.dayflow.android.prayer.prayerCities
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

class AlarmAndPrayerTest {
    @Test fun oneShotWithoutDateMovesToTomorrowWhenTimeHasPassed() {
        val now = ZonedDateTime.parse("2026-11-15T09:30:00+02:00[Africa/Cairo]")
        val result = nextOccurrence(AlarmEntry(1, 7, 0, emptySet()), now)!!
        assertEquals(LocalDate.of(2026, 11, 16), result.toLocalDate())
    }

    @Test fun repeatUsesOriginalSundayIndexAndSkipsPastOccurrence() {
        val now = ZonedDateTime.parse("2026-11-15T09:30:00+02:00[Africa/Cairo]")
        val result = nextOccurrence(AlarmEntry(1, 7, 0, setOf(0)), now)!!
        assertEquals(LocalDate.of(2026, 11, 22), result.toLocalDate())
    }

    @Test fun expiredSpecificDateIsNotSilentlyMoved() {
        val now = ZonedDateTime.parse("2026-11-15T09:30:00+02:00[Africa/Cairo]")
        assertNull(nextOccurrence(AlarmEntry(1, 7, 0, emptySet(), "2026-11-15"), now))
    }

    @Test fun daylightSavingGapUsesValidLocalTime() {
        val now = ZonedDateTime.of(2026, 3, 8, 0, 0, 0, 0, ZoneId.of("America/New_York"))
        val result = nextOccurrence(AlarmEntry(1, 2, 30, setOf(0)), now)!!
        assertEquals(3, result.hour)
        assertEquals(30, result.minute)
    }

    @Test fun cairoUsesZoneRulesAndTomorrowPrayerAfterIsha() {
        val cairo = prayerCities.first { it.id == "cairo" }
        val winter = calculatePrayers(cairo, LocalDate.of(2026, 1, 10))
        val summer = calculatePrayers(cairo, LocalDate.of(2026, 7, 10))
        assertEquals(2 * 3600, winter.first().at.offset.totalSeconds)
        assertEquals(3 * 3600, summer.first().at.offset.totalSeconds)
        val afterIsha = winter.last().at.plusMinutes(1).toInstant()
        assertEquals(LocalDate.of(2026, 1, 11), nextPrayer(cairo, afterIsha)!!.at.toLocalDate())
    }

    @Test fun cairoSampleTimesAreCloseToEgyptianMethodReference() {
        val cairo = prayerCities.first { it.id == "cairo" }
        val winter = calculatePrayers(cairo, LocalDate.of(2026, 1, 10))
        val summer = calculatePrayers(cairo, LocalDate.of(2026, 7, 10))
        fun minutes(hour: Int, minute: Int) = hour * 60 + minute
        assertTrue(kotlin.math.abs(minutes(winter[0].at.hour, winter[0].at.minute) - minutes(5, 20)) <= 2)
        assertTrue(kotlin.math.abs(minutes(winter[4].at.hour, winter[4].at.minute) - minutes(17, 13)) <= 2)
        assertTrue(kotlin.math.abs(minutes(summer[0].at.hour, summer[0].at.minute) - minutes(4, 17)) <= 2)
        assertTrue(kotlin.math.abs(minutes(summer[4].at.hour, summer[4].at.minute) - minutes(19, 59)) <= 2)
    }

    @Test fun formatterAlwaysUsesTwelveHourClock() {
        assertTrue(formatTime12(0, 5).contains("١٢"))
        assertTrue(formatTime12(13, 5).contains("١"))
        assertFalse(formatTime12(13, 5).contains("١٣"))
    }

    @Test fun extractorOnlySelectsKnownSupportedHosts() {
        assertTrue(StreamExtractor.supports("https://www.youtube.com/watch?v=example"))
        assertTrue(StreamExtractor.supports("https://soundcloud.com/example"))
        assertFalse(StreamExtractor.supports("https://youtube.com.example.org/watch"))
    }

    @Test fun openGraphUsesRealValuesAndResolvesRelativeImages() {
        val page = parsePageMetadata("""<html><head><title>Fallback</title>
            <meta property="og:title" content="Actual title"><meta name="description" content="Description">
            <meta name="author" content="Author"><meta property="og:image" content="/cover.jpg"></head></html>""",
            "https://example.com/article")
        assertEquals("Actual title", page.title)
        assertEquals("Description", page.description)
        assertEquals("Author", page.author)
        assertEquals("https://example.com/cover.jpg", page.image)
    }
}