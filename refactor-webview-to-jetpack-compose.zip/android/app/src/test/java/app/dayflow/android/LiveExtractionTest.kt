package app.dayflow.android

import app.dayflow.android.download.StreamExtractor
import okhttp3.OkHttpClient
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.util.concurrent.TimeUnit

class LiveExtractionTest {
    @Test fun publicYoutubeLink() {
        assumeTrue(System.getenv("DAYFLOW_LIVE_TESTS") == "1")
        val client = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(25, TimeUnit.SECONDS).build()
        val result = StreamExtractor.analyze("https://www.youtube.com/watch?v=jNQXAC9IVRw", client)
        assertTrue(result.title.isNotBlank())
        assertTrue(result.formats.isNotEmpty())
    }
}