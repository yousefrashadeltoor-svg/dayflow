package app.dayflow.android.alarm

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import app.dayflow.android.MainActivity
import app.dayflow.android.R

object Notifications {
    const val ALARMS = "dayflow_alarms_v2"
    const val REMINDERS = "dayflow_reminders_v2"
    const val COMPANION = "dayflow_companion_v2"
    const val RINGING_ID = 4001

    fun createChannels(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(ALARMS, "المنبهات", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "المنبهات التي تضبطها"; setSound(null, null); enableVibration(false)
            lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
        })
        manager.createNotificationChannel(NotificationChannel(REMINDERS, "التذكيرات", NotificationManager.IMPORTANCE_HIGH))
        manager.createNotificationChannel(NotificationChannel(COMPANION, "الرفيق العائم", NotificationManager.IMPORTANCE_LOW))
    }

    fun action(context: Context, id: Int, action: String): PendingIntent {
        val intent = Intent(context, AlarmActionReceiver::class.java).apply {
            this.action = action
            data = Uri.parse("dayflow://action/$id/$action")
            putExtra("id", id)
        }
        return PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun showReminder(context: Context, alarm: AlarmEntry) {
        createChannels(context)
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val open = PendingIntent.getActivity(context, alarm.id, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, REMINDERS)
            .setSmallIcon(R.drawable.ic_dayflow).setContentTitle(alarm.label.ifBlank { "تذكير" })
            .setContentText(formatTime12(alarm.hour, alarm.minute)).setContentIntent(open).setAutoCancel(true)
            .addAction(0, "غفوة", action(context, alarm.id, "app.dayflow.android.SNOOZE"))
            .addAction(0, "تم", action(context, alarm.id, "app.dayflow.android.DISMISS"))
            .build()
        NotificationManagerCompat.from(context).notify(10_000 + alarm.id, notification)
    }
}