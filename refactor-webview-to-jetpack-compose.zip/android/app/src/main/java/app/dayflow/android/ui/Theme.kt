package app.dayflow.android.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

val Accent = Color(0xff2f6f5e)
val Ink = Color(0xff1d1c1a)
val Muted = Color(0xff777970)
val Paper = Color(0xfff7f5f0)
val Soft = Color(0xffe6eee9)
val Line = Color(0xffe6e5df)

@Composable
fun DayflowTheme(content: @Composable () -> Unit) {
    val scheme = lightColorScheme(primary = Accent, onPrimary = Color.White, secondary = Color(0xffc9a24a),
        background = Paper, surface = Color.White, onSurface = Ink, outline = Line)
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}