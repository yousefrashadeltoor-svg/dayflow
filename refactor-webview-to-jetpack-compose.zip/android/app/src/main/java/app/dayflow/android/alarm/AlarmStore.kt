package app.dayflow.android.alarm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.format.DecimalStyle
import java.util.Locale

data class AlarmEntry(
    val id: Int,
    val hour: Int = 7,
    val minute: Int = 0,
    val days: Set<Int> = setOf(0, 1, 2, 3, 4),
    val date: String? = null,
    val label: String = "",
    val enabled: Boolean = true,
    val soundUri: String = "",
    val soundTitle: String = "منبه الجهاز الافتراضي",
    val vibrate: Boolean = true,
    val gentle: Boolean = false,
    val snoozeMinutes: Int = 10,
    val reminder: Boolean = false
)

/** Weekdays use the original application's 0=Sunday through 6=Saturday convention. */
fun nextOccurrence(alarm: AlarmEntry, now: ZonedDateTime = ZonedDateTime.now()): ZonedDateTime? {
    if (!alarm.enabled || alarm.hour !in 0..23 || alarm.minute !in 0..59) return null
    val time = LocalTime.of(alarm.hour, alarm.minute)
    val zone = now.zone
    if (alarm.days.isEmpty()) {
        val chosen = alarm.date?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        if (alarm.date != null && chosen == null) return null
        var candidate = (chosen ?: now.toLocalDate()).atTime(time).atZone(zone)
        if (chosen == null && !candidate.isAfter(now)) candidate = candidate.plusDays(1)
        return candidate.takeIf { it.isAfter(now) }
    }
    for (offset in 0..7) {
        val date = now.toLocalDate().plusDays(offset.toLong())
        if (date.dayOfWeek.value % 7 !in alarm.days) continue
        val candidate = date.atTime(time).atZone(zone)
        if (candidate.isAfter(now)) return candidate
    }
    return null
}

fun formatTime12(hour: Int, minute: Int): String {
    val locale = Locale("ar", "EG")
    return LocalTime.of(hour, minute).format(
        DateTimeFormatter.ofPattern("h:mm a", locale).withDecimalStyle(DecimalStyle.of(locale))
    )
}

class AlarmStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("dayflow_compose", Context.MODE_PRIVATE)

    @Synchronized fun all(): List<AlarmEntry> = prefs.all.keys.filter { it.startsWith("alarm_") }
        .mapNotNull { key -> runCatching { decode(JSONObject(prefs.getString(key, "{}").orEmpty())) }.getOrNull() }
        .sortedWith(compareBy(AlarmEntry::hour, AlarmEntry::minute, AlarmEntry::id))

    fun get(id: Int): AlarmEntry? = prefs.getString("alarm_$id", null)?.let {
        runCatching { decode(JSONObject(it)) }.getOrNull()
    }

    @Synchronized fun newId(): Int {
        val id = prefs.getInt("next_alarm_id", 1)
        prefs.edit().putInt("next_alarm_id", id + 1).commit()
        return id
    }

    fun save(alarm: AlarmEntry) {
        prefs.edit().putString("alarm_${alarm.id}", encode(alarm).toString()).commit()
    }

    fun remove(id: Int) { prefs.edit().remove("alarm_$id").commit() }

    /** Import the native bridge's persisted alarms without touching WebView storage. */
    @Synchronized fun importLegacyAlarms(): Boolean {
        if (prefs.getBoolean("legacy_imported", false)) return false
        val old = context.getSharedPreferences("dayflow_native", Context.MODE_PRIVATE)
        var imported = false
        old.all.filterKeys { it.startsWith("alarm_") }.values.forEach { value ->
            val obj = runCatching { JSONObject(value as String) }.getOrNull() ?: return@forEach
            val parts = obj.optString("time", "07:00").split(':')
            val hour = parts.getOrNull(0)?.toIntOrNull()?.coerceIn(0, 23) ?: 7
            val minute = parts.getOrNull(1)?.toIntOrNull()?.coerceIn(0, 59) ?: 0
            val dayArray = obj.optJSONArray("days") ?: JSONArray()
            val days = (0 until dayArray.length()).map { dayArray.optInt(it, -1) }.filter { it in 0..6 }.toSet()
            save(AlarmEntry(id = newId(), hour = hour, minute = minute, days = days,
                date = obj.optString("date").takeIf { it.isNotBlank() }, label = obj.optString("label"),
                enabled = obj.optBoolean("enabled", true), soundUri = obj.optString("soundUri"),
                vibrate = obj.optBoolean("vibrate", true), snoozeMinutes = obj.optInt("snooze", 10)))
            imported = true
        }
        prefs.edit().putBoolean("legacy_imported", true).commit()
        return imported
    }

    private fun encode(a: AlarmEntry) = JSONObject().apply {
        put("id", a.id); put("hour", a.hour); put("minute", a.minute); put("days", JSONArray(a.days.sorted()))
        put("date", a.date ?: ""); put("label", a.label); put("enabled", a.enabled)
        put("soundUri", a.soundUri); put("soundTitle", a.soundTitle); put("vibrate", a.vibrate)
        put("gentle", a.gentle); put("snoozeMinutes", a.snoozeMinutes); put("reminder", a.reminder)
    }

    private fun decode(o: JSONObject): AlarmEntry {
        val a = o.optJSONArray("days") ?: JSONArray()
        return AlarmEntry(o.getInt("id"), o.optInt("hour", 7), o.optInt("minute", 0),
            (0 until a.length()).map { a.optInt(it, -1) }.filter { it in 0..6 }.toSet(),
            o.optString("date").takeIf { it.isNotBlank() }, o.optString("label"), o.optBoolean("enabled", true),
            o.optString("soundUri"), o.optString("soundTitle", "منبه الجهاز الافتراضي"),
            o.optBoolean("vibrate", true), o.optBoolean("gentle", false), o.optInt("snoozeMinutes", 10),
            o.optBoolean("reminder", false))
    }
}