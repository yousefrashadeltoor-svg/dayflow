package app.dayflow.android.ui

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import app.dayflow.android.download.LinkMetadata
import app.dayflow.android.download.LinkRepository
import app.dayflow.android.download.NativeDownload
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun DownloadScreen(sharedUrl: String) {
    val context = LocalContext.current
    val repo = remember { LinkRepository(context) }
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf(Regex("https://\\S+").find(sharedUrl)?.value ?: sharedUrl) }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<LinkMetadata?>(null) }
    var error by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<NativeDownload>>(emptyList()) }
    LaunchedEffect(Unit) { while (true) { items = withContext(Dispatchers.IO) { repo.downloads() }; delay(2000) } }
    fun analyze() {
        if (busy) return
        busy = true; error = ""; result = null
        scope.launch {
            try { result = repo.analyze(input) }
            catch (e: Exception) { error = e.message ?: "تعذر تحليل الرابط. تحقق من اتصالك." }
            finally { busy = false }
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 90.dp)) {
        ScreenTitle("التحميل", "الصق أو شارك أي رابط")
        DayCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("حلّل رابطاً", fontWeight = FontWeight.Bold)
                Text("اعرف محتوى الرابط قبل التحميل", fontSize = 12.sp, color = Muted)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(input, { input = it }, Modifier.fillMaxWidth(), placeholder = { Text("https://...", fontSize = 13.sp) },
                    singleLine = true, shape = RoundedCornerShape(14.dp), leadingIcon = { Icon(Icons.Outlined.Link, null, tint = Accent) })
                Spacer(Modifier.height(10.dp))
                Button(onClick = { analyze() }, enabled = !busy && input.isNotBlank(), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                    else { Icon(Icons.Outlined.Search, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("تحليل الرابط") }
                }
                if (error.isNotBlank()) Text(error, Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }
        }
        result?.let { info ->
            Spacer(Modifier.height(12.dp))
            DayCard(Modifier.fillMaxWidth()) {
                if (info.image.isNotBlank()) AsyncImage(model = info.image, contentDescription = "غلاف الرابط", modifier = Modifier.fillMaxWidth().height(160.dp), contentScale = ContentScale.Crop)
                Column(Modifier.padding(16.dp)) {
                    Text(info.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    if (info.author.isNotBlank()) Text(info.author, fontSize = 12.sp, color = Accent)
                    if (info.description.isNotBlank()) Text(info.description, Modifier.padding(top = 6.dp), fontSize = 12.sp, color = Muted, lineHeight = 18.sp)
                    Text(info.url, Modifier.padding(top = 8.dp), fontSize = 11.sp, color = Muted, maxLines = 2)
                    if (info.mime.isNotBlank()) Text("النوع: ${info.mime}", Modifier.padding(top = 5.dp), fontSize = 11.sp, color = Muted)
                    info.size?.let { Text("الحجم: ${formatBytes(it)}", fontSize = 11.sp, color = Muted) }
                    info.durationSeconds?.let { Text("المدة: ${it / 60}:${(it % 60).toString().padStart(2, '0')}", fontSize = 11.sp, color = Muted) }
                    Spacer(Modifier.height(10.dp))
                    if (info.directFile) Button(onClick = {
                        scope.launch {
                            runCatching { withContext(Dispatchers.IO) { repo.start(info); repo.downloads() } }
                                .onSuccess { items = it; error = "" }.onFailure { error = it.message ?: "تعذر بدء التحميل." }
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Outlined.Download, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("تحميل الملف الأصلي") }
                    else if (info.formats.isNotEmpty()) {
                        Text("الصيغ المتاحة", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        info.formats.forEach { format ->
                            OutlinedButton(onClick = {
                                scope.launch {
                                    runCatching { withContext(Dispatchers.IO) { repo.start(info, format); repo.downloads() } }
                                        .onSuccess { items = it; error = "" }.onFailure { error = it.message ?: "تعذر بدء التحميل." }
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text(format.label, fontSize = 12.sp) }
                        }
                        Text("تظهر الملفات المباشرة فقط؛ البث المجزأ ودمج الصوت مع الفيديو غير مدعومين بعد.", fontSize = 11.sp, color = Muted)
                    } else Text(info.extractorError.ifBlank { "لا تتوفر صيغ مباشرة لهذا الرابط. قد يكون الموقع غير مدعوم أو المحتوى محمياً أو مجزأً." }, fontSize = 12.sp, color = Muted, lineHeight = 18.sp)
                }
            }
        }
        SectionLabel("التحميلات")
        if (items.isEmpty()) DayCard(Modifier.fillMaxWidth()) { Text("لا توجد تحميلات بعد.", Modifier.padding(20.dp), color = Muted, fontSize = 13.sp) }
        items.forEach { item ->
            DayCard(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(item.name, fontWeight = FontWeight.Medium, fontSize = 13.sp); Text(item.state, color = Muted, fontSize = 11.sp) }
                        if (item.state == "اكتمل") IconButton(onClick = {
                            val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                            manager.getUriForDownloadedFile(item.id)?.let { uri ->
                                runCatching { context.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, manager.getMimeTypeForDownloadedFile(item.id)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
                            }
                        }) { Icon(Icons.Outlined.OpenInNew, "فتح") }
                        else IconButton(onClick = { scope.launch { items = withContext(Dispatchers.IO) { repo.cancel(item.id); repo.downloads() } } }) { Icon(Icons.Outlined.Close, "إلغاء") }
                    }
                    if (item.total > 0 && item.state != "اكتمل") {
                        LinearProgressIndicator(progress = { (item.bytes.toFloat() / item.total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                        Text("${formatBytes(item.bytes)} / ${formatBytes(item.total)}", fontSize = 10.sp, color = Muted)
                    }
                }
            }
        }
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1_073_741_824 -> "%.1f GB".format(bytes / 1_073_741_824.0)
    bytes >= 1_048_576 -> "%.1f MB".format(bytes / 1_048_576.0)
    bytes >= 1024 -> "%.1f KB".format(bytes / 1024.0)
    else -> "$bytes B"
}