package app.dayflow.android.ui

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.R
import app.dayflow.android.alarm.AlarmStore
import app.dayflow.android.alarm.formatTime12
import app.dayflow.android.alarm.nextOccurrence
import app.dayflow.android.prayer.PrayerRepository
import app.dayflow.android.prayer.calculatePrayers
import app.dayflow.android.prayer.nextPrayer
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.YearMonth
import java.time.chrono.HijrahDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoField
import java.util.Locale

private data class TaskItem(val id: Long, val title: String, val done: Boolean)
private class TodayStore(context: Context) {
    private val prefs = context.getSharedPreferences("dayflow_compose", Context.MODE_PRIVATE)
    private val key = "tasks_${LocalDate.now()}"
    fun tasks(): List<TaskItem> = runCatching {
        val a = JSONArray(prefs.getString(key, "[]"))
        (0 until a.length()).map { a.getJSONObject(it).let { j -> TaskItem(j.getLong("id"), j.getString("title"), j.optBoolean("done")) } }
    }.getOrDefault(emptyList())
    fun save(tasks: List<TaskItem>) {
        val array = JSONArray()
        tasks.forEach { array.put(JSONObject().put("id", it.id).put("title", it.title).put("done", it.done)) }
        prefs.edit().putString(key, array.toString()).apply()
    }
    fun water() = prefs.getInt("water_${LocalDate.now()}", 0)
    fun water(value: Int) { prefs.edit().putInt("water_${LocalDate.now()}", value).apply() }
}

@Composable
fun TodayScreen(go: (String) -> Unit) {
    val context = LocalContext.current
    val store = remember { TodayStore(context) }
    var tasks by remember { mutableStateOf(store.tasks()) }
    var water by remember { mutableIntStateOf(store.water()) }
    var text by remember { mutableStateOf("") }
    var now by remember { mutableStateOf(ZonedDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { delay(30_000); now = ZonedDateTime.now() } }
    val city = PrayerRepository(context).selected()
    val dateInCity = now.withZoneSameInstant(ZoneId.of(city.zone)).toLocalDate()
    val prayers = remember(city, dateInCity) { runCatching { calculatePrayers(city, dateInCity) }.getOrDefault(emptyList()) }
    val next = remember(city, now) { nextPrayer(city, now.toInstant()) }
    val alarm = remember(now) { AlarmStore(context).all().mapNotNull { a -> nextOccurrence(a, now)?.let { a to it } }.minByOrNull { it.second } }
    val locale = Locale("ar", "EG")
    val date = now.format(DateTimeFormatter.ofPattern("EEEE، d MMMM", locale))
    val greeting = when (now.hour) { in 0..4 -> "طابت ليلتك"; in 5..11 -> "صباح الخير"; in 12..16 -> "طاب يومك"; else -> "مساء الخير" }
    val hijriMonth = runCatching { HijrahDate.now().get(ChronoField.MONTH_OF_YEAR) }.getOrDefault(0)
    val hero = when { hijriMonth == 9 -> R.drawable.season_ramadan; now.monthValue in 3..5 -> R.drawable.season_spring
        now.monthValue in 6..8 -> R.drawable.season_summer; now.monthValue in 9..11 -> R.drawable.season_autumn; else -> R.drawable.season_winter }
    val ornament = when { hijriMonth == 9 -> R.drawable.decor_ramadan; now.monthValue in 3..5 -> R.drawable.decor_spring
        now.monthValue in 6..8 -> R.drawable.decor_summer; now.monthValue in 9..11 -> R.drawable.decor_autumn; else -> R.drawable.decor_winter }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(top = 8.dp, bottom = 85.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(24.dp))) {
            Image(painterResource(hero), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xcc254f44), Color(0xa8357565)))))
            Image(painterResource(ornament), null, Modifier.align(Alignment.BottomEnd).padding(end = 14.dp, bottom = 10.dp).size(68.dp), contentScale = ContentScale.Fit, alpha = .88f)
            Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
                Text(greeting, color = Color.White.copy(alpha = .85f), fontSize = 14.sp)
                Text(date, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("يومك بهدوء", color = Color.White.copy(alpha = .88f), fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                Surface(color = Color.White.copy(alpha = .2f), shape = RoundedCornerShape(50)) {
                    Text("DAYFLOW", Modifier.padding(horizontal = 10.dp, vertical = 4.dp), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        DayCard(Modifier.fillMaxWidth(), onClick = { go("prayer") }) {
            Column(Modifier.padding(12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("الصلاة · ${city.name}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(next?.let { "القادمة: ${it.name} ${formatTime12(it.at.hour, it.at.minute)}" } ?: "المواقيت غير متاحة", color = Accent, fontSize = 11.sp)
                }
                Spacer(Modifier.height(8.dp))
                if (prayers.isEmpty()) Text("تعذر حساب المواقيت لهذا الموقع.", fontSize = 12.sp, color = Muted)
                else Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    prayers.forEach { prayer ->
                        val selected = prayer.name == next?.name
                        Column(Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).background(if (selected) Accent else Soft).padding(vertical = 5.dp),
                            horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(prayer.name, fontSize = 10.sp, color = if (selected) Color.White else Ink, maxLines = 1)
                            Text(formatTime12(prayer.at.hour, prayer.at.minute), fontSize = 9.sp, fontWeight = FontWeight.Bold,
                                color = if (selected) Color.White else Ink, maxLines = 1)
                        }
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            DayCard(Modifier.weight(1f), onClick = { go("alarms") }) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Icon(Icons.Outlined.Alarm, null, Modifier.size(15.dp), tint = Muted); Text("المنبه التالي", fontSize = 12.sp, color = Muted)
                    }
                    Spacer(Modifier.height(9.dp))
                    Text(alarm?.let { formatTime12(it.first.hour, it.first.minute) } ?: "لا منبهات مفعّلة", fontWeight = FontWeight.Bold, fontSize = if (alarm == null) 13.sp else 22.sp)
                }
            }
            DayCard(Modifier.weight(1f)) {
                Column(Modifier.padding(16.dp)) {
                    Text("اليوم", fontSize = 12.sp, color = Muted)
                    Spacer(Modifier.height(9.dp))
                    Text("${tasks.count { it.done }} / ${tasks.size}", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("مهام", color = Muted, fontSize = 11.sp)
                }
            }
        }
        DayCard(Modifier.fillMaxWidth(), onClick = { go("downloads") }) {
            SettingsRow(Icons.Outlined.Download, "التحميل", "الصق أو شارك رابطاً لعرض محتواه") { go("downloads") }
        }
        DayCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("مهام اليوم", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("ضيف مهمة للنهاردة...", fontSize = 13.sp) },
                        singleLine = true, shape = RoundedCornerShape(14.dp))
                    FilledIconButton(onClick = {
                        if (text.isNotBlank()) { tasks = tasks + TaskItem(System.currentTimeMillis(), text.trim(), false); store.save(tasks); text = "" }
                    }) { Icon(Icons.Outlined.Add, "إضافة مهمة") }
                }
                if (tasks.isEmpty()) Text("يوم فاضي وهادي · لسه مفيش حاجة متخططة.", Modifier.padding(top = 14.dp), fontSize = 12.sp, color = Muted)
                tasks.forEach { task ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(task.done, onCheckedChange = { done -> tasks = tasks.map { if (it.id == task.id) it.copy(done = done) else it }; store.save(tasks) })
                        Text(task.title, Modifier.weight(1f), fontSize = 14.sp)
                        IconButton(onClick = { tasks = tasks.filterNot { it.id == task.id }; store.save(tasks) }) { Icon(Icons.Outlined.DeleteOutline, "حذف", tint = Muted) }
                    }
                }
            }
        }
        DayCard(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.WaterDrop, null, tint = Accent)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text("الماية", fontWeight = FontWeight.Bold); Text("$water مل اليوم", color = Muted, fontSize = 12.sp) }
                OutlinedButton(onClick = { water += 250; store.water(water) }) { Text("+ ٢٥٠ مل") }
            }
        }
    }
}

@Composable
fun CalendarScreen() {
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selected by remember { mutableStateOf(LocalDate.now()) }
    val locale = Locale("ar", "EG")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        ScreenTitle("التقويم", "أيامك في مكان واحد")
        DayCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(15.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { month = month.minusMonths(1) }) { Icon(Icons.Outlined.ChevronRight, "الشهر السابق") }
                    Text(month.format(DateTimeFormatter.ofPattern("MMMM yyyy", locale)), Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
                    IconButton(onClick = { month = month.plusMonths(1) }) { Icon(Icons.Outlined.ChevronLeft, "الشهر التالي") }
                }
                Row(Modifier.fillMaxWidth()) { listOf("ح", "ن", "ث", "ر", "خ", "ج", "س").forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, color = Muted, fontSize = 12.sp) } }
                val offset = month.atDay(1).dayOfWeek.value % 7
                val cells = (0 until 42).map { it - offset + 1 }
                cells.chunked(7).forEach { week ->
                    Row(Modifier.fillMaxWidth()) {
                        week.forEach { day ->
                            val valid = day in 1..month.lengthOfMonth()
                            val current = valid && selected == month.atDay(day)
                            Box(Modifier.weight(1f).height(44.dp).padding(3.dp).clip(RoundedCornerShape(13.dp))
                                .background(if (current) Accent else Color.Transparent).clickable(enabled = valid) { selected = month.atDay(day) }, contentAlignment = Alignment.Center) {
                                if (valid) Text("$day", color = if (current) Color.White else Ink, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(15.dp))
        DayCard(Modifier.fillMaxWidth()) { Text(selected.format(DateTimeFormatter.ofPattern("EEEE، d MMMM yyyy", locale)), Modifier.padding(16.dp), fontWeight = FontWeight.Medium) }
    }
}