package app.dayflow.android.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import app.dayflow.android.R
import kotlin.math.roundToInt

@Composable
fun BoxScope.InAppCompanion(onClick: () -> Unit) {
    val density = LocalDensity.current.density
    val config = LocalConfiguration.current
    var x by remember { mutableFloatStateOf(0f) }
    var y by remember { mutableFloatStateOf(0f) }
    val transition = rememberInfiniteTransition(label = "companion")
    val bob by transition.animateFloat(0f, -3f * density, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "breathing")
    Image(painterResource(R.drawable.robot_idle), contentDescription = "الرفيق",
        modifier = Modifier.align(Alignment.BottomStart).padding(start = 5.dp, bottom = 84.dp).size(width = 84.dp, height = 112.dp)
            .offset { IntOffset(x.roundToInt(), y.roundToInt()) }
            .graphicsLayer { translationY = bob }
            .pointerInput(config.screenWidthDp, config.screenHeightDp) {
                detectDragGestures { change, amount ->
                    change.consume()
                    x = (x + amount.x).coerceIn(-(config.screenWidthDp - 90).coerceAtLeast(0) * density, 0f)
                    y = (y + amount.y).coerceIn(-(config.screenHeightDp - 230).coerceAtLeast(0) * density, 60f * density)
                }
            }.clickable(onClick = onClick))
}