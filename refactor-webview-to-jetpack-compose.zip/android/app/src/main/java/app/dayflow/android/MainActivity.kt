package app.dayflow.android

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import app.dayflow.android.alarm.AlarmScheduler
import app.dayflow.android.alarm.AlarmStore
import app.dayflow.android.alarm.Notifications
import app.dayflow.android.ui.DayflowApp
import app.dayflow.android.ui.DayflowTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifications.createChannels(this)
        if (AlarmStore(this).importLegacyAlarms()) AlarmScheduler.restore(this)
        val shared = if (intent.action == Intent.ACTION_SEND) intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty() else ""
        val route = if (shared.isNotBlank()) "downloads" else intent.getStringExtra("route") ?: "today"
        setContent { DayflowTheme { DayflowApp(route, shared) } }
    }
}