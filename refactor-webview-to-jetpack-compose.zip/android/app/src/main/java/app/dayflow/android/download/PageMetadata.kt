package app.dayflow.android.download

import org.jsoup.Jsoup
import java.net.URI

data class PageMetadata(val title: String, val description: String, val author: String, val image: String)

fun parsePageMetadata(html: String, url: String): PageMetadata {
    val doc = Jsoup.parse(html, url)
    fun meta(vararg names: String): String = names.firstNotNullOfOrNull { name ->
        doc.selectFirst("meta[property='$name'], meta[name='$name']")?.attr("content")?.trim()?.takeIf(String::isNotEmpty)
    } ?: ""
    val rawImage = meta("og:image:secure_url", "og:image", "twitter:image", "twitter:image:src")
    val image = if (rawImage.isBlank()) "" else runCatching { URI(url).resolve(rawImage).toString() }.getOrDefault("")
    val host = runCatching { URI(url).host.orEmpty() }.getOrDefault("")
    return PageMetadata(meta("og:title", "twitter:title").ifBlank { doc.title().ifBlank { host } },
        meta("og:description", "description", "twitter:description"), meta("author", "article:author", "og:site_name"),
        image.takeIf { it.startsWith("https://") } ?: "")
}