package app.dayflow.android.download

import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.jsoup.Jsoup
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import java.net.URI

data class StreamOption(val url: String, val label: String, val filename: String, val mime: String)

/** NewPipe returns the real streams exposed by a supported service; segmented streams are not offered as files. */
object StreamExtractor {
    @Volatile private var initialized = false

    fun supports(url: String): Boolean {
        val host = runCatching { URI(url).host.lowercase() }.getOrDefault("")
        return host == "youtu.be" || host.endsWith(".youtube.com") || host == "youtube.com" ||
            host == "soundcloud.com" || host.endsWith(".soundcloud.com") || host.endsWith(".bandcamp.com") || host == "media.ccc.de"
    }

    @Synchronized private fun initialize(client: OkHttpClient) {
        if (!initialized) { NewPipe.init(ExtractorDownloader(client)); initialized = true }
    }

    fun analyze(url: String, client: OkHttpClient): LinkMetadata {
        initialize(client)
        val info = StreamInfo.getInfo(url)
        val base = info.name.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(100).ifBlank { "media" }
        val video = info.videoStreams.filter { it.isUrl && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && it.content.startsWith("https://") }
            .mapNotNull { stream ->
                val format = stream.format ?: return@mapNotNull null
                StreamOption(stream.content, "فيديو وصوت · ${stream.resolution} · ${format.suffix}", "$base-${stream.resolution}.${format.suffix}", format.mimeType)
            }
        val audio = info.audioStreams.filter { it.isUrl && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && it.content.startsWith("https://") }
            .mapNotNull { stream ->
                val format = stream.format ?: return@mapNotNull null
                val bitrate = stream.averageBitrate.takeIf { it > 0 }?.let { " · $it kbps" }.orEmpty()
                StreamOption(stream.content, "صوت · ${format.suffix}$bitrate", "$base-audio.${format.suffix}", format.mimeType)
            }
        val image = info.thumbnails.filter { it.url.startsWith("https://") }.maxByOrNull { it.width.toLong() * it.height }?.url.orEmpty()
        return LinkMetadata(url = info.url, title = info.name, author = info.uploaderName.orEmpty(),
            description = Jsoup.parse(info.description?.content().orEmpty()).text().take(1500), image = image,
            durationSeconds = info.duration.takeIf { it > 0 }, formats = (video + audio).distinctBy { it.url })
    }
}

private class ExtractorDownloader(private val client: OkHttpClient) : Downloader() {
    override fun execute(request: Request): Response {
        val builder = okhttp3.Request.Builder().url(request.url())
        request.headers().forEach { (name, values) -> values.forEach { builder.addHeader(name, it) } }
        if (request.headers().keys.none { it.equals("User-Agent", true) }) {
            builder.header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126.0 Mobile Safari/537.36")
        }
        when (request.httpMethod().uppercase()) {
            "HEAD" -> builder.head()
            "POST" -> builder.post((request.dataToSend() ?: ByteArray(0)).toRequestBody())
            else -> builder.get()
        }
        client.newCall(builder.build()).execute().use { response ->
            return Response(response.code, response.message, response.headers.toMultimap(), response.body?.string().orEmpty(), response.request.url.toString())
        }
    }
}