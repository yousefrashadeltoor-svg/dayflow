package app.dayflow.android.prayer

import android.content.Context
import com.batoulapps.adhan2.CalculationMethod
import com.batoulapps.adhan2.Coordinates
import com.batoulapps.adhan2.PrayerTimes
import com.batoulapps.adhan2.data.DateComponents
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

data class PrayerCity(val id: String, val name: String, val lat: Double, val lon: Double, val zone: String,
                      val method: CalculationMethod = CalculationMethod.EGYPTIAN)
data class PrayerMoment(val name: String, val at: ZonedDateTime)

val prayerCities = listOf(
    PrayerCity("cairo", "القاهرة", 30.0444, 31.2357, "Africa/Cairo"),
    PrayerCity("giza", "الجيزة", 30.0131, 31.2089, "Africa/Cairo"),
    PrayerCity("qalyubia", "القليوبية", 30.3292, 31.2168, "Africa/Cairo"),
    PrayerCity("alexandria", "الإسكندرية", 31.2001, 29.9187, "Africa/Cairo"),
    PrayerCity("luxor", "الأقصر", 25.6872, 32.6396, "Africa/Cairo"),
    PrayerCity("aswan", "أسوان", 24.0889, 32.8998, "Africa/Cairo"),
    PrayerCity("suez", "السويس", 29.9668, 32.5498, "Africa/Cairo"),
    PrayerCity("sharm", "شرم الشيخ", 27.9158, 34.3299, "Africa/Cairo"),
    PrayerCity("makkah", "مكة المكرمة", 21.4225, 39.8262, "Asia/Riyadh", CalculationMethod.UMM_AL_QURA),
    PrayerCity("madinah", "المدينة المنورة", 24.4686, 39.6142, "Asia/Riyadh", CalculationMethod.UMM_AL_QURA),
    PrayerCity("dubai", "دبي", 25.2048, 55.2708, "Asia/Dubai", CalculationMethod.DUBAI),
    PrayerCity("london", "لندن", 51.5074, -0.1278, "Europe/London", CalculationMethod.MUSLIM_WORLD_LEAGUE)
)

fun calculatePrayers(city: PrayerCity, date: LocalDate): List<PrayerMoment> {
    val zone = ZoneId.of(city.zone)
    val p = PrayerTimes(Coordinates(city.lat, city.lon), DateComponents(date.year, date.monthValue, date.dayOfMonth), city.method.parameters)
    fun at(ms: Long) = Instant.ofEpochMilli(ms).atZone(zone)
    return listOf(
        PrayerMoment("الفجر", at(p.fajr.toEpochMilliseconds())),
        PrayerMoment("الشروق", at(p.sunrise.toEpochMilliseconds())),
        PrayerMoment("الظهر", at(p.dhuhr.toEpochMilliseconds())),
        PrayerMoment("العصر", at(p.asr.toEpochMilliseconds())),
        PrayerMoment("المغرب", at(p.maghrib.toEpochMilliseconds())),
        PrayerMoment("العشاء", at(p.isha.toEpochMilliseconds()))
    )
}

fun nextPrayer(city: PrayerCity, now: Instant = Instant.now()): PrayerMoment? = runCatching {
    val date = now.atZone(ZoneId.of(city.zone)).toLocalDate()
    (calculatePrayers(city, date) + calculatePrayers(city, date.plusDays(1))).firstOrNull { it.at.toInstant().isAfter(now) }
}.getOrNull()

class PrayerRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("dayflow_compose", Context.MODE_PRIVATE)
    fun selected(): PrayerCity {
        if (prefs.getString("city_id", "cairo") == "device") {
            return PrayerCity("device", "موقعي", Double.fromBits(prefs.getLong("latitude", 0)),
                Double.fromBits(prefs.getLong("longitude", 0)), prefs.getString("location_zone", ZoneId.systemDefault().id)!!)
        }
        return prayerCities.find { it.id == prefs.getString("city_id", "cairo") } ?: prayerCities.first()
    }
    fun select(city: PrayerCity) { prefs.edit().putString("city_id", city.id).apply() }
    fun selectLocation(lat: Double, lon: Double) {
        prefs.edit().putString("city_id", "device").putLong("latitude", lat.toBits()).putLong("longitude", lon.toBits())
            .putString("location_zone", ZoneId.systemDefault().id).apply()
    }
}