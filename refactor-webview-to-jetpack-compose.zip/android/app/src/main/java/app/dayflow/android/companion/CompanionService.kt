package app.dayflow.android.companion

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import app.dayflow.android.MainActivity
import app.dayflow.android.R
import app.dayflow.android.alarm.Notifications
import kotlin.math.abs
import kotlin.math.sin

class CompanionService : Service() {
    private lateinit var windows: WindowManager
    private var robot: RobotView? = null
    private var params: WindowManager.LayoutParams? = null
    private val preferences by lazy { getSharedPreferences("dayflow_compose", Context.MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() { super.onCreate(); windows = getSystemService(WINDOW_SERVICE) as WindowManager }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == STOP) {
            preferences.edit().putBoolean("overlay_enabled", false).apply(); stopSelf(); return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) { preferences.edit().putBoolean("overlay_enabled", false).apply(); stopSelf(); return START_NOT_STICKY }
        Notifications.createChannels(this)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).putExtra("route", "companion"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 0, Intent(this, CompanionService::class.java).setAction(STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val note = NotificationCompat.Builder(this, Notifications.COMPANION).setSmallIcon(R.drawable.ic_dayflow)
            .setContentTitle("رفيق DAYFLOW ظاهر على الشاشة").setContentText("اضغط للعودة إلى التطبيق")
            .setContentIntent(open).setOngoing(true).addAction(0, "إخفاء", stop).build()
        startForeground(4002, note)
        if (robot == null) {
            val density = resources.displayMetrics.density
            val scale = preferences.getFloat("overlay_size", 1f).coerceIn(.6f, 1.6f)
            val view = RobotView(this)
            val layout = WindowManager.LayoutParams((120 * density * scale).toInt(), (150 * density * scale).toInt(),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT).apply {
                gravity = Gravity.TOP or Gravity.START
                x = preferences.getInt("overlay_x", 12)
                y = preferences.getInt("overlay_y", (120 * density).toInt())
                alpha = preferences.getFloat("overlay_opacity", 1f).coerceIn(.3f, 1f)
            }
            params = layout; robot = view
            try { windows.addView(view, layout); preferences.edit().putBoolean("overlay_enabled", true).apply() }
            catch (_: Exception) { robot = null; preferences.edit().putBoolean("overlay_enabled", false).apply(); stopSelf(); return START_NOT_STICKY }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        robot?.let { runCatching { windows.removeView(it) } }
        robot = null
        super.onDestroy()
    }

    private inner class RobotView(context: Context) : View(context) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private var downX = 0f; private var downY = 0f; private var initialX = 0; private var initialY = 0
        private fun color(hex: String) = Color.parseColor(hex)
        private fun line(canvas: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, width: Float, color: String) {
            p.shader = null; p.color = color(color); p.style = Paint.Style.STROKE; p.strokeWidth = width; p.strokeCap = Paint.Cap.ROUND
            canvas.drawLine(x1, y1, x2, y2, p); p.style = Paint.Style.FILL
        }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.save(); canvas.scale(width / 120f, height / 150f)
            val bob = sin(SystemClock.uptimeMillis() / 900.0).toFloat() * 1.2f
            canvas.translate(0f, bob)
            p.shader = null; p.color = 0x26000000; canvas.drawOval(34f, 141f, 86f, 149f, p)
            line(canvas, 48f, 116f, 46f, 134f, 9f, "#8d9bb0"); line(canvas, 72f, 116f, 74f, 134f, 9f, "#8d9bb0")
            line(canvas, 34f, 78f, 20f, 112f, 8f, "#9aa7ba"); line(canvas, 86f, 78f, 100f, 112f, 8f, "#9aa7ba")
            p.shader = RadialGradient(48f, 72f, 65f, intArrayOf(color("#ffffff"), color("#d9e2ee"), color("#8d9bb0")), null, Shader.TileMode.CLAMP)
            canvas.drawRoundRect(34f, 66f, 86f, 122f, 18f, 18f, p)
            p.shader = null; p.color = color("#0f1a2c"); canvas.drawRoundRect(47f, 80f, 73f, 96f, 5f, 5f, p)
            p.color = color("#2f6f5e"); canvas.drawCircle(60f, 88f, 4f, p)
            line(canvas, 50f, 22f, 40f, 0f, 2.5f, "#7d8aa0"); line(canvas, 70f, 22f, 80f, 0f, 2.5f, "#7d8aa0")
            p.color = color("#c9a24a"); canvas.drawCircle(40f, 2f, 4f, p); canvas.drawCircle(80f, 2f, 4f, p)
            p.shader = RadialGradient(45f, 28f, 60f, intArrayOf(color("#ffffff"), color("#d9e2ee"), color("#8d9bb0")), null, Shader.TileMode.CLAMP)
            canvas.drawRoundRect(30f, 20f, 90f, 66f, 20f, 20f, p)
            p.shader = LinearGradient(37f, 29f, 83f, 57f, color("#3a4a66"), color("#0d1424"), Shader.TileMode.CLAMP)
            canvas.drawRoundRect(37f, 29f, 83f, 57f, 13f, 13f, p)
            p.shader = null; p.color = color("#7fd6ff")
            val eyeHeight = if (SystemClock.uptimeMillis() % 5000 < 140) 1f else 5f
            canvas.drawOval(46f, 43f - eyeHeight, 54f, 43f + eyeHeight, p); canvas.drawOval(66f, 43f - eyeHeight, 74f, 43f + eyeHeight, p)
            p.color = color("#e7edf5"); canvas.drawCircle(20f, 114f, 5.5f, p); canvas.drawCircle(100f, 114f, 5.5f, p)
            canvas.restore()
            postInvalidateDelayed(80)
        }
        override fun onTouchEvent(event: MotionEvent): Boolean {
            val layout = params ?: return false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; initialX = layout.x; initialY = layout.y; return true }
                MotionEvent.ACTION_MOVE -> {
                    layout.x = (initialX + event.rawX - downX).toInt().coerceIn(0, (resources.displayMetrics.widthPixels - width).coerceAtLeast(0))
                    layout.y = (initialY + event.rawY - downY).toInt().coerceIn(0, (resources.displayMetrics.heightPixels - height).coerceAtLeast(0))
                    runCatching { windows.updateViewLayout(this, layout) }; return true
                }
                MotionEvent.ACTION_UP -> {
                    preferences.edit().putInt("overlay_x", layout.x).putInt("overlay_y", layout.y).apply()
                    if (abs(event.rawX - downX) < 12 && abs(event.rawY - downY) < 12) {
                        startActivity(Intent(this@CompanionService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                    return true
                }
            }
            return super.onTouchEvent(event)
        }
    }
    companion object { const val STOP = "app.dayflow.android.STOP_COMPANION" }
}