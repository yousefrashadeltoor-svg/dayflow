package app.dayflow.android.download

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.webkit.URLUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URI
import java.util.concurrent.TimeUnit

data class LinkMetadata(
    val url: String, val title: String, val description: String = "", val author: String = "",
    val image: String = "", val mime: String = "", val filename: String = "", val size: Long? = null,
    val directFile: Boolean = false, val durationSeconds: Long? = null, val formats: List<StreamOption> = emptyList(),
    val extractorError: String = ""
)
data class NativeDownload(val id: Long, val name: String, val state: String, val bytes: Long, val total: Long)

class LinkRepository(private val context: Context) {
    private val client = OkHttpClient.Builder().connectTimeout(12, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS)
        .callTimeout(25, TimeUnit.SECONDS).followRedirects(true).build()
    private val prefs = context.getSharedPreferences("dayflow_compose", Context.MODE_PRIVATE)

    suspend fun analyze(raw: String): LinkMetadata = withContext(Dispatchers.IO) {
        val uri = runCatching { URI(raw.trim()) }.getOrNull() ?: throw IllegalArgumentException("أدخل رابط HTTPS صحيحاً.")
        require(uri.scheme == "https" && !uri.host.isNullOrBlank() && uri.userInfo == null) { "أدخل رابط HTTPS صحيحاً." }
        var extractorError = ""
        if (StreamExtractor.supports(uri.toString())) {
            try { return@withContext StreamExtractor.analyze(uri.toString(), client) }
            catch (_: Exception) { extractorError = "تعذر استخراج الصيغ؛ قد يتطلب الموقع تسجيل دخول أو تحديث المحرك." }
        }
        val request = Request.Builder().url(uri.toString()).header("User-Agent", "Mozilla/5.0 (Android) DAYFLOW/2.0").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("تعذر فتح الرابط (HTTP ${response.code}).")
            val url = response.request.url.toString()
            val mime = response.header("Content-Type").orEmpty().substringBefore(';').trim().lowercase()
            val size = response.header("Content-Length")?.toLongOrNull()?.takeIf { it >= 0 }
            val filename = URLUtil.guessFileName(url, response.header("Content-Disposition"), mime.ifBlank { null })
            val direct = mime.startsWith("video/") || mime.startsWith("audio/") || mime.startsWith("image/") ||
                (mime.isNotBlank() && !mime.startsWith("text/") && mime != "application/xhtml+xml" && mime != "application/json")
            if (direct) return@withContext LinkMetadata(url, filename, mime = mime, filename = filename, size = size, directFile = true)
            if (mime.isNotBlank() && mime != "text/html" && mime != "application/xhtml+xml") {
                return@withContext LinkMetadata(url, uri.host.orEmpty(), mime = mime)
            }
            val source = response.body?.source() ?: throw IllegalStateException("الصفحة فارغة.")
            source.request(1_048_576)
            val count = minOf(source.buffer.size, 1_048_576L)
            val html = source.readString(count, response.body?.contentType()?.charset(Charsets.UTF_8) ?: Charsets.UTF_8)
            val page = parsePageMetadata(html, url)
            LinkMetadata(url, page.title, page.description, page.author, page.image, mime, size = size, extractorError = extractorError)
        }
    }

    fun start(info: LinkMetadata, option: StreamOption? = null): Long {
        require(info.directFile || option != null) { "لا يوجد ملف مباشر أو صيغة متاحة لهذا الرابط." }
        val safeName = (option?.filename ?: info.filename).replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "download" }
        val request = DownloadManager.Request(Uri.parse(option?.url ?: info.url)).setTitle(safeName)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .addRequestHeader("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126.0 Mobile Safari/537.36")
        (option?.mime ?: info.mime).takeIf { it.isNotBlank() }?.let { request.setMimeType(it) }
        if (Build.VERSION.SDK_INT >= 29) request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, safeName)
        else request.setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, safeName)
        val id = (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
        val ids = prefs.getStringSet("download_ids", emptySet()).orEmpty().toMutableSet().apply { add(id.toString()) }
        prefs.edit().putStringSet("download_ids", ids).apply()
        return id
    }

    fun downloads(): List<NativeDownload> {
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        return prefs.getStringSet("download_ids", emptySet()).orEmpty().mapNotNull { raw ->
            val id = raw.toLongOrNull() ?: return@mapNotNull null
            manager.query(DownloadManager.Query().setFilterById(id)).use { cursor ->
                if (!cursor.moveToFirst()) return@mapNotNull null
                fun int(name: String) = cursor.getInt(cursor.getColumnIndexOrThrow(name))
                fun long(name: String) = cursor.getLong(cursor.getColumnIndexOrThrow(name))
                val state = when (int(DownloadManager.COLUMN_STATUS)) {
                    DownloadManager.STATUS_PENDING -> "في الانتظار"
                    DownloadManager.STATUS_RUNNING -> "جارٍ التحميل"
                    DownloadManager.STATUS_PAUSED -> "متوقف مؤقتاً بواسطة النظام"
                    DownloadManager.STATUS_SUCCESSFUL -> "اكتمل"
                    else -> "فشل التحميل"
                }
                NativeDownload(id, cursor.getString(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)) ?: "ملف",
                    state, long(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR), long(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
            }
        }.sortedByDescending { it.id }
    }

    fun cancel(id: Long) {
        (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(id)
        val ids = prefs.getStringSet("download_ids", emptySet()).orEmpty().toMutableSet().apply { remove(id.toString()) }
        prefs.edit().putStringSet("download_ids", ids).apply()
    }
}