package app.dayflow.android.ui

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Alarm
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import app.dayflow.android.alarm.AlarmEntry
import app.dayflow.android.alarm.AlarmScheduler
import app.dayflow.android.alarm.AlarmStore
import app.dayflow.android.alarm.formatTime12
import app.dayflow.android.alarm.nextOccurrence
import app.dayflow.android.widgets.DayflowWidgetProvider
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlarmScreen() {
    val context = LocalContext.current
    val store = remember { AlarmStore(context) }
    var alarms by remember { mutableStateOf(store.all()) }
    var editor by remember { mutableStateOf<AlarmEntry?>(null) }
    var message by remember { mutableStateOf("") }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        message = if (granted) "تم السماح بالإشعارات؛ فعّل المنبه مرة أخرى." else "الإشعارات مرفوضة؛ غيّر الإذن من إعدادات الهاتف."
    }
    val next = alarms.mapNotNull { a -> nextOccurrence(a)?.let { a to it } }.minByOrNull { it.second }
    fun refresh() { alarms = store.all(); DayflowWidgetProvider.updateAll(context) }
    fun requestExactPermission() {
        if (Build.VERSION.SDK_INT >= 31) {
            runCatching { context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}"))) }
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 90.dp)) {
        ScreenTitle("المنبهات", next?.let { "التالي: ${formatTime12(it.first.hour, it.first.minute)}" } ?: "لا منبهات مفعّلة", end = {
            Button(onClick = { editor = AlarmEntry(id = 0) }, shape = RoundedCornerShape(15.dp)) {
                Icon(Icons.Outlined.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("جديد")
            }
        })
        if (message.isNotBlank()) Text(message, Modifier.padding(bottom = 10.dp), color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        if (alarms.isEmpty()) {
            DayCard(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(vertical = 40.dp, horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Outlined.Alarm, null, Modifier.size(42.dp), tint = Accent)
                    Spacer(Modifier.height(12.dp)); Text("مفيش منبهات لسه", fontWeight = FontWeight.Bold)
                    Text("أنشئ منبهاً في ثوانٍ.", fontSize = 12.sp, color = Muted)
                    Spacer(Modifier.height(14.dp)); Button(onClick = { editor = AlarmEntry(id = 0) }) { Text("اعمل منبه") }
                }
            }
        }
        alarms.forEach { alarm ->
            DayCard(Modifier.fillMaxWidth().padding(bottom = 10.dp), onClick = { editor = alarm }) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(formatTime12(alarm.hour, alarm.minute), fontSize = 31.sp, fontWeight = FontWeight.SemiBold,
                            color = if (alarm.enabled) Ink else Muted)
                        Text(alarm.label.ifBlank { if (alarm.reminder) "تذكير" else "منبه" }, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                        val days = if (alarm.days.isEmpty()) alarm.date ?: "مرة واحدة" else if (alarm.days.size == 7) "كل يوم" else
                            listOf(6, 0, 1, 2, 3, 4, 5).filter { it in alarm.days }.joinToString(" · ") { dayNames[it] }
                        Text("$days · ${alarm.soundTitle}", color = Muted, fontSize = 11.sp)
                    }
                    Switch(checked = alarm.enabled, onCheckedChange = { enabled ->
                        message = ""
                        if (enabled && !AlarmScheduler.canSchedule(context)) { message = "اسمح بالمنبهات الدقيقة أولاً."; requestExactPermission() }
                        else if (enabled && Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                            message = "اسمح بالإشعارات أولاً."; notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        else if (enabled && nextOccurrence(alarm.copy(enabled = true)) == null) message = "موعد هذا المنبه قد مضى؛ اختر موعداً جديداً."
                        else {
                            val updated = alarm.copy(enabled = enabled)
                            if (!enabled) { AlarmScheduler.cancel(context, alarm.id); store.save(updated); refresh() }
                            else {
                                store.save(updated)
                                if (AlarmScheduler.schedule(context, updated)) refresh()
                                else { store.save(alarm); message = "تعذر جدولة المنبه. تحقق من صلاحية المنبهات الدقيقة." }
                            }
                        }
                    })
                }
            }
        }
    }
    editor?.let { initial ->
        ModalBottomSheet(onDismissRequest = { editor = null }, containerColor = Color.White) {
            AlarmEditor(initial, onClose = { editor = null }, onDelete = {
                AlarmScheduler.cancel(context, it); store.remove(it); refresh(); editor = null
            }, onSave = { updated ->
                val item = if (updated.id == 0) updated.copy(id = store.newId()) else updated
                val old = store.get(item.id)
                store.save(item)
                val ok = if (item.enabled) AlarmScheduler.schedule(context, item) else { AlarmScheduler.cancel(context, item.id); true }
                if (!ok) {
                    if (old == null) store.remove(item.id) else store.save(old)
                    message = "تعذر جدولة المنبه. تحقق من صلاحية المنبهات الدقيقة."
                } else { message = ""; refresh(); editor = null }
            })
        }
    }
}

private val dayNames = listOf("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")
private val dayShort = listOf("ح", "ن", "ث", "ر", "خ", "ج", "س")

@Composable
private fun AlarmEditor(initial: AlarmEntry, onClose: () -> Unit, onDelete: (Int) -> Unit, onSave: (AlarmEntry) -> Unit) {
    val context = LocalContext.current
    var a by remember(initial.id) { mutableStateOf(initial) }
    var error by remember { mutableStateOf("") }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        error = if (granted) "تم السماح بالإشعارات، اضغط حفظ مرة أخرى." else "الإشعارات مرفوضة؛ اسمح بها من إعدادات التطبيق لضمان ظهور التنبيه."
    }
    val ringtonePicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            @Suppress("DEPRECATION") val uri = result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            if (uri != null) a = a.copy(soundUri = uri.toString(), soundTitle = runCatching { RingtoneManager.getRingtone(context, uri).getTitle(context) }.getOrDefault("نغمة الجهاز"))
        }
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val name = runCatching {
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0) else null
                }
            }.getOrNull() ?: "ملف صوتي"
            a = a.copy(soundUri = uri.toString(), soundTitle = name)
        }
    }
    Column(Modifier.fillMaxWidth().heightIn(max = 700.dp).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
        Text(if (a.id == 0) "منبه جديد" else "تعديل المنبه", fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Surface(Modifier.fillMaxWidth().clickable {
            TimePickerDialog(context, { _, h, m -> a = a.copy(hour = h, minute = m) }, a.hour, a.minute, false).show()
        }, color = Paper, shape = RoundedCornerShape(18.dp)) {
            Text(formatTime12(a.hour, a.minute), Modifier.padding(15.dp), textAlign = TextAlign.Center, fontSize = 38.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = a.days.isEmpty(), onClick = { a = a.copy(days = emptySet(), date = a.date ?: LocalDate.now().toString()) }, label = { Text("يوم معين", fontSize = 11.sp) })
            FilterChip(selected = a.days.size == 7, onClick = { a = a.copy(days = (0..6).toSet(), date = null) }, label = { Text("كل يوم", fontSize = 11.sp) })
            FilterChip(selected = a.days == setOf(0, 1, 2, 3, 4), onClick = { a = a.copy(days = setOf(0, 1, 2, 3, 4), date = null) }, label = { Text("الأحد - الخميس", fontSize = 11.sp) })
        }
        if (a.days.isEmpty()) {
            TextButton(onClick = {
                val d = a.date?.let { runCatching { LocalDate.parse(it) }.getOrNull() } ?: LocalDate.now()
                DatePickerDialog(context, { _, y, m, day -> a = a.copy(date = LocalDate.of(y, m + 1, day).toString()) }, d.year, d.monthValue - 1, d.dayOfMonth).show()
            }) { Text("التاريخ: ${a.date ?: "اختر يوماً"}") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf(6, 0, 1, 2, 3, 4, 5).forEach { day ->
                Surface(modifier = Modifier.weight(1f).height(38.dp).clickable {
                    val newDays = if (day in a.days) a.days - day else a.days + day
                    a = a.copy(days = newDays, date = if (newDays.isEmpty()) LocalDate.now().toString() else null)
                }, shape = RoundedCornerShape(14.dp), color = if (day in a.days) Soft else Paper) {
                    Box(contentAlignment = Alignment.Center) { Text(dayShort[day], fontSize = 12.sp, color = if (day in a.days) Accent else Muted) }
                }
            }
        }
        OutlinedTextField(a.label, { a = a.copy(label = it) }, Modifier.fillMaxWidth(), label = { Text("الاسم (اختياري)") }, singleLine = true, shape = RoundedCornerShape(14.dp))
        Spacer(Modifier.height(10.dp))
        DayCard(Modifier.fillMaxWidth()) {
            SettingsRow(Icons.Outlined.MusicNote, "الصوت", a.soundTitle) {
                val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                    putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM or RingtoneManager.TYPE_NOTIFICATION)
                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                    putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, a.soundUri.takeIf { it.isNotBlank() }?.let(Uri::parse))
                }
                ringtonePicker.launch(intent)
            }
            TextButton(onClick = { filePicker.launch(arrayOf("audio/*")) }, modifier = Modifier.padding(horizontal = 8.dp)) { Text("اختيار ملف صوتي من الجهاز") }
        }
        Spacer(Modifier.height(8.dp))
        DayCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("اهتزاز", Modifier.weight(1f), fontSize = 14.sp); Switch(a.vibrate, { a = a.copy(vibrate = it) })
            }
            HorizontalDivider(color = Line)
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("استيقاظ لطيف", fontSize = 14.sp); Text("يرتفع الصوت خلال ٦٠ ثانية", fontSize = 11.sp, color = Muted) }
                Switch(a.gentle, { a = a.copy(gentle = it) })
            }
            HorizontalDivider(color = Line)
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("تذكير بإشعار فقط", Modifier.weight(1f), fontSize = 14.sp); Switch(a.reminder, { a = a.copy(reminder = it) })
            }
            HorizontalDivider(color = Line)
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("الغفوة", Modifier.weight(1f), fontSize = 14.sp)
                TextButton(onClick = { val options = listOf(5, 10, 15, 20); a = a.copy(snoozeMinutes = options[(options.indexOf(a.snoozeMinutes).coerceAtLeast(0) + 1) % options.size]) }) { Text("${a.snoozeMinutes} دقائق") }
            }
        }
        if (error.isNotBlank()) Text(error, Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (a.id != 0) OutlinedIconButton(onClick = { onDelete(a.id) }) { Icon(Icons.Outlined.DeleteOutline, "حذف") }
            OutlinedButton(onClick = onClose) { Text("إلغاء") }
            Button(onClick = {
                error = ""
                when {
                    nextOccurrence(a.copy(enabled = true)) == null -> error = "الموعد ده فات؛ اختار يوماً وساعة لسه جايين."
                    !AlarmScheduler.canSchedule(context) -> {
                        error = "اسمح بالمنبهات الدقيقة ثم ارجع واضغط حفظ."
                        if (Build.VERSION.SDK_INT >= 31) runCatching { context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}"))) }
                    }
                    Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED -> {
                        error = "اسمح بالإشعارات حتى يظهر التنبيه."; notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    else -> onSave(a)
                }
            }, modifier = Modifier.weight(1f)) { Text("حفظ") }
        }
    }
}