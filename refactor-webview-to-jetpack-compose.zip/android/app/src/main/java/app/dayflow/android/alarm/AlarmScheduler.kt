package app.dayflow.android.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.core.app.NotificationManagerCompat
import app.dayflow.android.MainActivity
import app.dayflow.android.widgets.DayflowWidgetProvider
import java.time.ZonedDateTime

object AlarmScheduler {
    private fun manager(context: Context) = context.getSystemService(AlarmManager::class.java)

    fun canSchedule(context: Context): Boolean = Build.VERSION.SDK_INT < 31 || manager(context).canScheduleExactAlarms()

    private fun alarmIntent(context: Context, id: Int, snooze: Boolean): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            data = Uri.parse("dayflow://alarm/$id/${if (snooze) "snooze" else "scheduled"}")
            putExtra("id", id); putExtra("snooze", snooze)
        }
        return PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun showIntent(context: Context): PendingIntent = PendingIntent.getActivity(
        context, 0, Intent(context, MainActivity::class.java).putExtra("route", "alarms"),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun schedule(context: Context, alarm: AlarmEntry, now: ZonedDateTime = ZonedDateTime.now()): Boolean {
        val next = nextOccurrence(alarm, now) ?: return false
        if (!canSchedule(context)) return false
        return try {
            manager(context).setAlarmClock(AlarmManager.AlarmClockInfo(next.toInstant().toEpochMilli(), showIntent(context)),
                alarmIntent(context, alarm.id, false))
            true
        } catch (_: SecurityException) { false }
    }

    fun snooze(context: Context, alarm: AlarmEntry): Boolean {
        if (!canSchedule(context)) return false
        val at = System.currentTimeMillis() + alarm.snoozeMinutes.coerceIn(1, 60) * 60_000L
        return try {
            manager(context).setAlarmClock(AlarmManager.AlarmClockInfo(at, showIntent(context)), alarmIntent(context, alarm.id, true))
            true
        } catch (_: SecurityException) { false }
    }

    fun cancel(context: Context, id: Int) {
        listOf(false, true).forEach { manager(context).cancel(alarmIntent(context, id, it)) }
    }

    fun restore(context: Context) {
        AlarmStore(context).all().filter { it.enabled }.forEach { schedule(context, it) }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        val snooze = intent.getBooleanExtra("snooze", false)
        val store = AlarmStore(context)
        val alarm = store.get(id) ?: return
        if (!alarm.enabled && !snooze) return
        if (!snooze) {
            if (alarm.days.isEmpty()) store.save(alarm.copy(enabled = false))
            else AlarmScheduler.schedule(context, alarm, ZonedDateTime.now().plusSeconds(2))
        }
        if (alarm.reminder) Notifications.showReminder(context, alarm)
        else {
            val service = Intent(context, AlarmService::class.java).putExtra("id", id)
            runCatching { ContextCompat.startForegroundService(context, service) }
        }
        DayflowWidgetProvider.updateAll(context)
    }
}

class AlarmActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val alarm = AlarmStore(context).get(intent.getIntExtra("id", -1))
        if (intent.action == "app.dayflow.android.SNOOZE" && alarm != null) AlarmScheduler.snooze(context, alarm)
        if (alarm?.reminder == true) NotificationManagerCompat.from(context).cancel(10_000 + alarm.id)
        else {
            context.stopService(Intent(context, AlarmService::class.java))
            context.sendBroadcast(Intent("app.dayflow.android.ALARM_FINISHED").setPackage(context.packageName))
        }
    }
}

class RestoreReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AlarmScheduler.restore(context)
        DayflowWidgetProvider.updateAll(context)
    }
}