package app.dayflow.android.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import app.dayflow.android.R
import app.dayflow.android.alarm.Notifications
import app.dayflow.android.alarm.formatTime12
import app.dayflow.android.companion.CompanionService
import app.dayflow.android.prayer.PrayerCity
import app.dayflow.android.prayer.PrayerRepository
import app.dayflow.android.prayer.calculatePrayers
import app.dayflow.android.prayer.prayerCities
import app.dayflow.android.widgets.DayflowWidgetProvider
import kotlinx.coroutines.delay
import java.time.ZoneId
import java.time.ZonedDateTime

private data class WidgetOption(val id: String, val title: String, val hint: String)
private val widgetOptions = listOf(
    WidgetOption("clock", "الساعة", "ساعة وتاريخ مباشران"),
    WidgetOption("alarm", "المنبه التالي", "موعد المنبه القادم"),
    WidgetOption("prayer", "الصلاة", "الصلاة القادمة في مدينتك"),
    WidgetOption("date", "النهاردة", "التاريخ الحالي")
)

@Composable
fun WidgetCatalog(configuring: Boolean, onBack: () -> Unit, onSelected: (String) -> Unit) {
    Column(Modifier.fillMaxSize().background(Paper).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 40.dp)) {
        ScreenTitle("الودجات", "الكتالوج · اختر التصميم المناسب", onBack)
        if (configuring) Text("اختر واحدة لتكون الودجت الذي أضفته إلى شاشة الهاتف.", Modifier.padding(bottom = 12.dp), color = Accent, fontWeight = FontWeight.Medium, fontSize = 13.sp)
        Text("الكتالوج", Modifier.padding(bottom = 10.dp), fontWeight = FontWeight.Bold)
        widgetOptions.forEach { widget ->
            Box(Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(20.dp)).clickable { onSelected(widget.id) }) {
                Image(painterResource(R.drawable.season_summer), null, Modifier.matchParentSize(), contentScale = ContentScale.Crop, alpha = .36f)
                Row(Modifier.fillMaxWidth().background(Color(0x8847665b)).padding(16.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Surface(shape = RoundedCornerShape(19.dp), color = Color.White, modifier = Modifier.width(126.dp).height(100.dp)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.Center) {
                            Text(widget.title, color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Text(when (widget.id) { "clock" -> formatTime12(ZonedDateTime.now().hour, ZonedDateTime.now().minute)
                                "alarm" -> "المنبه التالي"; "prayer" -> "الصلاة القادمة"; else -> "التاريخ" }, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text("DAYFLOW", fontSize = 10.sp, color = Muted)
                        }
                    }
                    Column(Modifier.weight(1f)) {
                        Text(widget.title, color = Color.White, fontWeight = FontWeight.Bold)
                        Text(widget.hint, color = Color.White.copy(alpha = .85f), fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp)); Text(if (configuring) "اختيار" else "إضافة إلى الشاشة", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Text("هذه هي التصاميم المنفذة أصلياً حالياً. بقية تصاميم الكتالوج المرجعي لم تُنقل بعد.", color = Muted, fontSize = 12.sp, lineHeight = 19.sp)
    }
}

@Composable
fun PrayerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val repository = remember { PrayerRepository(context) }
    var city by remember { mutableStateOf(repository.selected()) }
    var message by remember { mutableStateOf("") }
    val now = ZonedDateTime.now(ZoneId.of(city.zone))
    val times = remember(city, now.toLocalDate()) { runCatching { calculatePrayers(city, now.toLocalDate()) }.getOrDefault(emptyList()) }
    fun locate() {
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val location = runCatching { manager.getProviders(true).mapNotNull { manager.getLastKnownLocation(it) }
            .filter { System.currentTimeMillis() - it.time in 0..86_400_000L && (!it.hasAccuracy() || it.accuracy < 30_000f) }
            .maxByOrNull { it.time } }.getOrNull()
        if (location == null) message = "لا يوجد موقع حديث متاح. فعّل الموقع أو اختر مدينة يدوياً."
        else {
            repository.selectLocation(location.latitude, location.longitude); city = repository.selected(); message = ""
            DayflowWidgetProvider.updateAll(context)
        }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.any { it }) locate() else message = "لم يُسمح بالموقع؛ يمكنك اختيار مدينة يدوياً."
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 70.dp)) {
        ScreenTitle("مواقيت الصلاة", "${city.name} · ${city.zone}", onBack)
        DayCard(Modifier.fillMaxWidth()) {
            if (times.isEmpty()) Text("تعذر حساب المواقيت لهذا الموقع والتاريخ.", Modifier.padding(16.dp), color = Muted)
            times.forEach { p ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(p.name, fontWeight = FontWeight.Medium); Text(formatTime12(p.at.hour, p.at.minute), color = Accent, fontWeight = FontWeight.Bold)
                }
                if (p != times.last()) HorizontalDivider(color = Line)
            }
        }
        Text("الحساب فلكي، مع المنطقة الزمنية والتوقيت الصيفي للمدينة. قد تختلف الدقائق عن الجداول المحلية؛ راجع الجهة الرسمية قبل الاعتماد عليها.",
            Modifier.padding(vertical = 12.dp), color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        OutlinedButton(onClick = {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) locate()
            else permission.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Outlined.MyLocation, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("استخدم موقع الجهاز") }
        if (message.isNotBlank()) Text(message, Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        SectionLabel("اختر المدينة")
        DayCard(Modifier.fillMaxWidth()) {
            prayerCities.forEachIndexed { index, item ->
                Row(Modifier.fillMaxWidth().clickable { repository.select(item); city = item; message = ""; DayflowWidgetProvider.updateAll(context) }
                    .padding(horizontal = 16.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(item.name, Modifier.weight(1f), fontSize = 14.sp)
                    if (city.id == item.id) Icon(Icons.Outlined.Check, null, tint = Accent, modifier = Modifier.size(18.dp))
                }
                if (index != prayerCities.lastIndex) HorizontalDivider(color = Line)
            }
        }
    }
}

@Composable
fun CompanionScreen(onBack: () -> Unit, onInAppVisibilityChange: (Boolean) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("dayflow_compose", Context.MODE_PRIVATE) }
    var enabled by remember { mutableStateOf(prefs.getBoolean("overlay_enabled", false)) }
    var inApp by remember { mutableStateOf(prefs.getBoolean("inapp_companion", true)) }
    var size by remember { mutableFloatStateOf(prefs.getFloat("overlay_size", 1f)) }
    var opacity by remember { mutableFloatStateOf(prefs.getFloat("overlay_opacity", 1f)) }
    var message by remember { mutableStateOf("") }
    var starting by remember { mutableStateOf(false) }
    fun start() {
        if (!Settings.canDrawOverlays(context)) { message = "اسمح بالظهور فوق التطبيقات أولاً."; return }
        val success = runCatching { ContextCompat.startForegroundService(context, Intent(context, CompanionService::class.java)) }.isSuccess
        if (success) { starting = true; message = "جارٍ تشغيل الرفيق..." }
        else message = "تعذر تشغيل الرفيق. راجع إعدادات الجهاز."
    }
    LaunchedEffect(starting) {
        if (starting) { delay(700); enabled = prefs.getBoolean("overlay_enabled", false); message = if (enabled) "" else "تعذر إظهار الرفيق على هذا الجهاز."; starting = false }
    }
    val overlayPermission = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (Settings.canDrawOverlays(context)) start() else message = "لم يُمنح إذن الظهور فوق التطبيقات."
    }
    fun restart() {
        if (enabled) { context.stopService(Intent(context, CompanionService::class.java)); start() }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        ScreenTitle("الرفيق", "روبوتك الصغير في يومك", onBack)
        DayCard(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Surface(color = Soft, shape = RoundedCornerShape(20.dp)) { Icon(Icons.Outlined.SmartToy, null, Modifier.padding(15.dp).size(38.dp), tint = Accent) }
                Column { Text("الرفيق العائم", fontWeight = FontWeight.Bold); Text("اسحبه لتحريكه واضغط لفتح DAYFLOW", fontSize = 12.sp, color = Muted) }
            }
        }
        SectionLabel("الظهور على الهاتف")
        DayCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("الرفيق داخل التطبيق", Modifier.weight(1f), fontWeight = FontWeight.Medium)
                Switch(inApp, onCheckedChange = { inApp = it; prefs.edit().putBoolean("inapp_companion", it).apply(); onInAppVisibilityChange(it) })
            }
            HorizontalDivider(color = Line)
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("نافذة أندرويد العائمة", fontWeight = FontWeight.Medium); Text("تظهر فوق التطبيقات بعد منح الإذن", color = Muted, fontSize = 12.sp) }
                Switch(enabled, onCheckedChange = { value ->
                    if (!value) {
                        prefs.edit().putBoolean("overlay_enabled", false).apply(); context.stopService(Intent(context, CompanionService::class.java)); enabled = false; message = ""
                    } else if (Settings.canDrawOverlays(context)) start()
                    else overlayPermission.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                })
            }
        }
        if (message.isNotBlank()) Text(message, Modifier.padding(top = 8.dp), fontSize = 12.sp, color = Muted)
        SectionLabel("الحجم والشفافية")
        DayCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("الحجم", fontSize = 14.sp)
                Slider(value = size, onValueChange = { size = it; prefs.edit().putFloat("overlay_size", it).apply() }, valueRange = .6f..1.6f, onValueChangeFinished = { restart() })
                Text("الشفافية", fontSize = 14.sp)
                Slider(value = opacity, onValueChange = { opacity = it; prefs.edit().putFloat("overlay_opacity", it).apply() }, valueRange = .3f..1f, onValueChangeFinished = { restart() })
            }
        }
        Text("تعرض الخدمة إشعاراً دائماً أثناء ظهور الرفيق. قد تقيّد بعض الأجهزة عمل الخدمات في الخلفية.", Modifier.padding(vertical = 14.dp), color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

@Composable
fun NotificationScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var message by remember { mutableStateOf("") }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        message = if (granted) "تم السماح بالإشعارات." else "الإشعارات غير مسموحة. يمكنك تغيير الإذن من إعدادات الهاتف."
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        ScreenTitle("الإشعارات", "المنبهات والتذكيرات", onBack)
        DayCard(Modifier.fillMaxWidth()) {
            SettingsRow(Icons.Outlined.Notifications, "السماح بالإشعارات", "مطلوب لعرض التنبيهات والتذكيرات") {
                if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                    permission.launch(Manifest.permission.POST_NOTIFICATIONS)
                else context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName))
            }
            if (Build.VERSION.SDK_INT >= 34) {
                HorizontalDivider(color = Line)
                SettingsRow(Icons.Outlined.Alarm, "شاشة المنبه على القفل", "اسمح بعرض التنبيه بملء الشاشة عند الحاجة") {
                    runCatching { context.startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${context.packageName}"))) }
                        .onFailure { message = "افتح إعدادات التطبيقات للسماح بعرض المنبه بملء الشاشة." }
                }
            }
            HorizontalDivider(color = Line)
            SettingsRow(Icons.Outlined.Send, "اختبار الإشعارات", "أرسل إشعاراً حقيقياً الآن") {
                Notifications.createChannels(context)
                if (NotificationManagerCompat.from(context).areNotificationsEnabled()) {
                    val note = NotificationCompat.Builder(context, Notifications.REMINDERS).setSmallIcon(R.drawable.ic_dayflow)
                        .setContentTitle("DAYFLOW · اختبار الإشعارات").setContentText("الإشعارات تعمل على هذا الجهاز.").setAutoCancel(true).build()
                    try { NotificationManagerCompat.from(context).notify(3900, note); message = "تم إرسال إشعار الاختبار." }
                    catch (_: SecurityException) { message = "اسمح بالإشعارات أولاً." }
                } else message = "اسمح بالإشعارات أولاً من إعدادات الهاتف."
            }
        }
        if (message.isNotBlank()) Text(message, Modifier.padding(top = 12.dp), color = Accent, fontSize = 13.sp)
    }
}