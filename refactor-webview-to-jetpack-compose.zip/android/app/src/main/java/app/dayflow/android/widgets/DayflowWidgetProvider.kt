package app.dayflow.android.widgets

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.RemoteViews
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import app.dayflow.android.MainActivity
import app.dayflow.android.R
import app.dayflow.android.alarm.AlarmStore
import app.dayflow.android.alarm.AlarmScheduler
import app.dayflow.android.alarm.formatTime12
import app.dayflow.android.alarm.nextOccurrence
import app.dayflow.android.prayer.PrayerRepository
import app.dayflow.android.prayer.nextPrayer
import app.dayflow.android.ui.DayflowTheme
import app.dayflow.android.ui.WidgetCatalog
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

open class DayflowWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { refresh(context, it) }
    }
    override fun onDeleted(context: Context, ids: IntArray) {
        val editor = context.getSharedPreferences("dayflow_widgets", Context.MODE_PRIVATE).edit()
        ids.forEach { editor.remove("widget_$it") }
        editor.apply()
    }
    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            listOf(SmallWidgetProvider::class.java, WideWidgetProvider::class.java, MediumWidgetProvider::class.java,
                LargeWidgetProvider::class.java, XlWidgetProvider::class.java).forEach { type ->
                manager.getAppWidgetIds(ComponentName(context, type)).forEach { refresh(context, it) }
            }
        }

        fun refresh(context: Context, id: Int) {
            val design = context.getSharedPreferences("dayflow_widgets", Context.MODE_PRIVATE).getString("widget_$id", "clock")
            val views = RemoteViews(context.packageName, R.layout.dayflow_widget)
            views.setViewVisibility(R.id.widget_clock, if (design == "clock") View.VISIBLE else View.GONE)
            val date = LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE، d MMMM", Locale("ar", "EG")))
            when (design) {
                "alarm" -> {
                    val next = AlarmStore(context).all().mapNotNull { a -> nextOccurrence(a)?.let { a to it } }.minByOrNull { it.second }
                    views.setTextViewText(R.id.widget_title, "المنبه التالي")
                    views.setTextViewText(R.id.widget_detail, next?.let { "${formatTime12(it.first.hour, it.first.minute)}\n${it.first.label.ifBlank { "منبه" }}" } ?: "لا منبهات مفعّلة")
                }
                "prayer" -> {
                    val city = PrayerRepository(context).selected()
                    val next = nextPrayer(city)
                    views.setTextViewText(R.id.widget_title, "الصلاة · ${city.name}")
                    views.setTextViewText(R.id.widget_detail, next?.let { "${it.name}  ${formatTime12(it.at.hour, it.at.minute)}" } ?: "المواقيت غير متاحة")
                    next?.let { schedulePrayerRefresh(context, it.at.toInstant().toEpochMilli() + 1000) }
                }
                "date" -> { views.setTextViewText(R.id.widget_title, "النهاردة"); views.setTextViewText(R.id.widget_detail, date) }
                else -> { views.setTextViewText(R.id.widget_title, "DAYFLOW"); views.setTextViewText(R.id.widget_detail, date) }
            }
            val open = Intent(context, MainActivity::class.java).putExtra("route", "today")
            views.setOnClickPendingIntent(R.id.widget_root, PendingIntent.getActivity(context, id, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            AppWidgetManager.getInstance(context).updateAppWidget(id, views)
        }

        private fun schedulePrayerRefresh(context: Context, at: Long) {
            val pending = PendingIntent.getBroadcast(context, 0, Intent(context, WidgetRefreshReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val manager = context.getSystemService(AlarmManager::class.java)
            try {
                if (AlarmScheduler.canSchedule(context)) manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
                else manager.setWindow(AlarmManager.RTC_WAKEUP, at, 60_000L, pending)
            } catch (_: SecurityException) { /* The system's periodic update remains the fallback. */ }
        }
    }
}
class WidgetRefreshReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) { DayflowWidgetProvider.updateAll(context) }
}
class SmallWidgetProvider : DayflowWidgetProvider()
class WideWidgetProvider : DayflowWidgetProvider()
class MediumWidgetProvider : DayflowWidgetProvider()
class LargeWidgetProvider : DayflowWidgetProvider()
class XlWidgetProvider : DayflowWidgetProvider()

class WidgetConfigureActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        setResult(Activity.RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }
        setContent {
            DayflowTheme {
                WidgetCatalog(configuring = true, onBack = { finish() }) { design ->
                    getSharedPreferences("dayflow_widgets", Context.MODE_PRIVATE).edit().putString("widget_$id", design).commit()
                    DayflowWidgetProvider.refresh(this, id)
                    setResult(Activity.RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
                    finish()
                }
            }
        }
    }
}