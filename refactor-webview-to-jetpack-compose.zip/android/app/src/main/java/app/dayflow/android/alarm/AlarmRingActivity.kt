package app.dayflow.android.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Alarm
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import app.dayflow.android.ui.DayflowTheme

class AlarmRingActivity : ComponentActivity() {
    private val finished = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { finish() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        ContextCompat.registerReceiver(this, finished, IntentFilter("app.dayflow.android.ALARM_FINISHED"), ContextCompat.RECEIVER_NOT_EXPORTED)
        val alarm = AlarmStore(this).get(intent.getIntExtra("id", -1)) ?: run { finish(); return }
        setContent {
            DayflowTheme {
                RingContent(alarm) { action ->
                    sendBroadcast(Intent(this, AlarmActionReceiver::class.java).setAction(action).putExtra("id", alarm.id))
                    finish()
                }
            }
        }
    }
    override fun onDestroy() { unregisterReceiver(finished); super.onDestroy() }
}

@Composable
private fun RingContent(alarm: AlarmEntry, action: (String) -> Unit) {
    Column(Modifier.fillMaxSize().background(Color(0xfff7f5f0)).padding(32.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Outlined.Alarm, contentDescription = null, tint = Color(0xff2f6f5e), modifier = Modifier.size(64.dp))
        Spacer(Modifier.height(22.dp))
        Text(formatTime12(alarm.hour, alarm.minute), fontSize = 54.sp, fontWeight = FontWeight.Bold, color = Color(0xff1d1c1a))
        Text(alarm.label.ifBlank { "منبه" }, fontSize = 20.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(48.dp))
        Button(onClick = { action("app.dayflow.android.SNOOZE") }, modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp)) { Text("غفوة ${alarm.snoozeMinutes} دقائق") }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = { action("app.dayflow.android.DISMISS") }, modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp)) { Text("إيقاف المنبه") }
    }
}