package app.dayflow.android.alarm

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import app.dayflow.android.R

class AlarmService : Service() {
    private var player: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private var vibrator: Vibrator? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getIntExtra("id", -1) ?: -1
        val alarm = AlarmStore(this).get(id) ?: run { stopSelf(); return START_NOT_STICKY }
        Notifications.createChannels(this)
        val ringIntent = Intent(this, AlarmRingActivity::class.java).putExtra("id", id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val fullScreen = PendingIntent.getActivity(this, id, ringIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, Notifications.ALARMS)
            .setSmallIcon(R.drawable.ic_dayflow).setContentTitle(alarm.label.ifBlank { "منبه DAYFLOW" })
            .setContentText(formatTime12(alarm.hour, alarm.minute)).setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX).setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true).setContentIntent(fullScreen).setFullScreenIntent(fullScreen, true)
            .addAction(0, "غفوة", Notifications.action(this, id, "app.dayflow.android.SNOOZE"))
            .addAction(0, "إيقاف", Notifications.action(this, id, "app.dayflow.android.DISMISS"))
            .build()
        startForeground(Notifications.RINGING_ID, notification)
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "dayflow:alarm").apply {
            acquire(10 * 60_000L)
        }
        if (alarm.vibrate) {
            @Suppress("DEPRECATION")
            vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0))
        }
        val chosen = alarm.soundUri.takeIf { it.isNotBlank() }?.let(Uri::parse)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        play(chosen, alarm.gentle, true)
        return START_NOT_STICKY
    }

    private fun play(uri: Uri?, gentle: Boolean, allowFallback: Boolean) {
        player?.release()
        if (uri == null) return
        val media = MediaPlayer()
        player = media
        try {
            media.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            media.setDataSource(this, uri)
            media.isLooping = true
            media.setOnPreparedListener { p ->
                if (gentle) {
                    p.setVolume(0.05f, 0.05f)
                    val start = System.currentTimeMillis()
                    val ramp = object : Runnable {
                        override fun run() {
                            if (player !== p) return
                            val volume = ((System.currentTimeMillis() - start) / 60_000f).coerceIn(0.05f, 1f)
                            runCatching { p.setVolume(volume, volume) }
                            if (volume < 1f) handler.postDelayed(this, 1000)
                        }
                    }
                    handler.post(ramp)
                }
                p.start()
            }
            media.setOnErrorListener { _, _, _ ->
                if (allowFallback) play(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), gentle, false)
                true
            }
            media.prepareAsync()
        } catch (_: Exception) {
            if (allowFallback) play(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), gentle, false)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player?.release(); player = null
        vibrator?.cancel()
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}