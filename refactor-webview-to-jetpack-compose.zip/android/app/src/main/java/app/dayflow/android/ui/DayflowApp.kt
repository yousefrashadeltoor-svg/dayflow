package app.dayflow.android.ui

import android.content.ComponentName
import android.content.Context
import android.appwidget.AppWidgetManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ListAlt
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.widgets.SmallWidgetProvider

private data class Tab(val id: String, val label: String, val icon: ImageVector)
private val tabs = listOf(
    Tab("today", "النهاردة", Icons.Outlined.WbSunny), Tab("calendar", "التقويم", Icons.Outlined.CalendarMonth),
    Tab("alarms", "المنبهات", Icons.Outlined.Alarm), Tab("tools", "أدوات", Icons.Outlined.GridView),
    Tab("ai", "الذكاء", Icons.Outlined.AutoAwesome), Tab("downloads", "التحميل", Icons.Outlined.Download),
    Tab("me", "أنا", Icons.Outlined.Person)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DayflowApp(initialRoute: String, sharedUrl: String) {
    var route by rememberSaveable { mutableStateOf(initialRoute) }
    var quick by remember { mutableStateOf(false) }
    val context = LocalContext.current
    var companionVisible by remember { mutableStateOf(context.getSharedPreferences("dayflow_compose", Context.MODE_PRIVATE).getBoolean("inapp_companion", true)) }
    BackHandler(route != "today") { route = if (route in listOf("widgets", "prayer", "companion", "notifications")) "me" else "today" }
    val active = when (route) { "widgets", "prayer", "companion", "notifications" -> "me"; else -> route }
    Scaffold(containerColor = Paper, bottomBar = {
        Row(Modifier.fillMaxWidth().background(Color.White).navigationBarsPadding().padding(top = 5.dp, bottom = 7.dp),
            verticalAlignment = Alignment.CenterVertically) {
            tabs.forEach { tab ->
                val selected = active == tab.id
                Column(Modifier.weight(1f).clickable { route = tab.id }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(width = 39.dp, height = 28.dp).background(if (selected) Soft else Color.Transparent, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(tab.icon, tab.label, Modifier.size(20.dp), tint = if (selected) Accent else Muted)
                    }
                    Text(tab.label, color = if (selected) Accent else Muted, fontSize = 10.sp, maxLines = 1)
                }
            }
        }
    }, floatingActionButton = {
        SmallFloatingActionButton(onClick = { quick = true }, containerColor = Accent, contentColor = Color.White,
            shape = CircleShape, modifier = Modifier.size(56.dp)) { Icon(Icons.Outlined.Add, "اعمل جديد") }
    }, floatingActionButtonPosition = FabPosition.Center) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
          AnimatedContent(targetState = route, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "screen",
            modifier = Modifier.fillMaxSize()) { current ->
            when (current) {
                "today" -> TodayScreen { route = it }
                "alarms" -> AlarmScreen()
                "downloads" -> DownloadScreen(sharedUrl)
                "widgets" -> WidgetCatalog(configuring = false, onBack = { route = "me" }) {
                    val manager = AppWidgetManager.getInstance(context)
                    if (Build.VERSION.SDK_INT >= 26 && manager.isRequestPinAppWidgetSupported) {
                        manager.requestPinAppWidget(ComponentName(context, SmallWidgetProvider::class.java), null, null)
                    } else Toast.makeText(context, "أضف الودجت من شاشة الهاتف الرئيسية", Toast.LENGTH_LONG).show()
                }
                "prayer" -> PrayerScreen { route = "me" }
                "companion" -> CompanionScreen(onBack = { route = "me" }, onInAppVisibilityChange = { companionVisible = it })
                "notifications" -> NotificationScreen { route = "me" }
                "calendar" -> CalendarScreen()
                "tools" -> ToolsScreen { route = it }
                "me" -> MeScreen { route = it }
                "ai" -> UnavailableScreen("الذكاء", "شاشة الذكاء ومزودوها لم تُنقل إلى النسخة الأصلية بعد.")
                else -> TodayScreen { route = it }
            }
          }
          if (companionVisible) {
              InAppCompanion { route = "companion" }
          }
        }
    }
    if (quick) ModalBottomSheet(onDismissRequest = { quick = false }) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
            Text("اعمل جديد", fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            listOf(Triple("منبه", Icons.Outlined.Alarm, "alarms"), Triple("تذكير", Icons.Outlined.Notifications, "alarms"),
                Triple("إضافة ودجت", Icons.Outlined.Widgets, "widgets"), Triple("الصق رابطاً", Icons.Outlined.Link, "downloads")).forEach { (label, icon, dest) ->
                SettingsRow(icon, label) { quick = false; route = dest }
            }
        }
    }
}

@Composable
fun MeScreen(go: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 80.dp)) {
        ScreenTitle("أنا")
        DayCard(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Surface(color = Soft, shape = CircleShape) { Icon(Icons.Outlined.SmartToy, null, Modifier.padding(14.dp).size(26.dp), tint = Accent) }
                Column { Text("DAYFLOW", fontWeight = FontWeight.Bold); Text("خاص · على هذا الجهاز", color = Muted, fontSize = 12.sp) }
            }
        }
        SectionLabel("المظهر")
        DayCard(Modifier.fillMaxWidth()) {
            SettingsRow(Icons.Outlined.Widgets, "الودجات", "التصاميم المتاحة للشاشة الرئيسية") { go("widgets") }
            HorizontalDivider(color = Line)
            SettingsRow(Icons.Outlined.SmartToy, "الرفيق", "الروبوت العائم فوق التطبيقات") { go("companion") }
        }
        SectionLabel("التنبيهات والوقت")
        DayCard(Modifier.fillMaxWidth()) {
            SettingsRow(Icons.Outlined.Notifications, "الإشعارات", "الأذونات واختبار الإشعارات") { go("notifications") }
            HorizontalDivider(color = Line)
            SettingsRow(Icons.Outlined.NightsStay, "مواقيت الصلاة", "المدينة والموقع وطريقة الحساب") { go("prayer") }
        }
        Spacer(Modifier.height(18.dp))
        Text("تُنقل بقية إعدادات وتخصيصات المشروع الأصلي تدريجياً إلى أندرويد الأصلي.", color = Muted, fontSize = 12.sp, lineHeight = 19.sp)
    }
}

@Composable
fun ToolsScreen(go: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        ScreenTitle("أدوات", "كل ما تحتاجه في يومك")
        DayCard(Modifier.fillMaxWidth()) {
            SettingsRow(Icons.Outlined.Alarm, "المنبهات والتذكيرات") { go("alarms") }
            HorizontalDivider(color = Line)
            SettingsRow(Icons.Outlined.Widgets, "الودجات") { go("widgets") }
            HorizontalDivider(color = Line)
            SettingsRow(Icons.Outlined.NightsStay, "مواقيت الصلاة") { go("prayer") }
            HorizontalDivider(color = Line)
            SettingsRow(Icons.Outlined.Download, "التحميل") { go("downloads") }
        }
        Spacer(Modifier.height(16.dp))
        Text("الأدوات الأخرى في النسخة المرجعية لم تُنقل بعد إلى Compose.", fontSize = 12.sp, color = Muted)
    }
}

@Composable
fun UnavailableScreen(title: String, message: String) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTitle(title)
        DayCard(Modifier.fillMaxWidth()) { Text(message, Modifier.padding(18.dp), color = Muted, fontSize = 14.sp) }
    }
}