import { CalculationMethod, Coordinates, PrayerTimes as AdhanPrayerTimes } from "adhan";

// Times remain HH:mm internally for scheduling; the UI uses the shared 12-hour formatter.
export interface PrayerTimes { fajr: string; sunrise: string; dhuhr: string; asr: string; maghrib: string; isha: string; next: { name: string; nameAr: string; time: string; inMin: number } | null }
export interface Location { lat: number; lng: number; city: string; cityAr: string; tz: number; timeZone: string; method?: "ummalqura" | "dubai" | "mwl" }

// Keep the original order so existing saved city indexes remain valid.
export const CITIES: Location[] = [
  { lat: 30.0444, lng: 31.2357, city: "Cairo", cityAr: "القاهرة", tz: 2, timeZone: "Africa/Cairo" },
  { lat: 31.2001, lng: 29.9187, city: "Alexandria", cityAr: "الإسكندرية", tz: 2, timeZone: "Africa/Cairo" },
  { lat: 25.6872, lng: 32.6396, city: "Luxor", cityAr: "الأقصر", tz: 2, timeZone: "Africa/Cairo" },
  { lat: 24.0889, lng: 32.8998, city: "Aswan", cityAr: "أسوان", tz: 2, timeZone: "Africa/Cairo" },
  { lat: 29.9668, lng: 32.5498, city: "Suez", cityAr: "السويس", tz: 2, timeZone: "Africa/Cairo" },
  { lat: 27.9158, lng: 34.3299, city: "Sharm El-Sheikh", cityAr: "شرم الشيخ", tz: 2, timeZone: "Africa/Cairo" },
  { lat: 21.4225, lng: 39.8262, city: "Makkah", cityAr: "مكة المكرمة", tz: 3, timeZone: "Asia/Riyadh", method: "ummalqura" },
  { lat: 24.4686, lng: 39.6142, city: "Madinah", cityAr: "المدينة المنورة", tz: 3, timeZone: "Asia/Riyadh", method: "ummalqura" },
  { lat: 25.2048, lng: 55.2708, city: "Dubai", cityAr: "دبي", tz: 4, timeZone: "Asia/Dubai", method: "dubai" },
  { lat: 51.5074, lng: -0.1278, city: "London", cityAr: "لندن", tz: 0, timeZone: "Europe/London", method: "mwl" },
  { lat: 30.0131, lng: 31.2089, city: "Giza", cityAr: "الجيزة", tz: 2, timeZone: "Africa/Cairo" },
  { lat: 30.3292, lng: 31.2168, city: "Qalyubia", cityAr: "القليوبية", tz: 2, timeZone: "Africa/Cairo" },
];

const names = [["fajr", "الفجر"], ["sunrise", "الشروق"], ["dhuhr", "الظهر"], ["asr", "العصر"], ["maghrib", "المغرب"], ["isha", "العشاء"]] as const;

export function prayerTimes(loc: Location, now = new Date()): PrayerTimes {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: loc.timeZone, year: "numeric", month: "numeric", day: "numeric" }).formatToParts(now);
  const part = (key: string) => Number(parts.find((p) => p.type === key)?.value);
  const localDate = new Date(part("year"), part("month") - 1, part("day"));
  const params = loc.method === "ummalqura" ? CalculationMethod.UmmAlQura() : loc.method === "dubai" ? CalculationMethod.Dubai() : loc.method === "mwl" ? CalculationMethod.MuslimWorldLeague() : CalculationMethod.Egyptian();
  const calculate = (date: Date) => new AdhanPrayerTimes(new Coordinates(loc.lat, loc.lng), date, params);
  const today = calculate(localDate);
  const format = (date: Date) => Number.isFinite(date.getTime()) ? new Intl.DateTimeFormat("en-GB", { timeZone: loc.timeZone, hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(date) : "—";
  const times = Object.fromEntries(names.map(([name]) => [name, format(today[name])])) as Omit<PrayerTimes, "next">;
  const tomorrow = calculate(new Date(localDate.getFullYear(), localDate.getMonth(), localDate.getDate() + 1));
  const upcoming = [...names.map(([name, nameAr]) => ({ name, nameAr, at: today[name] })), { name: "fajr", nameAr: "الفجر", at: tomorrow.fajr }]
    .find((entry) => Number.isFinite(entry.at.getTime()) && entry.at.getTime() > now.getTime());
  const next = upcoming ? { name: upcoming.name, nameAr: upcoming.nameAr, time: format(upcoming.at), inMin: Math.ceil((upcoming.at.getTime() - now.getTime()) / 60000) } : null;
  return { ...times, next };
}

export const PRAYER_NAMES: Array<[keyof Omit<PrayerTimes, "next">, string, string, string]> = [
  ["fajr", "Fajr", "الفجر", "🌅"], ["sunrise", "Sunrise", "الشروق", "☀️"], ["dhuhr", "Dhuhr", "الظهر", "🕛"],
  ["asr", "Asr", "العصر", "🌤️"], ["maghrib", "Maghrib", "المغرب", "🌇"], ["isha", "Isha", "العشاء", "🌙"],
];